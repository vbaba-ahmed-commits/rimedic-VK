# RIMEDIC Security Specification & TDD Spec

## 1. Data Invariants
1. **User Isolation**: A user can only read and write their own document in `/users/{userId}` where `userId == request.auth.uid`.
2. **PII Protection**: User profiles containing phone numbers, NNI, and insurance records cannot be listed or read by other non-admin users.
3. **Appointment Ownership**: An appointment document in `/appointments/{appointmentId}` must have `patientId == request.auth.uid` upon creation.
4. **Appointment Immutability**: Critical fields like `patientId`, `referenceNumber`, `practitionerId`, `establishmentId`, and `fee` cannot be forged or altered during updates.
5. **State Transition Integrity**: An appointment can transition between `confirmed` and `cancelled` or `completed`, but non-owners cannot mutate unauthorized fields.
6. **Public Directories Read-Only**: Directory collections (`/practitioners`, `/establishments`) are readable by all authenticated users, but writable only by verified administrators.
7. **Default Deny**: Any unmatched paths or documents are strictly denied for all read and write operations.
8. **Admin Bootstrapping**: Admin capabilities check `/admins/{uid}` or authenticated email `v.baba-ahmed@mailistec.fr` with verified email token.

---

## 2. The "Dirty Dozen" Payloads

1. **Payload 1 (Identity Theft on User Profile)**:
   Attempting to write to `/users/victim_user_123` with `auth.uid = attacker_456`.
   - Result: PERMISSION_DENIED.

2. **Payload 2 (Admin Role Self-Elevation in Profile)**:
   Creating a user profile with role `ADMIN` by an unprivileged user.
   - Result: PERMISSION_DENIED.

3. **Payload 3 (Appointment Spoofing - Forging Patient ID)**:
   Creating an appointment with `patientId: "victim_123"` when `auth.uid = "attacker_456"`.
   - Result: PERMISSION_DENIED.

4. **Payload 4 (Denial of Wallet - 1MB String in Appointment Reference)**:
   Attempting to store a 50KB payload inside `referenceNumber`.
   - Result: PERMISSION_DENIED (exceeds size limit 50 chars).

5. **Payload 5 (Unauthenticated Profile Read)**:
   Unauthenticated request reading `/users/user_abc`.
   - Result: PERMISSION_DENIED.

6. **Payload 6 (Global Directory Overwrite by Patient)**:
   Attempting to update `/practitioners/dr-sidi` or `/establishments/ch-national` as a regular patient.
   - Result: PERMISSION_DENIED.

7. **Payload 7 (Orphaned Write / Invalid Appointment ID injection)**:
   Attempting to write to `/appointments/bad@id!#$` with invalid characters.
   - Result: PERMISSION_DENIED.

8. **Payload 8 (Cancelling Someone Else's Appointment)**:
   User `attacker_456` attempting to update `status: "cancelled"` on appointment owned by `patient_123`.
   - Result: PERMISSION_DENIED.

9. **Payload 9 (Fee Tampering on Appointment Update)**:
   Patient attempting to alter `fee: 0` or `patientAmount: 0` during status update.
   - Result: PERMISSION_DENIED (affectedKeys constraint).

10. **Payload 10 (Admin Collection Write by Non-Admin)**:
    Regular user attempting to write a new document into `/admins/{attacker_uid}`.
    - Result: PERMISSION_DENIED.

11. **Payload 11 (Blanket List Scraping of All Users)**:
    Calling `list` on `/users` without specifying single-user identity match.
    - Result: PERMISSION_DENIED.

12. **Payload 12 (Ghost Field Injection on Appointment)**:
    Attempting to create an appointment with unauthorized extra field `isFreePass: true`.
    - Result: PERMISSION_DENIED.
