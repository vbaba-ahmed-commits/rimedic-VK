/**
 * Types & Data Models for RIMEDIC Mauritanie
 */

export type Role = 'PATIENT' | 'PRACTITIONER' | 'ESTABLISHMENT' | 'ADMIN';
export type Language = 'fr' | 'ar';

export type InsuranceType = 'CNAM' | 'CNASS' | 'PRIVATE' | 'NONE';

export interface User {
  id: string;
  phone: string;
  role: Role;
  name: string;
}

export interface PatientProfile {
  id: string;
  firstName: string;
  lastName: string;
  birthDate: string;
  gender: 'male' | 'female';
  phone: string;
  nni: string; // Numéro National d'Identification 10 chiffres
  city: string;
  neighborhood: string;
  insuranceType: InsuranceType;
  insuranceNumber?: string;
  insuranceCardUrl?: string;
  organization?: string;
  email?: string;
  photoURL?: string;
}

export interface Subspecialty {
  id: string;
  name: string;
  nameAr: string;
  doctorCount: number;
}

export interface Specialty {
  id: string;
  name: string;
  nameAr: string;
  subtitle: string;
  subtitleAr: string;
  icon: string;
  category: 'dentaire' | 'mere-enfant' | 'consultation' | 'chirurgie' | 'specialise';
  popular?: boolean;
  urgent?: boolean;
  isPopular?: boolean;
  subspecialties: Subspecialty[];
  specialistCount: number;
  availableDelay: string;
  availableDelayAr: string;
  keywords?: string[];
}

export interface Practitioner {
  id: string;
  firstName: string;
  lastName: string;
  title: string;
  titleAr: string;
  specialtyId: string;
  specialtyName: string;
  specialtyNameAr: string;
  subspecialtyNames: string[];
  establishmentId: string;
  establishmentName: string;
  establishmentNameAr: string;
  city: string;
  neighborhood: string;
  avatarUrl?: string;
  initials: string;
  rating: number;
  reviewsCount: number;
  experienceYears: number;
  education: string;
  educationAr: string;
  languages: string[];
  languagesAr: string[];
  fee: number; // in MRU
  nextSlot: string; // e.g. "Aujourd'hui à 15:30"
  nextSlotAr: string;
  verified: boolean;
  cnamConventioned: boolean;
  bio: string;
  bioAr: string;
}

export interface PractitionerScheduleDay {
  dayOfWeek: number; // 0 Sunday, 1 Monday, ... 6 Saturday
  dayName: string;
  dayNameAr: string;
  active: boolean;
  morningStart: string;
  morningEnd: string;
  hasLunchBreak: boolean;
  lunchStart: string;
  lunchEnd: string;
  afternoonStart: string;
  afternoonEnd: string;
}

export interface PractitionerProfileData {
  id: string;
  firstName: string;
  lastName: string;
  title: string;
  titleAr: string;
  phone: string;
  email?: string;
  specialtyId: string;
  specialtyName: string;
  specialtyNameAr: string;
  establishmentId: string;
  establishmentName: string;
  establishmentNameAr: string;
  city: string;
  neighborhood: string;
  fee: number;
  cnamConventioned: boolean;
  cnassConventioned: boolean;
  orderNumber: string;
  experienceYears: number;
  bio: string;
  bioAr: string;
  education: string;
  educationAr: string;
  languages: string[];
  slotDurationMinutes: number;
  autoAcceptAppointments: boolean;
  allowEmergencyWalkins: boolean;
  smsRemindersEnabled: boolean;
  teleconsultationEnabled: boolean;
  schedule: PractitionerScheduleDay[];
}

export type EstablishmentType =
  | 'hopital'
  | 'clinique'
  | 'dentaire'
  | 'laboratoire'
  | 'imagerie'
  | 'specialise';

export interface Establishment {
  id: string;
  name: string;
  nameAr: string;
  type: EstablishmentType;
  typeLabel: string;
  typeLabelAr: string;
  city: string;
  neighborhood: string;
  address: string;
  phone: string;
  openingHours: string;
  openingHoursAr: string;
  emergency24h: boolean;
  cnamConventioned: boolean;
  rating: number;
  reviewsCount: number;
  specialties: string[];
  specialtiesAr: string[];
  practitionerCount: number;
  latitude: number | null;
  longitude: number | null;
  verified: boolean;
  verificationStatus: 'verified' | 'pending' | 'rejected';
  photoUrl?: string;
  licenseNumber?: string;
  capacity?: string;
  hasScanner?: boolean;
  hasPMR?: boolean;
  hasParking?: boolean;
  mapX?: number;
  mapY?: number;
}

export interface City {
  id: string;
  name: string;
  nameAr: string;
  wilaya: string;
  wilayaAr: string;
  moughataas: string[];
  moughataasAr?: string[];
  centerCount: number;
  practitionerCount: number;
  isCapital?: boolean;
}

export type AppointmentStatus = 'confirmed' | 'pending' | 'completed' | 'cancelled';

export interface Appointment {
  id: string;
  referenceNumber: string; // e.g. "SCAN-RIM-89412"
  patientId: string;
  patientName: string;
  patientPhone: string;
  patientNni: string;
  practitionerId: string;
  practitionerName: string;
  practitionerSpecialty: string;
  practitionerSpecialtyAr: string;
  establishmentId: string;
  establishmentName: string;
  establishmentAddress: string;
  date: string; // e.g. "2026-09-28"
  dateFormatted: string; // e.g. "Lun. 28 Septembre 2026"
  time: string; // e.g. "15:30"
  fee: number; // e.g. 1500
  reason: string;
  reasonAr: string;
  status: AppointmentStatus;
  insuranceType: InsuranceType;
  insuranceCoveragePercent: number; // e.g. 80
  cnamAmount: number; // e.g. 1200
  patientAmount: number; // e.g. 300
  qrCodeData: string;
  createdAt: string;
}

export interface ConsultationSlot {
  time: string;
  period: 'morning' | 'afternoon';
  isAvailable: boolean;
  isBlocked?: boolean;
  bookedPatientName?: string;
  bookedReason?: string;
  status?: 'termine' | 'honore' | 'urgence' | 'pause' | 'avis' | 'attente' | 'confirme' | 'libre';
  fileNumber?: string;
}
