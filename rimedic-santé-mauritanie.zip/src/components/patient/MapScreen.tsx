import React, { useState, useMemo, useEffect, useRef } from 'react';
import L from 'leaflet';
import { useApp } from '../../context/AppContext';
import { ESTABLISHMENTS_DATA, PRACTITIONERS_DATA } from '../../data/mockData';
import { Establishment } from '../../types';
import { translateNeighborhood, translateSpecialtyName, translateOpeningHours } from '../../translations';

export const MapScreen: React.FC = () => {
  const {
    language,
    navigateTo,
    setSelectedEstablishment,
    setSelectedPractitioner,
    isRtl
  } = useApp();

  const [search, setSearch] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<
    'all' | 'hopital' | 'clinique' | 'dentaire' | 'urgences' | 'open_now' | 'bookable'
  >('all');
  const [activeFacility, setActiveFacility] = useState<Establishment>(ESTABLISHMENTS_DATA[0]);

  // Leaflet map refs
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  // Useful filters (Exigence 15)
  const filters = [
    { id: 'all', label: language === 'fr' ? 'Tous' : 'الكل' },
    { id: 'hopital', label: language === 'fr' ? 'Hôpitaux' : 'مستشفيات' },
    { id: 'clinique', label: language === 'fr' ? 'Cliniques' : 'مصحات' },
    { id: 'dentaire', label: language === 'fr' ? 'Cabinets' : 'عيادات' },
    { id: 'urgences', label: language === 'fr' ? 'Urgences 24h' : 'طوارئ ٢٤ ساعة' },
    { id: 'open_now', label: language === 'fr' ? 'Ouvert maintenant' : 'مفتوح الآن' },
    { id: 'bookable', label: language === 'fr' ? 'Dispo réservation' : 'متاح للحجز' },
  ];

  // Neighborhoods of Nouakchott for quick navigation
  const neighborhoods = [
    { name: 'Tevragh Zeina', coords: [18.0984, -15.9752] as [number, number] },
    { name: 'Ksar', coords: [18.0855, -15.9620] as [number, number] },
    { name: 'Sebkha', coords: [18.0670, -15.9860] as [number, number] },
    { name: 'Arafat', coords: [18.0520, -15.9540] as [number, number] },
    { name: 'Dar Naïm', coords: [18.1120, -15.9350] as [number, number] },
    { name: 'Toujounine', coords: [18.0880, -15.9080] as [number, number] },
  ];

  // Helper to resolve coordinates
  const getCoords = (est: Establishment, idx: number): [number, number] => {
    if (est.latitude && est.longitude) {
      return [est.latitude, est.longitude];
    }
    const latOffset = (((idx * 19) % 70) - 35) * 0.0012;
    const lngOffset = (((idx * 29) % 70) - 35) * 0.0014;
    return [18.0858 + latOffset, -15.9785 + lngOffset];
  };

  // Multi-criteria search (name, doctor, specialty, sub-specialty, city/neighborhood)
  const filteredFacilities = useMemo(() => {
    return ESTABLISHMENTS_DATA.filter(est => {
      // Filter tab criteria
      if (selectedFilter === 'hopital' && est.type !== 'hopital') return false;
      if (selectedFilter === 'clinique' && est.type !== 'clinique') return false;
      if (selectedFilter === 'dentaire' && est.type !== 'dentaire') return false;
      if (selectedFilter === 'urgences' && !est.emergency24h) return false;
      if (selectedFilter === 'open_now' && est.openingHours?.includes('Fermé')) return false;

      if (!search.trim()) return true;

      const q = search.toLowerCase().trim();
      const matchName = est.name.toLowerCase().includes(q) || est.nameAr.toLowerCase().includes(q);
      const matchLoc = est.neighborhood.toLowerCase().includes(q) || est.city.toLowerCase().includes(q);
      const matchSpec = est.specialties.some(s => s.toLowerCase().includes(q));

      // Match doctors practicing in this facility
      const matchDoc = PRACTITIONERS_DATA.some(d =>
        d.establishmentId === est.id && (
          d.title.toLowerCase().includes(q) ||
          d.titleAr.toLowerCase().includes(q) ||
          d.specialtyName.toLowerCase().includes(q) ||
          d.subspecialtyNames.some(sub => sub.toLowerCase().includes(q))
        )
      );

      return matchName || matchLoc || matchSpec || matchDoc;
    });
  }, [search, selectedFilter]);

  // Open dynamic universal directions in Google Maps (Exigence 16)
  const handleOpenDirections = (facility: Establishment) => {
    const destination = facility.latitude && facility.longitude
      ? `${facility.latitude},${facility.longitude}`
      : encodeURIComponent(`${facility.name} ${facility.address} Nouakchott Mauritanie`);
    const url = `https://www.google.com/maps/dir/?api=1&destination=${destination}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleBookFacility = (facility: Establishment) => {
    setSelectedEstablishment(facility);
    const doctor = PRACTITIONERS_DATA.find(d => d.establishmentId === facility.id) || PRACTITIONERS_DATA[0];
    setSelectedPractitioner(doctor);
    navigateTo('doctor-profile', { doctor, establishment: facility });
  };

  // Fly to Nouakchott Center
  const handleCenterNouakchott = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([18.0858, -15.9785], 13, { duration: 0.8 });
    }
  };

  // Fly to Neighborhood
  const handleFlyToNeighborhood = (coords: [number, number]) => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo(coords, 14, { duration: 0.8 });
    }
  };

  // Select Facility and center map
  const handleSelectFacility = (facility: Establishment) => {
    setActiveFacility(facility);
    if (mapInstanceRef.current) {
      const idx = ESTABLISHMENTS_DATA.findIndex(e => e.id === facility.id);
      const coords = getCoords(facility, idx);
      mapInstanceRef.current.flyTo(coords, 15, { duration: 0.8 });
    }
  };

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    // Centered at Nouakchott, Mauritanie (18.0858° N, 15.9785° W)
    const map = L.map(mapContainerRef.current, {
      center: [18.0858, -15.9785],
      zoom: 13,
      zoomControl: false,
    });

    // Custom OpenStreetMap Tiles
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap',
    }).addTo(map);

    // Zoom control at bottom-right
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    const markersGroup = L.layerGroup().addTo(map);
    markersLayerRef.current = markersGroup;
    mapInstanceRef.current = map;

    // Invalidate size after layout stabilization
    const timer = setTimeout(() => {
      map.invalidateSize();
    }, 200);

    return () => {
      clearTimeout(timer);
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Markers on Leaflet Map
  useEffect(() => {
    if (!markersLayerRef.current || !mapInstanceRef.current) return;

    markersLayerRef.current.clearLayers();

    filteredFacilities.forEach((facility, idx) => {
      const coords = getCoords(facility, idx);
      const isSelected = activeFacility?.id === facility.id;

      const bgClass = facility.emergency24h
        ? '#dc2626'
        : facility.type === 'hopital'
        ? '#006948'
        : facility.type === 'clinique'
        ? '#059669'
        : '#0284c7';

      const iconSymbol = facility.emergency24h
        ? 'emergency'
        : facility.type === 'hopital'
        ? 'local_hospital'
        : 'apartment';

      const customIcon = L.divIcon({
        className: 'rimedic-leaflet-pin',
        html: `
          <div style="position: relative; display: flex; align-items: center; justify-content: center; transform: translate(-50%, -50%); cursor: pointer;">
            ${facility.emergency24h ? '<span style="position: absolute; width: 34px; height: 34px; border-radius: 9999px; background: rgba(239, 68, 68, 0.4); animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></span>' : ''}
            <div style="width: ${isSelected ? '36px' : '30px'}; height: ${isSelected ? '36px' : '30px'}; border-radius: 9999px; background-color: ${bgClass}; color: white; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 10px rgba(0,0,0,0.3); border: 2.5px solid white; transition: all 0.2s ease;">
              <span class="material-symbols-outlined" style="font-size: ${isSelected ? '20px' : '16px'};">${iconSymbol}</span>
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [0, 0],
      });

      const marker = L.marker(coords, { icon: customIcon });

      const popupContent = `
        <div style="font-family: inherit; font-size: 12px; min-width: 160px; padding: 4px 2px;">
          <strong style="color: #006948; font-size: 13px; display: block; margin-bottom: 2px;">${language === 'fr' ? facility.name : (facility.nameAr || facility.name)}</strong>
          <span style="color: #64748b; font-size: 11px; display: block;">${language === 'fr' ? `${facility.typeLabel} • ${facility.neighborhood}` : `${facility.typeLabelAr || facility.typeLabel} • ${translateNeighborhood(facility.neighborhood, language)}`}</span>
          ${facility.emergency24h ? `<span style="display: inline-block; margin-top: 4px; padding: 2px 6px; border-radius: 9999px; font-size: 10px; font-weight: bold; background: #fee2e2; color: #b91c1c;">${language === 'fr' ? 'Urgences 24h' : 'طوارئ ٢٤ ساعة'}</span>` : ''}
        </div>
      `;

      marker.bindPopup(popupContent);

      marker.on('click', () => {
        setActiveFacility(facility);
      });

      markersLayerRef.current?.addLayer(marker);
    });
  }, [filteredFacilities, activeFacility]);

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Header & Search */}
      <div className="px-4 pt-3 pb-2 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-on-surface tracking-tight">
              {language === 'fr' ? 'Carte Santé Nouakchott' : 'خريطة المنشآت الصحية'}
            </h1>
            <p className="text-xs text-on-surface-variant">
              {language === 'fr'
                ? `${filteredFacilities.length} structures médicales géoréférencées`
                : `${filteredFacilities.length} منشأة صحية موثقة في نواكشوط`}
            </p>
          </div>

          <button
            onClick={handleCenterNouakchott}
            title={language === 'fr' ? 'Recentrer sur Nouakchott' : 'إعادة التوسيط على نواكشوط'}
            className="px-2.5 py-1.5 rounded-xl bg-surface-container hover:bg-surface-container-high text-primary text-xs font-bold flex items-center gap-1 transition-colors shadow-2xs cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">my_location</span>
            <span>{language === 'fr' ? 'Recentrer' : 'توسيط'}</span>
          </button>
        </div>

        {/* Global Search Bar */}
        <div className="relative flex items-center w-full bg-surface-container-lowest rounded-xl shadow-xs border border-surface-container">
          <span className="material-symbols-outlined text-outline ml-3 mr-2 text-[20px]">search</span>
          <input
            type="search"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={language === 'fr' ? 'Établissement, médecin, spécialité, quartier...' : 'ابحث عن منشأة، طبيب، تخصص، حي...'}
            className="w-full h-11 px-1 bg-transparent text-xs text-on-surface focus:outline-none placeholder:text-outline"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="pr-3 text-outline hover:text-on-surface cursor-pointer"
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          )}
        </div>

        {/* Essential Filter Pills (Exigence 15) */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          {filters.map(f => (
            <button
              key={f.id}
              onClick={() => setSelectedFilter(f.id as any)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all cursor-pointer ${
                selectedFilter === f.id
                  ? 'bg-primary text-white shadow-xs'
                  : 'bg-surface-container-low text-on-surface-variant hover:bg-surface-container border border-surface-container'
              }`}
              type="button"
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Quick Neighborhood Navigation Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-0.5">
          <span className="text-[10px] font-bold text-outline uppercase tracking-wider shrink-0">
            {language === 'fr' ? 'Quartiers :' : 'الأحياء :'}
          </span>
          {neighborhoods.map(n => (
            <button
              key={n.name}
              type="button"
              onClick={() => handleFlyToNeighborhood(n.coords)}
              className="px-2.5 py-0.5 rounded-lg bg-surface-container-lowest hover:bg-primary/10 hover:text-primary text-[11px] font-medium text-on-surface-variant border border-surface-container shrink-0 transition-colors cursor-pointer"
            >
              {translateNeighborhood(n.name, language)}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Navigable Leaflet Map Container */}
      <div className="px-4 my-2">
        <div className="relative w-full h-72 rounded-2xl overflow-hidden border border-surface-container shadow-sm bg-[#e8ece9]">
          {/* Real Leaflet Map DOM Element */}
          <div ref={mapContainerRef} className="w-full h-full z-0" />

          {/* Interactive Navigation Hint */}
          <div className="absolute top-2 left-2 z-10 pointer-events-none">
            <span className="px-2 py-0.5 bg-white/95 backdrop-blur-xs rounded-full text-[10px] font-bold text-slate-700 shadow-xs border border-slate-200 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>{language === 'fr' ? 'Carte interactive (glisser, zoomer)' : 'خريطة تفاعلية (اسحب للتنقل)'}</span>
            </span>
          </div>

          {/* Legend Overlay at top right */}
          <div className="absolute top-2 right-2 z-10 flex items-center gap-2 bg-white/95 backdrop-blur-xs px-2 py-1 rounded-xl border border-slate-200 text-[10px] text-slate-700 shadow-xs">
            <span className="flex items-center gap-1 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600"></span>
              <span>{language === 'fr' ? 'Urgences' : 'طوارئ'}</span>
            </span>
            <span className="flex items-center gap-1 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-primary"></span>
              <span>{language === 'fr' ? 'Hôpital' : 'مستشفى'}</span>
            </span>
            <span className="flex items-center gap-1 font-semibold">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
              <span>{language === 'fr' ? 'Clinique' : 'عيادة'}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Selected Facility Details Card (Exigence 14: Fiche complète avec tous les détails vérifiés) */}
      {activeFacility && (
        <div className="px-4 my-1">
          <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container flex flex-col gap-3 animate-fadeIn">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-3 min-w-0">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${
                    activeFacility.emergency24h
                      ? 'bg-red-50 text-red-600'
                      : 'bg-primary-container text-on-primary'
                  }`}
                >
                  <span className="material-symbols-outlined text-[24px]">
                    {activeFacility.emergency24h ? 'emergency' : 'domain'}
                  </span>
                </div>
                <div className="flex flex-col min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <h3 className="font-bold text-sm text-on-surface truncate">
                      {language === 'fr' ? activeFacility.name : (activeFacility.nameAr || activeFacility.name)}
                    </h3>
                  </div>
                  <p className="text-xs text-primary font-semibold truncate">
                    {language === 'fr' ? activeFacility.typeLabel : (activeFacility.typeLabelAr || activeFacility.typeLabel)} • {translateNeighborhood(activeFacility.neighborhood, language)}
                  </p>
                  <div className="flex items-center gap-1 text-[11px] text-on-surface-variant mt-0.5">
                    <span className="material-symbols-outlined text-[14px] text-secondary">location_on</span>
                    <span className="truncate">
                      {language === 'fr'
                        ? activeFacility.address
                        : `${translateNeighborhood(activeFacility.neighborhood, language)}، نواكشوط`}
                    </span>
                  </div>
                </div>
              </div>

              {activeFacility.emergency24h && (
                <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-[10px] font-bold shrink-0">
                  {language === 'fr' ? 'Urgences 24/7' : 'طوارئ ٢٤/٧'}
                </span>
              )}
            </div>

            {/* Badges de Statut (Exigence 19: Statuts distincts et vérifiés) */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-surface-container/60">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold">
                <span className="material-symbols-outlined text-[13px]">verified</span>
                <span>{language === 'fr' ? 'Référencé & Vérifié' : 'معتمد وموثق'}</span>
              </span>

              {activeFacility.cnamConventioned && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-bold">
                  <span className="material-symbols-outlined text-[13px]">health_and_safety</span>
                  <span>{language === 'fr' ? 'Conventionné CNAM & CNASS' : 'معتمد كنام وكناص'}</span>
                </span>
              )}

              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-surface-container text-on-surface-variant text-[10px] font-semibold">
                <span className="material-symbols-outlined text-[13px]">schedule</span>
                <span>
                  {translateOpeningHours(activeFacility.openingHours, (activeFacility as any).openingHoursAr, language)}
                </span>
              </span>
            </div>

            {/* Spécialités & Services */}
            <div className="text-xs">
              <span className="font-bold text-on-surface block mb-1">
                {language === 'fr' ? 'Spécialités disponibles :' : 'التخصصات المتوفرة:'}
              </span>
              <div className="flex flex-wrap gap-1">
                {activeFacility.specialties.map((s, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md bg-surface-container-low text-on-surface text-[10px] font-medium"
                  >
                    {translateSpecialtyName(s, language)}
                  </span>
                ))}
              </div>
            </div>

            {/* Action Buttons: Itinéraire et Prise de RDV */}
            <div className="grid grid-cols-2 gap-2 pt-1 border-t border-surface-container/60">
              <button
                type="button"
                onClick={() => handleOpenDirections(activeFacility)}
                className="py-2.5 px-3 bg-surface-container hover:bg-surface-container-high text-on-surface rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px] text-primary">near_me</span>
                <span>{language === 'fr' ? "Voir l'itinéraire" : "الاتجاهات"}</span>
              </button>

              <button
                type="button"
                onClick={() => handleBookFacility(activeFacility)}
                className="py-2.5 px-3 bg-primary hover:bg-primary/95 text-on-primary rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-transform cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">calendar_today</span>
                <span>{language === 'fr' ? 'Prendre RDV' : 'حجز موعد'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Facilities List */}
      <div className="px-4 mt-3 flex flex-col gap-2">
        <h3 className="font-bold text-xs uppercase tracking-wider text-outline px-1">
          {language === 'fr' ? 'Établissements répertoriés' : 'قائمة المنشآت الطبية'}
        </h3>
        {filteredFacilities.slice(0, 15).map(facility => (
          <div
            key={facility.id}
            onClick={() => handleSelectFacility(facility)}
            className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
              activeFacility.id === facility.id
                ? 'bg-surface-container-lowest border-primary shadow-xs ring-1 ring-primary/20'
                : 'bg-white border-surface-container hover:bg-surface-container-low'
            }`}
          >
            <div className="min-w-0 pr-2">
              <p className="font-bold text-xs text-on-surface truncate">
                {language === 'fr' ? facility.name : (facility.nameAr || facility.name)}
              </p>
              <p className="text-[11px] text-on-surface-variant truncate">
                {language === 'fr'
                  ? `${facility.neighborhood} • ${facility.typeLabel}`
                  : `${translateNeighborhood(facility.neighborhood, language)} • ${facility.typeLabelAr || facility.typeLabel}`}
              </p>
            </div>
            <span className="material-symbols-outlined text-[18px] text-outline">
              chevron_right
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
