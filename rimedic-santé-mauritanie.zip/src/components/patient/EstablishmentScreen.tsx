import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PRACTITIONERS_DATA, ESTABLISHMENTS_DATA } from '../../data/mockData';
import { Practitioner } from '../../types';
import {
  translateNeighborhood,
  translateSpecialtyName,
  translateDoctorTitle,
  translateSlotText,
  translateOpeningHours,
  parseSlotParts,
} from '../../translations';

export const EstablishmentScreen: React.FC = () => {
  const {
    language,
    navigateTo,
    selectedEstablishment,
    setSelectedPractitioner,
    showToast,
    isRtl
  } = useApp();

  const est = selectedEstablishment || ESTABLISHMENTS_DATA[0];
  const [activeTab, setActiveTab] = useState<'presentation' | 'praticiens' | 'services'>('presentation');
  const [isFavorite, setIsFavorite] = useState(false);

  const doctorsInEstablishment = PRACTITIONERS_DATA.filter(d => d.establishmentId === est.id);

  const handleBookWithDoctor = (doc: Practitioner) => {
    setSelectedPractitioner(doc);
    navigateTo('doctor-profile', { doctor: doc });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: language === 'fr' ? est.name : (est.nameAr || est.name),
        text: language === 'fr'
          ? `Fiche médicale et prise de rendez-vous à la ${est.name} (${est.neighborhood}, Nouakchott).`
          : `الملف الطبي وحجز موعد في ${est.nameAr || est.name} (${translateNeighborhood(est.neighborhood, language)}، نواكشوط).`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      showToast(
        language === 'fr' ? 'Lien copié !' : 'تم نسخ الرابط !',
        language === 'fr' ? est.name : (est.nameAr || est.name)
      );
    }
  };

  return (
    <div className="flex flex-col w-full pb-36">
      {/* Top Bar Navigation & Actions */}
      <div className="px-4 pt-3 pb-2 flex items-center justify-between">
        <button
          onClick={() => navigateTo('map')}
          className="inline-flex items-center gap-1.5 text-primary text-xs font-bold hover:opacity-80 transition-opacity"
        >
          <span className={`material-symbols-outlined text-[16px] ${isRtl ? 'rotate-180' : ''}`}>
            arrow_back
          </span>
          <span>{language === 'fr' ? 'Établissements' : 'المؤسسات الصحية'}</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={handleShare}
            aria-label={language === 'fr' ? "Partager" : "مشاركة"}
            className="w-9 h-9 rounded-full bg-surface-container flex items-center justify-center text-on-surface hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined text-[18px]">share</span>
          </button>
          <button
            onClick={() => {
              setIsFavorite(!isFavorite);
              showToast(
                isFavorite
                  ? (language === 'fr' ? 'Retiré des favoris' : 'تمت الإزالة من المفضلة')
                  : (language === 'fr' ? 'Ajouté aux favoris' : 'تمت الإضافة إلى المفضلة'),
                language === 'fr' ? est.name : (est.nameAr || est.name)
              );
            }}
            aria-label={language === 'fr' ? "Ajouter aux favoris" : "إضافة للمفضلة"}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${
              isFavorite ? 'bg-error-container text-error' : 'bg-surface-container text-on-surface'
            }`}
          >
            <span className={`material-symbols-outlined text-[18px] ${isFavorite ? 'fill-current' : ''}`}>
              favorite
            </span>
          </button>
        </div>
      </div>

      {/* Hero Facade Visual Frame */}
      <div className="px-4 mb-3">
        <div className="relative w-full h-44 rounded-2xl overflow-hidden shadow-sm border border-surface-container">
          <img
            src={est.photoUrl || 'https://lh3.googleusercontent.com/aida-public/AB6AXuAPB0EdicaOgOJJWvzYJasbTen65Xyy-O8HlOrqig1Abd8SHHQDhlyUrQjLeOoUj3Qlll7vhzF8JLoLy0ll-SESdKBkj1yCK_Sr23itT1nRD4wyvO5R1wjfCyGIlG6kYELDQ05jytDHM6cdBBbUYibuL9VmdIubk_3LED1iWaZcfyUlC2gWc5uvoZYxbstxyva0mPIosZjIsrogqh2Oizz6Vxru4WIBTYZ1EMpslxTLoM9hEMlySYbEbw'}
            alt={language === 'fr' ? est.name : (est.nameAr || est.name)}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent"></div>

          {/* Badges on Hero */}
          <div className="absolute top-3 left-3 right-3 flex items-start justify-between gap-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-primary-container text-on-primary text-[10px] font-bold shadow-xs">
              <span className="material-symbols-outlined text-[13px]">verified</span>
              <span>{language === 'fr' ? 'Conventionné CNAM & CNASS' : 'معتمد لدى كنام وكناص'}</span>
            </span>
            <span className="px-2 py-0.5 rounded-full bg-white/90 backdrop-blur-md text-secondary text-[10px] font-bold">
              {language === 'fr' ? 'Vérifiée' : 'معتمد وموثق'}
            </span>
          </div>

          <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between text-white">
            <div className="min-w-0 pr-2">
              <span className="text-white/80 text-[10px] uppercase font-bold tracking-wider block truncate">
                {language === 'fr' ? `${est.city} • ${est.neighborhood}` : `نواكشوط • ${translateNeighborhood(est.neighborhood, language)}`}
              </span>
              <h2 className="text-lg font-bold truncate">
                {language === 'fr' ? est.name : (est.nameAr || est.name)}
              </h2>
            </div>
            <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-md text-primary shrink-0">
              <span className="material-symbols-outlined text-[24px]">local_hospital</span>
            </div>
          </div>
        </div>
      </div>

      {/* Identity Details Card */}
      <div className="px-4 mb-3">
        <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container">
          <div className="flex items-start gap-2.5">
            <div className="w-8 h-8 rounded-full bg-secondary-container text-on-secondary-container flex items-center justify-center shrink-0 mt-0.5">
              <span className="material-symbols-outlined text-[18px]">verified_user</span>
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-sm text-on-surface truncate">
                {language === 'fr' ? est.typeLabel : est.typeLabelAr}
              </h3>
              <p className="text-xs text-on-surface-variant flex items-center gap-1 mt-0.5 truncate">
                <span className="material-symbols-outlined text-[15px] text-tertiary">location_on</span>
                <span className="truncate">
                  {language === 'fr'
                    ? est.address
                    : `${translateNeighborhood(est.neighborhood, language)}، نواكشوط، موريتانيا`}
                </span>
              </p>
            </div>
          </div>

          <div className="mt-3 pt-2 border-t border-surface-container flex items-center justify-between text-xs">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-surface-container-low text-secondary font-semibold">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
              <span>{translateOpeningHours(est.openingHours, est.openingHoursAr, language)}</span>
            </div>
            <div className="flex items-center gap-1 text-tertiary font-bold">
              <span className="material-symbols-outlined text-[16px]">star</span>
              <span>{est.rating}</span>
              <span className="text-[11px] text-outline font-normal">({est.reviewsCount}+)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons (3 cols from Stitch) */}
      <div className="px-4 mb-3 grid grid-cols-3 gap-2">
        <a
          href={`tel:${est.phone}`}
          className="flex flex-col items-center justify-center p-3 bg-surface-container-lowest rounded-2xl shadow-xs border border-surface-container text-center hover:bg-surface-container-low transition-colors"
        >
          <div className="w-10 h-10 rounded-full bg-secondary-container text-on-secondary-container flex items-center justify-center mb-1">
            <span className="material-symbols-outlined text-[20px]">call</span>
          </div>
          <span className="font-bold text-xs text-on-surface">{language === 'fr' ? 'Standard' : 'الهاتف'}</span>
          <span className="text-[10px] text-outline truncate">{est.phone.replace('+222 ', '')}</span>
        </a>

        <a
          href={
            est.latitude && est.longitude
              ? `https://www.google.com/maps/dir/?api=1&destination=${est.latitude},${est.longitude}`
              : `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${est.name} ${est.address} Nouakchott Mauritanie`)}`
          }
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center p-3 bg-surface-container-lowest rounded-2xl shadow-xs border border-surface-container text-center hover:bg-surface-container-low transition-colors"
        >
          <div className="w-10 h-10 rounded-full bg-secondary-container text-primary flex items-center justify-center mb-1">
            <span className="material-symbols-outlined text-[20px]">near_me</span>
          </div>
          <span className="font-bold text-xs text-on-surface">{language === 'fr' ? "Voir l'itinéraire" : "الاتجاهات"}</span>
          <span className="text-[10px] text-outline">Google Maps</span>
        </a>

        <button
          onClick={() => {
            if (doctorsInEstablishment.length > 0) {
              handleBookWithDoctor(doctorsInEstablishment[0]);
            }
          }}
          className="flex flex-col items-center justify-center p-3 bg-primary rounded-2xl shadow-xs text-center text-on-primary hover:opacity-95 transition-opacity"
          type="button"
        >
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mb-1">
            <span className="material-symbols-outlined text-[20px]">calendar_month</span>
          </div>
          <span className="font-bold text-xs">{language === 'fr' ? 'Réserver' : 'حجز موعد'}</span>
          <span className="text-[10px] text-on-primary-container truncate">{language === 'fr' ? 'Dispo en 24h' : 'متاح خلال ٢٤س'}</span>
        </button>
      </div>

      {/* Tab Selector */}
      <div className="px-4 mb-3">
        <div className="flex items-center p-1 bg-surface-container-high rounded-full border border-surface-container">
          <button
            onClick={() => setActiveTab('presentation')}
            className={`flex-1 py-1.5 px-2 rounded-full text-xs font-bold transition-all text-center ${
              activeTab === 'presentation'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant'
            }`}
          >
            {language === 'fr' ? 'Présentation' : 'عن المنشأة'}
          </button>
          <button
            onClick={() => setActiveTab('praticiens')}
            className={`flex-1 py-1.5 px-2 rounded-full text-xs font-bold transition-all text-center ${
              activeTab === 'praticiens'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant'
            }`}
          >
            {language === 'fr' ? `Praticiens (${doctorsInEstablishment.length || 14})` : `الأطباء (${doctorsInEstablishment.length || 14})`}
          </button>
          <button
            onClick={() => setActiveTab('services')}
            className={`flex-1 py-1.5 px-2 rounded-full text-xs font-bold transition-all text-center cursor-pointer ${
              activeTab === 'services'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant'
            }`}
          >
            {language === 'fr' ? 'Services & Équipements' : 'الخدمات والتجهيزات'}
          </button>
        </div>
      </div>

      {/* Tab 1: Présentation */}
      {activeTab === 'presentation' && (
        <div className="flex flex-col gap-3 px-4">
          {/* About */}
          <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container">
            <div className="flex items-center gap-2 mb-2">
              <span className="material-symbols-outlined text-primary text-[20px]">info</span>
              <h4 className="font-bold text-sm text-on-surface">
                {language === 'fr' ? "À propos de l'établissement" : "عن المنشأة الصحية"}
              </h4>
            </div>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              {language === 'fr'
                ? `Référence des soins privés et spécialisés à Nouakchott depuis plus de 15 ans, la ${est.name} réunit un plateau technique de dernière génération, des blocs opératoires ultra-stériles et un service d'urgences accessible jour et nuit avec astreinte permanente.`
                : `تعتبر ${est.nameAr || est.name} مرجعاً طبياً للرعاية الصحية في نواكشوط منذ أكثر من 15 عاماً، حيث تجمع بين أحدث التجهيزات الطبية وغرف العمليات المعقمة وقسم طوارئ متاح على مدار الساعة.`}
            </p>

            <div className="mt-3 grid grid-cols-2 gap-2">
              <div className="p-2.5 bg-surface-container-low rounded-xl flex items-center gap-2 border border-surface-container">
                <span className="material-symbols-outlined text-secondary text-[20px]">medical_services</span>
                <div>
                  <span className="text-[10px] text-outline block">{language === 'fr' ? 'Capacité' : 'الطاقة الاستيعابية'}</span>
                  <span className="text-xs font-bold text-on-surface">
                    {language === 'fr' ? (est.capacity || '42 Lits d\'hosp.') : '٤٢ سريراً استشفائياً'}
                  </span>
                </div>
              </div>
              <div className="p-2.5 bg-surface-container-low rounded-xl flex items-center gap-2 border border-surface-container">
                <span className="material-symbols-outlined text-primary text-[20px]">biotech</span>
                <div>
                  <span className="text-[10px] text-outline block">{language === 'fr' ? 'Laboratoire' : 'المختبر'}</span>
                  <span className="text-xs font-bold text-on-surface">
                    {language === 'fr' ? 'Analyses 24/7' : 'تحاليل ٢٤/٧'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Pôles & Spécialités */}
          <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container">
            <h4 className="font-bold text-sm text-on-surface mb-2">
              {language === 'fr' ? 'Pôles & Spécialités' : 'الأقسام والتخصصات'}
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {est.specialties.map((spec, i) => (
                <div key={i} className="p-2.5 bg-surface-container-low rounded-xl border border-surface-container flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary text-[18px]">verified</span>
                  <span className="text-xs font-bold text-on-surface truncate">
                    {translateSpecialtyName(spec, language)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Praticiens en vedette */}
          <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-sm text-on-surface">
                {language === 'fr' ? 'Praticiens rattachés' : 'الأطباء المنتسبون'}
              </h4>
              <button onClick={() => setActiveTab('praticiens')} className="text-xs font-bold text-primary hover:underline">
                {language === 'fr' ? `Voir l'équipe (${doctorsInEstablishment.length})` : `عرض الفريق (${doctorsInEstablishment.length})`}
              </button>
            </div>

            <div className="space-y-2">
              {doctorsInEstablishment.map(doc => (
                <div
                  key={doc.id}
                  className="p-3 bg-surface-container-low rounded-xl border border-surface-container flex items-start gap-3"
                >
                  <div className="w-12 h-12 rounded-xl bg-secondary-container text-on-secondary-container flex items-center justify-center font-bold text-xs shrink-0">
                    {doc.initials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h5 className="font-bold text-xs text-on-surface truncate">
                        {translateDoctorTitle(doc.title, language)}
                      </h5>
                      <span className="font-bold text-xs text-primary">{language === 'fr' ? 'Sur RDV' : 'بموعد'}</span>
                    </div>
                    <p className="text-[11px] text-on-surface-variant truncate">
                      {translateSpecialtyName(doc.specialtyName, language)}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <button
                        onClick={() => handleBookWithDoctor(doc)}
                        className="py-1 px-3 bg-primary text-on-primary rounded-lg text-xs font-bold shadow-xs"
                      >
                        {language === 'fr' ? 'Prendre RDV' : 'حجز موعد'}
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Praticiens List */}
      {activeTab === 'praticiens' && (
        <div className="px-4 space-y-2">
          {doctorsInEstablishment.map(doc => (
            <div
              key={doc.id}
              className="p-3 bg-white rounded-xl border border-surface-container shadow-xs flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-11 h-11 rounded-xl bg-secondary-container text-on-secondary-container flex items-center justify-center font-bold text-xs shrink-0">
                  {doc.initials}
                </div>
                <div className="min-w-0">
                  <h5 className="font-bold text-xs text-on-surface truncate">
                    {translateDoctorTitle(doc.title, language)}
                  </h5>
                  <span className="text-[11px] text-on-surface-variant block truncate">
                    {translateSpecialtyName(doc.specialtyName, language)}
                  </span>
                  <span className="text-[10px] text-primary font-semibold">
                    {language === 'fr' ? (
                      doc.nextSlot
                    ) : (
                      (() => {
                        const { prefix, time } = parseSlotParts(doc.nextSlotAr || doc.nextSlot, 'ar');
                        return (
                          <span className="inline-flex items-center gap-1">
                            <span>{prefix}</span>
                            {time && (
                              <span dir="ltr" className="inline-block tabular-nums font-mono font-bold">
                                {time}
                              </span>
                            )}
                          </span>
                        );
                      })()
                    )}
                  </span>
                </div>
              </div>
              <button
                onClick={() => handleBookWithDoctor(doc)}
                className="px-3 py-1.5 bg-primary text-on-primary rounded-lg text-xs font-bold shadow-xs shrink-0"
              >
                {language === 'fr' ? 'Prendre RDV' : 'حجز موعد'}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Tab 3: Services & Équipements */}
      {activeTab === 'services' && (
        <div className="px-4 space-y-3">
          <div className="bg-white p-4 rounded-2xl border border-surface-container space-y-3">
            <h4 className="font-bold text-sm text-on-surface">
              {language === 'fr' ? 'Plateau technique & Services médicaux' : 'التجهيزات والخدمات الطبية'}
            </h4>
            <div className="divide-y divide-surface-container text-xs">
              <div className="py-2.5 flex justify-between items-center">
                <span>{language === 'fr' ? 'Service des Urgences médicales & chirurgicales' : 'قسم الطوارئ الطبية والجراحية'}</span>
                <span className="font-bold text-secondary">{language === 'fr' ? '24h/24 • 7j/7' : '٢٤/٢٤ • ٧/٧'}</span>
              </div>
              <div className="py-2.5 flex justify-between items-center">
                <span>{language === 'fr' ? "Laboratoire d'analyses médicales et de biologie" : 'مختبر التحاليل الطبية والبيولوجية'}</span>
                <span className="font-bold text-secondary">{language === 'fr' ? 'En continu' : 'على مدار الساعة'}</span>
              </div>
              <div className="py-2.5 flex justify-between items-center">
                <span>{language === 'fr' ? 'Imagerie médicale (Échographie Doppler, Radio)' : 'التصوير الطبي (إيكو دوبلر، أشعة)'}</span>
                <span className="font-bold text-secondary">{language === 'fr' ? 'Sur prescription' : 'بناءً على وصفة'}</span>
              </div>
              <div className="py-2.5 flex justify-between items-center">
                <span>{language === 'fr' ? 'Hospitalisation & Soins intensifs' : 'الحجز الاستشفائي والعناية المركزة'}</span>
                <span className="font-bold text-secondary">{language === 'fr' ? 'Chambres équipées' : 'غرف مجهزة'}</span>
              </div>
            </div>
            <p className="text-[11px] text-outline italic pt-1">
              {language === 'fr'
                ? '* Structure conventionnée pour la prise en charge du tiers-payant CNAM & CNASS Mauritanie.'
                : '* منشأة معتمدة لخدمات الدفع المباشر كنام وكناص موريتانيا.'}
            </p>
          </div>
        </div>
      )}

      {/* Floating Bottom Primary Booking CTA */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-surface-container-lowest/95 backdrop-blur-md border-t border-surface-container shadow-xl p-3 pb-safe">
        <div className="max-w-md mx-auto">
          <button
            onClick={() => {
              if (doctorsInEstablishment.length > 0) {
                handleBookWithDoctor(doctorsInEstablishment[0]);
              } else {
                navigateTo('doctor-list');
              }
            }}
            className="w-full h-12 bg-primary hover:bg-primary-container text-on-primary rounded-xl font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-transform active:scale-[0.99]"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">calendar_add_on</span>
            <span>{language === 'fr' ? 'Prendre rendez-vous dans cet établissement' : 'حجز موعد في هذه المنشأة'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
