import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { QrCodeView } from '../common/QrCodeView';
import { Appointment } from '../../types';
import {
  translateDoctorTitle,
  translateSpecialtyName,
  translateEstablishmentName,
  translateReason,
  translateDateFormatted,
} from '../../translations';

export const AppointmentsScreen: React.FC = () => {
  const {
    t,
    language,
    upcomingAppointments,
    pastAppointments,
    cancelledAppointments,
    cancelAppointment,
    navigateTo,
    setSelectedSpecialtyId,
    setSelectedSubspecialtyName,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'upcoming' | 'past' | 'cancelled'>('upcoming');
  const [showQrMap, setShowQrMap] = useState<Record<string, boolean>>({});
  const [appointmentToCancel, setAppointmentToCancel] = useState<Appointment | null>(null);

  const toggleQr = (id: string) => {
    setShowQrMap(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleReprendreRdv = (specialtyId: string, sub: string) => {
    setSelectedSpecialtyId(specialtyId);
    setSelectedSubspecialtyName(sub);
    navigateTo('doctor-list');
  };

  const handleOpenItinerary = (apt: Appointment) => {
    const destination = encodeURIComponent(`${apt.establishmentName} ${apt.establishmentAddress} Nouakchott Mauritanie`);
    const mapsUrl = `https://www.google.com/maps/dir/?api=1&destination=${destination}`;
    window.open(mapsUrl, '_blank', 'noopener,noreferrer');
  };

  const handleConfirmCancel = () => {
    if (appointmentToCancel) {
      cancelAppointment(appointmentToCancel.id);
      setAppointmentToCancel(null);
    }
  };

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Title & New Appointment Action */}
      <div className="px-4 pt-3 pb-2 flex items-start justify-between gap-3">
        <div className="flex flex-col min-w-0">
          <h1 className="text-2xl font-bold text-on-surface tracking-tight">
            {t.myAppointmentsTitle}
          </h1>
          <p className="text-xs text-on-surface-variant truncate">
            {t.myAppointmentsSubtitle}
          </p>
        </div>
        <button
          onClick={() => navigateTo('specialties')}
          className="inline-flex items-center gap-1 px-3 py-1.5 bg-primary text-on-primary rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-transform shrink-0 cursor-pointer"
          type="button"
        >
          <span className="material-symbols-outlined text-[16px]">add</span>
          <span>{t.newBtn}</span>
        </button>
      </div>

      {/* Segmented Filter Tabs */}
      <div className="px-4 my-2">
        <div className="flex items-center gap-1 bg-surface-container p-1 rounded-xl border border-surface-container">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'upcoming'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
            type="button"
          >
            <span>{t.tabUpcoming}</span>
            <span
              className={`inline-flex items-center justify-center px-1.5 py-0.2 rounded-full text-[10px] ${
                activeTab === 'upcoming' ? 'bg-secondary-container text-on-secondary-container' : 'bg-surface-container-high'
              }`}
            >
              {upcomingAppointments.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('past')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'past'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
            type="button"
          >
            <span>{t.tabPast}</span>
            <span className="inline-flex items-center justify-center px-1.5 py-0.2 rounded-full bg-surface-container-high text-on-surface-variant text-[10px]">
              {pastAppointments.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('cancelled')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'cancelled'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
            type="button"
          >
            <span>{language === 'fr' ? 'Annulés' : 'الملغاة'}</span>
            <span className="inline-flex items-center justify-center px-1.5 py-0.2 rounded-full bg-surface-container-high text-on-surface-variant text-[10px]">
              {cancelledAppointments.length}
            </span>
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="px-4 flex flex-col gap-3">
        {/* UPCOMING TAB */}
        {activeTab === 'upcoming' && (
          <div className="flex flex-col gap-3">
            {upcomingAppointments.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-8 bg-surface-container-lowest rounded-2xl border border-surface-container text-center">
                <div className="w-14 h-14 rounded-full bg-secondary-container flex items-center justify-center text-primary mb-3">
                  <span className="material-symbols-outlined text-[28px]">calendar_today</span>
                </div>
                <h3 className="font-bold text-sm text-on-surface">{t.noAppointmentTitle}</h3>
                <p className="text-xs text-on-surface-variant max-w-xs mt-1 leading-relaxed">
                  {t.noAppointmentDesc}
                </p>
                <button
                  onClick={() => navigateTo('specialties')}
                  className="mt-4 px-4 py-2 bg-primary text-on-primary rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-transform"
                  type="button"
                >
                  {t.bookAppointmentBtn}
                </button>
              </div>
            ) : (
              upcomingAppointments.map(apt => (
                <div
                  key={apt.id}
                  className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container flex flex-col gap-3 animate-fadeIn"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-primary-container text-on-primary flex items-center justify-center shrink-0">
                        <span className="material-symbols-outlined text-[20px]">medical_services</span>
                      </div>
                      <div className="flex flex-col min-w-0">
                        <h3 className="font-bold text-sm text-on-surface truncate">{translateDoctorTitle(apt.practitionerName, language)}</h3>
                        <p className="text-xs text-primary font-semibold truncate">{translateSpecialtyName(apt.practitionerSpecialty, language)}</p>
                        <p className="text-[11px] text-on-surface-variant truncate">{translateEstablishmentName(apt.establishmentName, language)}</p>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold shrink-0">
                      {language === 'fr' ? 'Confirmé' : 'مؤكد'}
                    </span>
                  </div>

                  <div className="p-2.5 bg-surface-container-low rounded-xl flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-primary text-[18px]">calendar_month</span>
                      <div>
                        <span className="font-bold text-on-surface block">{translateDateFormatted(apt.dateFormatted, language)}</span>
                        <span className="text-on-surface-variant text-[11px]">
                          {language === 'fr' ? `Horaire : ` : `التوقيت : `}
                          <span dir="ltr" className="inline-block tabular-nums font-mono font-semibold">{apt.time}</span>
                        </span>
                      </div>
                    </div>
                    <div className="text-end">
                      <span className="text-[10px] text-outline block">
                        {language === 'fr' ? 'Couverture' : 'التأمين'}
                      </span>
                      <span className="font-bold text-secondary">
                        {apt.insuranceType && apt.insuranceType !== 'NONE' ? apt.insuranceType : (language === 'fr' ? 'Conventionné' : 'معتمد')}
                      </span>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="flex flex-col gap-2 pt-1 border-t border-surface-container/60">
                    <button
                      onClick={() => toggleQr(apt.id)}
                      className="w-full py-2 bg-secondary-container text-on-secondary-container rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 active:bg-secondary-container/80 transition-colors cursor-pointer"
                      type="button"
                    >
                      <span className="material-symbols-outlined text-[16px]">qr_code_2</span>
                      <span>
                        {showQrMap[apt.id]
                          ? (language === 'fr' ? 'Masquer Pass QR' : 'إخفاء رمز الدخول (QR)')
                          : (language === 'fr' ? 'Afficher Pass QR & Justificatif' : 'عرض رمز الدخول والإفادة (QR)')}
                      </span>
                    </button>

                    {showQrMap[apt.id] && (
                      <div className="p-3 bg-surface-container-low rounded-xl flex flex-col items-center gap-2 animate-fadeIn">
                        <QrCodeView
                          value={apt.qrCodeData || `RIMEDIC://${apt.referenceNumber}`}
                          size={150}
                        />
                        <span className="text-xs font-mono font-bold text-primary tracking-wider">
                          {apt.referenceNumber}
                        </span>
                        <span className="text-[10px] text-outline">
                          {language === 'fr'
                            ? `Pass numérique officiel pour l'accueil de ${translateEstablishmentName(apt.establishmentName, language)}`
                            : `بطاقة الدخول الرقمية المعتمدة لاستقبال ${translateEstablishmentName(apt.establishmentName, language)}`}
                        </span>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-2 pt-0.5">
                      <button
                        onClick={() => handleOpenItinerary(apt)}
                        className="py-2.5 px-2 bg-surface-container hover:bg-surface-container-high text-on-surface rounded-xl text-xs font-semibold flex items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer"
                        type="button"
                      >
                        <span className="material-symbols-outlined text-[16px] text-primary">near_me</span>
                        <span>{language === 'fr' ? "Voir l'itinéraire" : "الاتجاهات"}</span>
                      </button>

                      <button
                        onClick={() => setAppointmentToCancel(apt)}
                        className="py-2.5 px-2 bg-surface-container hover:bg-red-50 text-error rounded-xl text-xs font-semibold flex items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer"
                        type="button"
                      >
                        <span className="material-symbols-outlined text-[16px]">cancel</span>
                        <span>{language === 'fr' ? 'Annuler RDV' : 'إلغاء الموعد'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* PAST TAB */}
        {activeTab === 'past' && (
          <div className="flex flex-col gap-3">
            {pastAppointments.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-2xl border border-surface-container">
                <span className="material-symbols-outlined text-[32px] text-outline mb-1 block">history</span>
                <p className="text-xs text-on-surface-variant">
                  {language === 'fr' ? "Aucun rendez-vous passé dans l'historique." : "لا توجد مواعيد سابقة في السجل."}
                </p>
              </div>
            ) : (
              pastAppointments.map(apt => (
                <div
                  key={apt.id}
                  className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container flex flex-col gap-2.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-surface-container flex items-center justify-center shrink-0 text-on-surface-variant">
                        <span className="material-symbols-outlined text-[20px]">medical_services</span>
                      </div>
                      <div className="flex flex-col min-w-0">
                        <h3 className="font-bold text-sm text-on-surface truncate">{translateDoctorTitle(apt.practitionerName, language)}</h3>
                        <p className="text-xs text-on-surface-variant truncate">{translateEstablishmentName(apt.establishmentName, language)}</p>
                        <div className="flex items-center gap-1 mt-0.5 text-on-surface-variant text-[11px]">
                          <span className="material-symbols-outlined text-[13px]">calendar_today</span>
                          <span>
                            {translateDateFormatted(apt.dateFormatted, language)} {language === 'fr' ? 'à ' : 'عند '}
                            <span dir="ltr" className="inline-block tabular-nums font-mono font-semibold">{apt.time}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-surface-container-high text-on-surface-variant text-[10px] font-bold shrink-0">
                      <span className="material-symbols-outlined text-[12px] text-primary">check_circle</span>
                      <span>{language === 'fr' ? 'Honoré' : 'مكتمل'}</span>
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-surface-container/60">
                    <span className="text-xs text-on-surface-variant">{translateReason(apt.reason, language)}</span>
                    <button
                      onClick={() => handleReprendreRdv('odontologie', 'Orthodontistes')}
                      className="px-3 py-1.5 bg-surface-container-high text-primary rounded-xl text-xs font-bold active:bg-surface-container transition-colors cursor-pointer"
                      type="button"
                    >
                      {t.retakeAppointment}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* CANCELLED TAB */}
        {activeTab === 'cancelled' && (
          <div className="flex flex-col gap-3">
            {cancelledAppointments.length === 0 ? (
              <div className="p-8 text-center bg-white rounded-2xl border border-surface-container">
                <span className="material-symbols-outlined text-[32px] text-outline mb-1 block">check_circle</span>
                <p className="text-xs text-on-surface-variant">
                  {language === 'fr' ? "Aucun rendez-vous annulé." : "لا توجد مواعيد ملغاة."}
                </p>
              </div>
            ) : (
              cancelledAppointments.map(apt => (
                <div
                  key={apt.id}
                  className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container flex flex-col gap-2 opacity-80"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-on-surface">{translateDoctorTitle(apt.practitionerName, language)}</span>
                    <span className="px-2 py-0.5 rounded-full bg-error-container text-on-error-container text-[10px] font-bold">
                      {language === 'fr' ? 'Annulé' : 'ملغى'}
                    </span>
                  </div>
                  <p className="text-xs text-on-surface-variant">
                    {translateEstablishmentName(apt.establishmentName, language)} • {translateDateFormatted(apt.dateFormatted, language)} {language === 'fr' ? 'à ' : 'عند '}
                    <span dir="ltr" className="inline-block tabular-nums font-mono font-semibold">{apt.time}</span>
                  </p>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* Confirmation Modal pour Annulation (Exigence 11) */}
      {appointmentToCancel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-surface-container text-start animate-scaleUp">
            <div className="w-12 h-12 rounded-full bg-red-100 text-error flex items-center justify-center mb-3">
              <span className="material-symbols-outlined text-[28px]">event_busy</span>
            </div>
            <h3 className="font-bold text-base text-on-surface mb-1">
              {language === 'fr' ? 'Voulez-vous vraiment annuler ce rendez-vous ?' : 'هل أنت متأكد من إلغاء هذا الموعد؟'}
            </h3>
            <p className="text-xs text-on-surface-variant mb-4 leading-relaxed">
              {language === 'fr' ? (
                `Consultation auprès de ${translateDoctorTitle(appointmentToCancel.practitionerName, 'fr')} le ${appointmentToCancel.dateFormatted} à ${appointmentToCancel.time}. Le créneau sera libéré sans pénalité.`
              ) : (
                <>
                  الموعد لدى {translateDoctorTitle(appointmentToCancel.practitionerName, 'ar')} في {translateDateFormatted(appointmentToCancel.dateFormatted, 'ar')} عند{' '}
                  <span dir="ltr" className="inline-block tabular-nums font-mono font-bold">{appointmentToCancel.time}</span>. سيتم تحرير الموعد دون رسوم.
                </>
              )}
            </p>
            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={handleConfirmCancel}
                className="w-full py-2.5 bg-error hover:bg-error/95 text-white text-xs font-bold rounded-xl shadow-xs active:scale-95 transition-transform cursor-pointer"
              >
                {language === 'fr' ? 'Annuler le rendez-vous' : 'تأكيد إلغاء الموعد'}
              </button>
              <button
                type="button"
                onClick={() => setAppointmentToCancel(null)}
                className="w-full py-2.5 bg-surface-container hover:bg-surface-container-high text-on-surface text-xs font-bold rounded-xl active:scale-95 transition-transform cursor-pointer"
              >
                {language === 'fr' ? 'Conserver le rendez-vous' : 'الاحتفاظ بالموعد'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
