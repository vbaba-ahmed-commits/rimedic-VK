import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PRACTITIONERS_DATA, SPECIALTIES_DATA } from '../../data/mockData';
import { Practitioner } from '../../types';
import { translateNeighborhood, translateSubspecialty, translateSlotText, parseSlotParts } from '../../translations';

export const DoctorListScreen: React.FC = () => {
  const {
    language,
    navigateTo,
    setSelectedPractitioner,
    selectedSpecialtyId,
    selectedSubspecialtyName,
    setSelectedSpecialtyId,
    isRtl
  } = useApp();

  const [search, setSearch] = useState('');
  const [filterNeighborhood, setFilterNeighborhood] = useState<string>('');
  const [filterCnamOnly, setFilterCnamOnly] = useState<boolean>(false);
  const [filterTodayOnly, setFilterTodayOnly] = useState<boolean>(false);

  // Find active specialty info
  const currentSpecialty = SPECIALTIES_DATA.find(s => s.id === selectedSpecialtyId) || SPECIALTIES_DATA[0];

  const neighborhoods = ['Tevragh Zeina', 'Ksar', 'Arafat', 'Dar Naïm', 'Sebkha', 'Toujounine', 'El Mina', 'Teyarett', 'Riyadh'];

  const filteredDoctors = PRACTITIONERS_DATA.filter(doc => {
    // Filter by specialty if selected
    if (selectedSpecialtyId) {
      const isDiabeteTarget = selectedSpecialtyId === 'diabetologie' || selectedSpecialtyId === 'endocrinologie';
      const isDocDiabete = doc.specialtyId === 'diabetologie' || doc.specialtyId === 'endocrinologie';
      if (isDiabeteTarget) {
        if (!isDocDiabete) return false;
      } else if (doc.specialtyId !== selectedSpecialtyId) {
        return false;
      }
    }

    // Filter by search query with accent and plural resilience
    if (search.trim()) {
      const normalize = (s: string) => s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
      const q = normalize(search);
      const qStem = q.endsWith('s') && q.length > 3 ? q.slice(0, -1) : q;
      const haystack = normalize(
        `${doc.title} ${doc.titleAr} ${doc.neighborhood} ${doc.establishmentName} ${doc.specialtyName} ${doc.subspecialtyNames.join(' ')} ${doc.bio} ${doc.bioAr} ${doc.education}`
      );
      const matchesSearch = haystack.includes(q) || haystack.includes(qStem);
      if (!matchesSearch) return false;
    }

    // Filter by neighborhood if selected
    if (filterNeighborhood && doc.neighborhood !== filterNeighborhood) {
      return false;
    }

    // CNAM conventioned only
    if (filterCnamOnly && !doc.cnamConventioned) return false;

    // Available today only
    if (filterTodayOnly && !doc.nextSlot.includes("Aujourd'hui")) return false;

    return true;
  });

  const handleSelectDoctor = (doc: Practitioner, action: 'profile' | 'book') => {
    setSelectedPractitioner(doc);
    navigateTo('doctor-profile', { doctor: doc });
  };

  const displaySpecialtyTitle = selectedSubspecialtyName
    ? (language === 'fr' ? selectedSubspecialtyName : translateSubspecialty(selectedSubspecialtyName, language))
    : (language === 'fr' ? currentSpecialty.name : currentSpecialty.nameAr);

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Breadcrumb Navigation */}
      <div className="px-4 pt-3 pb-2">
        <div className="flex items-center gap-1.5 text-xs text-on-surface-variant mb-1">
          <button
            onClick={() => navigateTo('specialties')}
            className="inline-flex items-center gap-1 font-semibold text-secondary hover:text-primary transition-colors"
            type="button"
          >
            <span className={`material-symbols-outlined text-[16px] ${isRtl ? 'rotate-180' : ''}`}>
              arrow_back
            </span>
            <span>{language === 'fr' ? 'Spécialités' : 'التخصصات'}</span>
          </button>
          <span className="text-outline-variant">›</span>
          <span className="font-semibold text-on-surface-variant">
            {language === 'fr' ? currentSpecialty.name : currentSpecialty.nameAr}
          </span>
          {selectedSubspecialtyName && (
            <>
              <span className="text-outline-variant">›</span>
              <span className="font-bold text-primary truncate max-w-[120px]">
                {language === 'fr' ? selectedSubspecialtyName : translateSubspecialty(selectedSubspecialtyName, language)}
              </span>
            </>
          )}
        </div>

        <h1 className="text-2xl font-bold text-on-surface tracking-tight">
          {displaySpecialtyTitle} {language === 'fr' ? 'à Nouakchott' : 'في نواكشوط'}
        </h1>

        <p className="text-xs text-on-surface-variant flex items-center gap-1.5 mt-1">
          <span className="w-2 h-2 rounded-full bg-primary inline-block"></span>
          <span>
            {filteredDoctors.length} {language === 'fr' ? 'praticiens répertoriés' : 'أطباء مسجلين'}
          </span>
          <span className="text-outline-variant">•</span>
          <span className="text-tertiary font-bold">
            {language === 'fr' ? 'Données de démonstration' : 'بيانات تجريبية'}
          </span>
        </p>
      </div>

      {/* Search Input Bar */}
      <div className="px-4 py-1.5">
        <div className="relative flex items-center gap-2">
          <div className="relative flex-1">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline text-[20px]">
              search
            </span>
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={
                language === 'fr'
                  ? `Rechercher un ${currentSpecialty.name.toLowerCase()}...`
                  : `ابحث عن طبيب في ${currentSpecialty.nameAr}...`
              }
              className="w-full h-11 pl-10 pr-4 rounded-xl bg-surface-container-lowest text-on-surface placeholder:text-outline text-sm shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-surface-container focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
          </div>
          <button
            onClick={() => {
              setFilterCnamOnly(!filterCnamOnly);
            }}
            aria-label={language === 'fr' ? "Filtres" : "تصفية"}
            className={`h-11 w-11 flex-shrink-0 flex items-center justify-center rounded-xl border border-surface-container transition-all ${
              filterCnamOnly ? 'bg-primary text-on-primary' : 'bg-surface-container text-on-surface-variant'
            }`}
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">tune</span>
          </button>
        </div>
      </div>

      {/* Filter Horizontal Chips */}
      <div className="px-4 py-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {/* Neighborhood chips */}
        <button
          onClick={() => setFilterNeighborhood('')}
          className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
            filterNeighborhood === ''
              ? 'bg-primary text-on-primary shadow-xs'
              : 'bg-surface-container text-on-surface-variant hover:text-primary'
          }`}
          type="button"
        >
          {language === 'fr' ? 'Tous quartiers' : 'كل الأحياء'}
        </button>

        {neighborhoods.map(nh => (
          <button
            key={nh}
            onClick={() => setFilterNeighborhood(filterNeighborhood === nh ? '' : nh)}
            className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-bold transition-all ${
              filterNeighborhood === nh
                ? 'bg-primary text-on-primary shadow-xs'
                : 'bg-surface-container-lowest text-on-surface-variant hover:bg-surface-container border border-surface-container'
            }`}
            type="button"
          >
            {translateNeighborhood(nh, language)}
          </button>
        ))}

        {/* CNAM filter chip */}
        <button
          onClick={() => setFilterCnamOnly(!filterCnamOnly)}
          className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1 ${
            filterCnamOnly
              ? 'bg-secondary text-on-secondary shadow-xs'
              : 'bg-surface-container-lowest text-on-surface-variant hover:bg-surface-container border border-surface-container'
          }`}
          type="button"
        >
          <span className="material-symbols-outlined text-[14px]">health_and_safety</span>
          <span>CNAM / CNASS</span>
        </button>

        {/* Today filter chip */}
        <button
          onClick={() => setFilterTodayOnly(!filterTodayOnly)}
          className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1 ${
            filterTodayOnly
              ? 'bg-primary text-on-primary shadow-xs'
              : 'bg-surface-container-lowest text-on-surface-variant hover:bg-surface-container border border-surface-container'
          }`}
          type="button"
        >
          <span className="material-symbols-outlined text-[14px]">schedule</span>
          <span>{language === 'fr' ? "Dispo aujourd'hui" : 'متاح اليوم'}</span>
        </button>
      </div>

      {/* Practitioner Cards List */}
      <div className="px-4 flex flex-col gap-3 mt-1">
        {filteredDoctors.length === 0 ? (
          <div className="p-8 text-center bg-surface-container-lowest rounded-2xl border border-surface-container flex flex-col items-center gap-2">
            <span className="material-symbols-outlined text-[40px] text-outline">search_off</span>
            <p className="font-bold text-sm text-on-surface">
              {language === 'fr' ? 'Aucun praticien ne correspond à vos filtres' : 'لا يوجد أطباء يطابقون خيارات البحث'}
            </p>
            <p className="text-xs text-on-surface-variant">
              {language === 'fr' ? 'Essayez de réinitialiser les filtres de quartier ou de CNAM.' : 'يرجى تجربة إعادة ضبط الحي أو معايير التأمين.'}
            </p>
            <button
              onClick={() => {
                setFilterNeighborhood('');
                setFilterCnamOnly(false);
                setFilterTodayOnly(false);
                setSearch('');
              }}
              className="mt-2 px-4 py-2 rounded-xl bg-primary text-on-primary text-xs font-bold shadow-xs hover:bg-primary-container transition-all"
              type="button"
            >
              {language === 'fr' ? 'Réinitialiser tous les filtres' : 'إعادة ضبط كل الفلاتر'}
            </button>
          </div>
        ) : (
          filteredDoctors.map(doc => (
            <div
              key={doc.id}
              className="bg-surface-container-lowest rounded-2xl p-4 shadow-[0_2px_12px_rgba(0,0,0,0.04)] border border-surface-container hover:border-primary/40 transition-all flex flex-col gap-3"
            >
              {/* Top row: Avatar, Info, Rating */}
              <div className="flex items-start gap-3.5">
                <div
                  onClick={() => handleSelectDoctor(doc, 'profile')}
                  className="w-14 h-14 rounded-2xl bg-surface-container-high text-primary flex items-center justify-center font-bold text-lg shrink-0 cursor-pointer shadow-xs hover:scale-105 transition-transform"
                >
                  <span className="material-symbols-outlined text-[30px]">person</span>
                </div>

                <div className="flex flex-col min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1">
                    <h3
                      onClick={() => handleSelectDoctor(doc, 'profile')}
                      className="font-bold text-base text-on-surface hover:text-primary transition-colors cursor-pointer truncate"
                    >
                      {language === 'fr' ? doc.title : doc.titleAr}
                    </h3>
                    <div className="flex items-center gap-1 shrink-0 text-xs font-bold text-tertiary">
                      <span className="material-symbols-outlined text-[15px]">star</span>
                      <span>{doc.rating}</span>
                      <span className="text-[10px] text-outline font-normal">({doc.reviewsCount})</span>
                    </div>
                  </div>

                  <p className="text-xs font-semibold text-primary mt-0.5 truncate">
                    {language === 'fr' ? doc.specialtyName : doc.specialtyNameAr}
                    {doc.subspecialtyNames.length > 0 && ` • ${language === 'fr' ? doc.subspecialtyNames[0] : translateSubspecialty(doc.subspecialtyNames[0], language)}`}
                  </p>

                  <div className="flex items-center gap-1 text-xs text-on-surface-variant mt-1">
                    <span className="material-symbols-outlined text-[15px] shrink-0 text-outline">location_on</span>
                    <span className="truncate">{doc.establishmentName}, {translateNeighborhood(doc.neighborhood, language)}</span>
                  </div>
                </div>
              </div>

              {/* Bio snippet */}
              <p className="text-xs text-on-surface-variant line-clamp-2 leading-relaxed bg-surface-container-low/40 p-2.5 rounded-xl">
                {language === 'fr' ? doc.bio : doc.bioAr}
              </p>

              {/* Badges & Meta info */}
              <div className="flex items-center justify-between flex-wrap gap-2 pt-1 border-t border-surface-container">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {doc.cnamConventioned && (
                    <span className="px-2 py-0.5 rounded-md bg-secondary-container text-on-secondary-container text-[11px] font-bold flex items-center gap-1">
                      <span className="material-symbols-outlined text-[13px]">health_and_safety</span>
                      <span>CNAM & CNASS</span>
                    </span>
                  )}
                  <span className="px-2 py-0.5 rounded-md bg-surface-container text-on-surface-variant text-[11px] font-semibold">
                    {language === 'fr' ? 'Secteur conventionné' : 'قطاع معتمد'}
                  </span>
                </div>

                <div className="text-xs font-bold text-primary flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                  {language === 'fr' ? (
                    <span>{doc.nextSlot}</span>
                  ) : (
                    (() => {
                      const { prefix, time } = parseSlotParts(doc.nextSlotAr || doc.nextSlot, 'ar');
                      return (
                        <span className="inline-flex items-center gap-1">
                          <span>{prefix}</span>
                          {time && (
                            <span dir="ltr" className="inline-block tabular-nums font-mono font-bold">
                              {time}
                            </span>
                          )}
                        </span>
                      );
                    })()
                  )}
                </div>
              </div>

              {/* Action Buttons: Voir Profil & Prendre RDV */}
              <div className="grid grid-cols-2 gap-2 mt-0.5">
                <button
                  onClick={() => handleSelectDoctor(doc, 'profile')}
                  className="h-10 px-3 rounded-xl bg-surface-container text-on-surface text-xs font-bold hover:bg-surface-container-high transition-colors flex items-center justify-center gap-1"
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">visibility</span>
                  <span>{language === 'fr' ? 'Voir le profil' : 'عرض الملف'}</span>
                </button>

                <button
                  onClick={() => handleSelectDoctor(doc, 'book')}
                  className="h-10 px-3 rounded-xl bg-primary text-on-primary text-xs font-bold shadow-md shadow-primary/20 hover:bg-primary-container active:scale-[0.98] transition-all flex items-center justify-center gap-1"
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">calendar_add_on</span>
                  <span>{language === 'fr' ? 'Prendre RDV' : 'حجز موعد'}</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
