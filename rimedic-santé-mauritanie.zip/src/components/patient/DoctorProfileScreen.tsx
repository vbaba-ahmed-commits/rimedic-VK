import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { PRACTITIONERS_DATA, ESTABLISHMENTS_DATA } from '../../data/mockData';
import { Practitioner } from '../../types';
import { translateNeighborhood } from '../../translations';

export const DoctorProfileScreen: React.FC = () => {
  const {
    language,
    navigateTo,
    selectedPractitioner,
    selectedEstablishment,
    bookAppointment,
    patient,
    practitionerProfile,
    showToast,
    isRtl
  } = useApp();

  const doc = selectedPractitioner || PRACTITIONERS_DATA[0];
  const establishment = ESTABLISHMENTS_DATA.find(e => e.id === doc.establishmentId) || selectedEstablishment;

  const [activeTab, setActiveTab] = useState<'disponibilites' | 'presentation' | 'conventions'>('disponibilites');
  const [selectedReason, setSelectedReason] = useState<number>(0);

  const getTodayISOString = () => {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };

  // Dynamic calendar navigation state (Requirements 7 & 8)
  const [calendarDate, setCalendarDate] = useState<Date>(() => new Date());
  const [selectedDay, setSelectedDay] = useState<string>(() => getTodayISOString());
  const [selectedTime, setSelectedTime] = useState<string>('10:30');
  const [showSummaryModal, setShowSummaryModal] = useState<boolean>(false);

  // Consultation reasons based on specialty
  const getConsultationReasons = (specialtyId: string, baseFee: number) => {
    switch (specialtyId) {
      case 'odontologie':
        return [
          {
            title: language === 'fr' ? 'Première consultation dentaire' : 'أول كشف أسنان',
            desc: language === 'fr' ? 'Bilan bucco-dentaire, examen complet • 40 min' : 'فحص شامل للأسنان والفكين • ٤٠ دقيقة',
            fee: baseFee,
          },
          {
            title: language === 'fr' ? 'Détartrage & Soins dentaires' : 'تنظيف الأسنان وعلاج التسوس',
            desc: language === 'fr' ? 'Détartrage ultrasonique et polissage • 30 min' : 'إزالة الجير وتنظيف شامل • ٣٠ دقيقة',
            fee: Math.round(baseFee * 0.8),
          },
          {
            title: language === 'fr' ? 'Consultation orthodontie ou prothèse' : 'استشارة تقويم أو زراعة',
            desc: language === 'fr' ? 'Évaluation esthétique et devis de traitement • 45 min' : 'تقييم التقويم وخطة العلاج • ٤٥ دقيقة',
            fee: baseFee,
          }
        ];
      case 'cardiologie':
        return [
          {
            title: language === 'fr' ? 'Consultation cardiologie & ECG' : 'كشف القلب مع تخطيط ECG',
            desc: language === 'fr' ? 'Bilan cardiaque complet, tension & électrocardiogramme • 40 min' : 'فحص سريري وتخطيط كهربائي للقلب • ٤٠ دقيقة',
            fee: baseFee,
          },
          {
            title: language === 'fr' ? 'Échocardiographie Doppler' : 'تخطيط صدى القلب دوبلر',
            desc: language === 'fr' ? 'Exploration ultrasonore des cavités cardiaques • 45 min' : 'فحص القلب بالموجات فوق الصوتية • ٤٥ دقيقة',
            fee: baseFee + 500,
          },
          {
            title: language === 'fr' ? 'Contrôle hypertension artérielle' : 'متابعة ضغط الدم',
            desc: language === 'fr' ? 'Ajustement du traitement et bilan tensionnel • 30 min' : 'متابعة العلاج وفحص الضغط • ٣٠ دقيقة',
            fee: Math.round(baseFee * 0.75),
          }
        ];
      case 'pediatrie':
        return [
          {
            title: language === 'fr' ? 'Consultation pédiatrique générale' : 'كشف أطفال عام',
            desc: language === 'fr' ? 'Bilan de santé, croissance et alimentation • 30 min' : 'فحص شامل لصحة ونمو الطفل • ٣٠ دقيقة',
            fee: baseFee,
          },
          {
            title: language === 'fr' ? 'Bilan vaccinal & Suivi nourrisson' : 'متابعة الرضع والتطعيمات',
            desc: language === 'fr' ? 'Contrôle du carnet de santé et développement • 30 min' : 'فحص النمو والتطعيمات الوطنية • ٣٠ دقيقة',
            fee: Math.round(baseFee * 0.8),
          }
        ];
      default:
        return [
          {
            title: language === 'fr' ? `Première consultation (${doc.specialtyName})` : `أول استشارة (${doc.specialtyNameAr})`,
            desc: language === 'fr' ? 'Bilan initial approfondi et diagnostic • 35 min' : 'فحص أولي شامل وتشخيص • ٣٥ دقيقة',
            fee: baseFee,
          },
          {
            title: language === 'fr' ? 'Consultation de suivi & Traitement' : 'استشارة متابعة وعلاج',
            desc: language === 'fr' ? 'Contrôle de l\'évolution et renouvellement • 25 min' : 'متابعة الاستجابة وتعديل الوصفة • ٢٥ دقيقة',
            fee: Math.round(baseFee * 0.75),
          }
        ];
    }
  };

  const consultationReasons = getConsultationReasons(doc.specialtyId, doc.fee);
  const currentFee = consultationReasons[selectedReason]?.fee || doc.fee;

  // Month navigation handlers
  const handlePrevMonth = () => {
    setCalendarDate(prev => new Date(prev.getFullYear(), prev.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCalendarDate(prev => new Date(prev.getFullYear(), prev.getMonth() + 1, 1));
  };

  const monthYearLabel = useMemo(() => {
    const raw = calendarDate.toLocaleDateString(language === 'fr' ? 'fr-FR' : 'ar-MR', {
      month: 'long',
      year: 'numeric'
    });
    return raw.charAt(0).toUpperCase() + raw.slice(1);
  }, [calendarDate, language]);

  const monthDays = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const year = calendarDate.getFullYear();
    const month = calendarDate.getMonth();
    const numDays = new Date(year, month + 1, 0).getDate();

    return Array.from({ length: numDays }, (_, i) => {
      const dayNum = i + 1;
      const d = new Date(year, month, dayNum);
      const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
      const dayOfWeek = d.getDay(); // 0 is Sunday

      // Date is past if strictly before today
      const isPast = d < todayStart;
      const isToday = d.getTime() === todayStart.getTime();

      // Check doctor's custom schedule from practitionerProfile if this practitioner
      const isThisDoctor = doc.id === practitionerProfile.id || doc.id === 'dr-mohamed-ould-ahmed';
      const scheduleDay = isThisDoctor && practitionerProfile.schedule ? practitionerProfile.schedule.find(s => s.dayOfWeek === dayOfWeek) : null;
      const isClosed = scheduleDay ? !scheduleDay.active : dayOfWeek === 0;
      // Some days are fully booked
      const isFull = !isPast && !isClosed && (dayNum % 5 === 0);

      const dayLabel = d.toLocaleDateString(language === 'fr' ? 'fr-FR' : 'ar-MR', { weekday: 'short' });
      const availableCount = (isPast || isClosed || isFull) ? 0 : ((dayNum * 2) % 4) + 3;

      let slotsText = `${availableCount} crén.`;
      if (isPast) slotsText = language === 'fr' ? 'Passé' : 'مضى';
      else if (isClosed) slotsText = language === 'fr' ? 'Fermé' : 'مغلق';
      else if (isFull) slotsText = language === 'fr' ? 'Complet' : 'مكتمل';

      return {
        date: dateString,
        label: dayLabel,
        num: String(dayNum).padStart(2, '0'),
        isPast,
        isToday,
        isClosed,
        isFull,
        availableCount,
        slotsText
      };
    });
  }, [calendarDate, language]);

  // Synchronize selectedDay when month changes to pick the first available day
  useEffect(() => {
    const currentInMonth = monthDays.find(d => d.date === selectedDay);
    if (!currentInMonth || currentInMonth.isPast || currentInMonth.isClosed || currentInMonth.isFull) {
      const firstAvailable = monthDays.find(d => !d.isPast && !d.isClosed && !d.isFull);
      if (firstAvailable) {
        setSelectedDay(firstAvailable.date);
      } else {
        const firstNonPast = monthDays.find(d => !d.isPast);
        if (firstNonPast) {
          setSelectedDay(firstNonPast.date);
        } else if (monthDays.length > 0) {
          setSelectedDay(monthDays[0].date);
        }
      }
    }
  }, [monthDays, selectedDay]);

  // Slots generation strictly linked to selectedDay
  const selectedDayInfo = monthDays.find(d => d.date === selectedDay) || monthDays[0];

  const currentSlots = useMemo(() => {
    if (!selectedDayInfo || selectedDayInfo.isPast || selectedDayInfo.isClosed || selectedDayInfo.isFull) {
      return { morning: [], afternoon: [] };
    }

    const now = new Date();
    const dayNum = parseInt(selectedDayInfo.num, 10);
    const isToday = selectedDayInfo.isToday;

    const isSlotPassed = (timeStr: string) => {
      if (!isToday) return false;
      const [h, m] = timeStr.split(':').map(Number);
      return h < now.getHours() || (h === now.getHours() && m <= now.getMinutes());
    };

    return {
      morning: [
        { time: '09:00', available: !isSlotPassed('09:00') },
        { time: '09:30', available: !isSlotPassed('09:30') && dayNum % 2 !== 0 },
        { time: '10:30', available: !isSlotPassed('10:30') },
        { time: '11:00', available: !isSlotPassed('11:00') && dayNum % 3 !== 0 },
      ],
      afternoon: [
        { time: '15:00', available: !isSlotPassed('15:00') },
        { time: '15:30', available: !isSlotPassed('15:30') },
        { time: '16:00', available: !isSlotPassed('16:00') && dayNum % 2 === 0 },
        { time: '16:30', available: !isSlotPassed('16:30') },
      ]
    };
  }, [selectedDayInfo]);

  // Auto-select first available slot if current selectedTime is not available
  useEffect(() => {
    const allSlots = [...currentSlots.morning, ...currentSlots.afternoon];
    const availableSlots = allSlots.filter(s => s.available);
    if (availableSlots.length > 0) {
      if (!availableSlots.some(s => s.time === selectedTime)) {
        setSelectedTime(availableSlots[0].time);
      }
    } else {
      setSelectedTime('');
    }
  }, [currentSlots, selectedTime]);

  const isDateInvalid = !selectedDayInfo || selectedDayInfo.isPast || selectedDayInfo.isClosed || selectedDayInfo.isFull || !selectedTime;

  // Confirm booking handler
  const handleFinalConfirm = () => {
    if (isDateInvalid) {
      showToast(
        language === 'fr' ? 'Date non réservable' : 'تاريخ غير متاح للحجز',
        language === 'fr' ? 'Impossible de réserver une date passée ou sans créneau disponible.' : 'لا يمكن حجز موعد في تاريخ منقضٍ أو لا تتوفر فيه مواعيد.',
        'warning'
      );
      return;
    }
    const selectedReasonObj = consultationReasons[selectedReason] || consultationReasons[0];
    bookAppointment({
      doctorId: doc.id,
      date: selectedDay,
      time: selectedTime,
      reason: selectedReasonObj.title,
      reasonAr: selectedReasonObj.title,
      fee: currentFee
    });
    setShowSummaryModal(false);
    navigateTo('booking-confirm');
  };

  // Format date display
  const formattedSelectedDay = useMemo(() => {
    try {
      const [y, m, d] = selectedDay.split('-').map(Number);
      return new Date(y, m - 1, d).toLocaleDateString(language === 'fr' ? 'fr-FR' : 'ar-MR', {
        weekday: 'long',
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      });
    } catch {
      return selectedDay;
    }
  }, [selectedDay, language]);

  return (
    <div className="flex flex-col w-full pb-36">
      {/* Context Breadcrumb */}
      <div className="px-4 pt-3 pb-1 flex items-center justify-between gap-2">
        <button
          onClick={() => navigateTo('doctor-list')}
          className="flex items-center gap-1.5 text-xs text-on-surface-variant font-bold hover:text-primary transition-colors cursor-pointer"
          type="button"
        >
          <span className={`material-symbols-outlined text-[16px] text-primary ${isRtl ? 'rotate-180' : ''}`}>
            arrow_back
          </span>
          <span>{language === 'fr' ? doc.specialtyName : doc.specialtyNameAr} • {translateNeighborhood(doc.neighborhood, language) || (language === 'fr' ? 'Nouakchott' : 'نواكشوط')}</span>
        </button>

        <span className="bg-secondary-container text-on-secondary-container text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
          {language === 'fr' ? 'Praticien Vérifié' : 'طبيب معتمد'}
        </span>
      </div>

      {/* Practitioner Header Card */}
      <section className="px-4 mt-1">
        <div className="bg-surface-container-lowest p-4 rounded-2xl shadow-sm border border-surface-container flex flex-col gap-3">
          <div className="flex items-start gap-3.5">
            <div className="relative shrink-0">
              <div className="w-16 h-16 rounded-2xl bg-surface-container-high flex items-center justify-center text-primary font-bold text-lg">
                <span className="material-symbols-outlined text-[36px]">medical_services</span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary flex items-center justify-center shadow-md">
                <span className="material-symbols-outlined text-white text-[14px]">verified</span>
              </div>
            </div>

            <div className="flex flex-col min-w-0 flex-1">
              <h2 className="font-bold text-base text-on-surface truncate">
                {language === 'fr' ? doc.title : doc.titleAr}
              </h2>
              <p className="text-xs font-semibold text-primary mt-0.5">
                {language === 'fr' ? doc.education.split('•')[1] || doc.specialtyName : doc.specialtyNameAr}
              </p>
              <div className="flex items-center gap-1 text-on-surface-variant text-xs mt-1">
                <span className="material-symbols-outlined text-[15px] shrink-0 text-secondary">
                  location_on
                </span>
                <span className="truncate">
                  {doc.establishmentName}, {translateNeighborhood(doc.neighborhood, language)}
                </span>
              </div>
            </div>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <span className="inline-flex items-center gap-1 bg-secondary-container text-on-secondary-container text-[11px] font-bold px-2.5 py-1 rounded-full">
              <span className="material-symbols-outlined text-[14px]">health_and_safety</span>
              <span>{language === 'fr' ? 'Conventionné CNAM & CNASS' : 'معتمد كنام وكناص'}</span>
            </span>
            <span className="inline-flex items-center gap-1 bg-surface-container text-on-surface-variant text-[11px] font-bold px-2.5 py-1 rounded-full">
              <span className="material-symbols-outlined text-[14px]">verified</span>
              <span>{language === 'fr' ? 'Tiers-payant accepté' : 'قبول الدفع الجزئي'}</span>
            </span>
          </div>
        </div>
      </section>

      {/* Segmented Tab Bar */}
      <section className="px-4 mt-3">
        <div className="bg-surface-container-low p-1 rounded-xl flex items-center justify-between gap-1 border border-surface-container">
          <button
            onClick={() => setActiveTab('disponibilites')}
            className={`flex-1 py-2 text-center text-xs font-bold rounded-lg transition-all ${
              activeTab === 'disponibilites'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
            type="button"
          >
            {language === 'fr' ? 'Disponibilités' : 'المواعيد المتاحة'}
          </button>
          <button
            onClick={() => setActiveTab('presentation')}
            className={`flex-1 py-2 text-center text-xs font-bold rounded-lg transition-all ${
              activeTab === 'presentation'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
            type="button"
          >
            {language === 'fr' ? 'Présentation' : 'عن الطبيب'}
          </button>
          <button
            onClick={() => setActiveTab('conventions')}
            className={`flex-1 py-2 text-center text-xs font-bold rounded-lg transition-all ${
              activeTab === 'conventions'
                ? 'bg-surface-container-lowest text-primary shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
            type="button"
          >
            {language === 'fr' ? 'Conventions' : 'التأمين والاتفاقيات'}
          </button>
        </div>
      </section>

      {activeTab === 'disponibilites' && (
        <>
          {/* Motif de Consultation */}
          <section className="px-4 mt-3">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-sm text-on-surface">
                {language === 'fr' ? 'Motif de consultation' : 'سبب الاستشارة'}
              </h3>
              <span className="text-xs text-primary font-bold">
                {language === 'fr' ? 'Obligatoire' : 'إجباري'}
              </span>
            </div>

            <div className="grid grid-cols-1 gap-2">
              {consultationReasons.map((reason, idx) => {
                const isSelected = selectedReason === idx;
                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedReason(idx)}
                    className={`w-full text-left p-3 rounded-2xl border transition-all flex items-center justify-between ${
                      isSelected
                        ? 'bg-surface-container-lowest border-primary shadow-sm ring-1 ring-primary/20'
                        : 'bg-surface-container-low border-surface-container hover:bg-surface-container'
                    }`}
                    type="button"
                  >
                    <div className="flex items-center gap-3 min-w-0 pr-2">
                      <span
                        className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 border ${
                          isSelected ? 'border-primary bg-primary' : 'border-outline bg-white'
                        }`}
                      >
                        {isSelected && <span className="w-2 h-2 rounded-full bg-white"></span>}
                      </span>
                      <div className="min-w-0 text-start">
                        <div className="font-bold text-xs text-on-surface truncate">{reason.title}</div>
                        <div className="text-[11px] text-on-surface-variant mt-0.5 truncate">{reason.desc}</div>
                      </div>
                    </div>
                    <span className="material-symbols-outlined text-outline text-[18px]">
                      {isSelected ? 'check_circle' : 'radio_button_unchecked'}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Calendrier & Navigation Dynamique par Mois (Exigences 7 & 8) */}
          <section className="px-4 mt-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-[20px]">calendar_month</span>
                <h3 className="font-bold text-sm text-on-surface">
                  {monthYearLabel}
                </h3>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={handlePrevMonth}
                  aria-label={language === 'fr' ? "Mois précédent" : "الشهر السابق"}
                  className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high transition-colors cursor-pointer"
                  type="button"
                >
                  <span className={`material-symbols-outlined text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
                    chevron_left
                  </span>
                </button>
                <button
                  onClick={handleNextMonth}
                  aria-label={language === 'fr' ? "Mois suivant" : "الشهر القادم"}
                  className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high transition-colors cursor-pointer"
                  type="button"
                >
                  <span className={`material-symbols-outlined text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
                    chevron_right
                  </span>
                </button>
              </div>
            </div>

            {/* Horizontal Day Scroller */}
            <div className="flex items-center gap-2 overflow-x-auto py-1 no-scrollbar">
              {monthDays.map(d => {
                const isSelected = selectedDay === d.date;
                const isDisabled = d.isPast || d.isClosed || d.isFull;

                return (
                  <button
                    key={d.date}
                    disabled={isDisabled}
                    onClick={() => {
                      setSelectedDay(d.date);
                    }}
                    className={`flex-1 min-w-[68px] py-2.5 px-2 rounded-2xl flex flex-col items-center gap-1 transition-all shrink-0 border ${
                      isSelected
                        ? 'bg-primary text-on-primary border-primary shadow-sm'
                        : isDisabled
                        ? 'bg-surface-container-low opacity-45 cursor-not-allowed border-surface-container text-on-surface-variant'
                        : 'bg-white text-on-surface border-surface-container hover:bg-surface-container-low shadow-2xs cursor-pointer'
                    }`}
                    type="button"
                  >
                    <span className="text-[10px] font-bold uppercase tracking-wider">{d.label}</span>
                    <span className="text-lg font-bold leading-none">{d.num}</span>
                    <span className={`text-[10px] font-semibold mt-0.5 ${
                      isSelected ? 'text-white' : d.isPast ? 'text-outline' : d.isFull ? 'text-error' : 'text-primary'
                    }`}>
                      {d.slotsText}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Grille des créneaux horaires (Exigence 8) */}
          <section className="px-4 mt-3">
            {selectedDayInfo && (selectedDayInfo.isPast || selectedDayInfo.isClosed || selectedDayInfo.isFull) ? (
              <div className="p-6 bg-surface-container-low rounded-2xl border border-surface-container text-center">
                <span className="material-symbols-outlined text-outline text-[32px] mb-1">
                  event_busy
                </span>
                <p className="text-xs font-bold text-on-surface">
                  {selectedDayInfo.isPast
                    ? (language === 'fr' ? 'Date passée' : 'تاريخ منقضٍ')
                    : selectedDayInfo.isClosed
                    ? (language === 'fr' ? 'Cabinet fermé ce jour' : 'العيادة مغلقة في هذا اليوم')
                    : (language === 'fr' ? 'Journée complète' : 'مكتمل الحجز')}
                </p>
                <p className="text-[11px] text-on-surface-variant mt-0.5">
                  {language === 'fr'
                    ? 'Aucun créneau disponible pour cette date. Veuillez choisir un autre jour.'
                    : 'يرجى اختيار يوم آخر تتوفر فيه مواعيد شاغرة.'}
                </p>
              </div>
            ) : (
              <>
                {/* Matinée */}
                <div className="mb-3">
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="material-symbols-outlined text-[18px] text-tertiary">wb_sunny</span>
                    <span className="text-xs font-bold text-on-surface">
                      {language === 'fr' ? 'Matinée' : 'الصباح'}
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {currentSlots.morning.map(slot => {
                      const isSelected = selectedTime === slot.time;
                      if (!slot.available) {
                        return (
                          <button
                            key={slot.time}
                            disabled
                            className="py-2.5 rounded-xl bg-surface-container-low text-center text-xs font-semibold text-outline-variant opacity-60 line-through cursor-not-allowed border border-surface-container"
                            type="button"
                          >
                            <span dir="ltr" className="inline-block tabular-nums font-mono">{slot.time}</span>
                          </button>
                        );
                      }
                      return (
                        <button
                          key={slot.time}
                          onClick={() => setSelectedTime(slot.time)}
                          className={`py-2.5 rounded-xl text-center text-xs font-bold transition-all border cursor-pointer ${
                            isSelected
                              ? 'bg-primary text-white border-primary shadow-sm'
                              : 'bg-white text-on-surface border-surface-container hover:bg-secondary-container/40'
                          }`}
                          type="button"
                        >
                          <span dir="ltr" className="inline-block tabular-nums font-mono">{slot.time}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Après-midi */}
                <div>
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="material-symbols-outlined text-[18px] text-primary">wb_twilight</span>
                    <span className="text-xs font-bold text-on-surface">
                      {language === 'fr' ? 'Après-midi' : 'المساء'}
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {currentSlots.afternoon.map(slot => {
                      const isSelected = selectedTime === slot.time;
                      if (!slot.available) {
                        return (
                          <button
                            key={slot.time}
                            disabled
                            className="py-2.5 rounded-xl bg-surface-container-low text-center text-xs font-semibold text-outline-variant opacity-60 line-through cursor-not-allowed border border-surface-container"
                            type="button"
                          >
                            <span dir="ltr" className="inline-block tabular-nums font-mono">{slot.time}</span>
                          </button>
                        );
                      }
                      return (
                        <button
                          key={slot.time}
                          onClick={() => setSelectedTime(slot.time)}
                          className={`py-2.5 rounded-xl text-center text-xs font-bold transition-all border cursor-pointer ${
                            isSelected
                              ? 'bg-primary text-white border-primary shadow-sm'
                              : 'bg-white text-on-surface border-surface-container hover:bg-secondary-container/40'
                          }`}
                          type="button"
                        >
                          <span dir="ltr" className="inline-block tabular-nums font-mono">{slot.time}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </>
            )}
          </section>
        </>
      )}

      {/* Présentation */}
      {activeTab === 'presentation' && (
        <section className="px-4 mt-3 flex flex-col gap-3">
          <div className="bg-surface-container-lowest p-4 rounded-2xl border border-surface-container">
            <h3 className="font-bold text-sm text-on-surface mb-2">
              {language === 'fr' ? 'Biographie & Parcours' : 'السيرة المهنية'}
            </h3>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              {language === 'fr' ? doc.bio : doc.bioAr}
            </p>
          </div>
        </section>
      )}

      {/* Conventions */}
      {activeTab === 'conventions' && (
        <section className="px-4 mt-3 flex flex-col gap-3">
          <div className="bg-surface-container-lowest p-4 rounded-2xl border border-surface-container">
            <h3 className="font-bold text-sm text-on-surface mb-2">
              {language === 'fr' ? 'Conventions & Prise en charge' : 'التأمين والاتفاقيات'}
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1.5 border-b border-surface-container">
                <span className="text-on-surface-variant">{language === 'fr' ? 'Assurance CNAM' : 'تأمين كنام'}</span>
                <span className="font-bold text-secondary">{language === 'fr' ? 'Tiers-payant agréé' : 'الدفع الجزئي معتمد'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-surface-container">
                <span className="text-on-surface-variant">{language === 'fr' ? 'Assurance CNASS' : 'تأمين كناص'}</span>
                <span className="font-bold text-secondary">{language === 'fr' ? 'Prise en charge acceptée' : 'التكفل المباشر مقبول'}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-on-surface-variant">{language === 'fr' ? 'Admission patient' : 'تسجيل المريض'}</span>
                <span className="font-bold text-on-surface">{language === 'fr' ? 'Au guichet de l\'établissement' : 'عند شباك الاستقبال'}</span>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Sticky Bottom Bar */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-surface-container-lowest/98 backdrop-blur-md border-t border-surface-container shadow-[0_-4px_20px_rgba(0,0,0,0.1)] px-4 py-3 pb-safe">
        <div className="max-w-md mx-auto flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs px-1 font-bold">
            <div className="flex items-center gap-1.5 text-on-surface">
              <span className="material-symbols-outlined text-[16px] text-primary">event_available</span>
              <span>
                {formattedSelectedDay}{' '}
                {language === 'fr' ? `à ` : `عند الساعة `}
                <span dir="ltr" className="inline-block tabular-nums font-mono font-bold">{selectedTime}</span>
              </span>
            </div>
            <div className="text-xs text-secondary font-bold">
              {language === 'fr' ? 'Secteur conventionné' : 'قطاع معتمد'}
            </div>
          </div>

          <button
            disabled={isDateInvalid}
            onClick={() => {
              if (!isDateInvalid) {
                setShowSummaryModal(true);
              }
            }}
            className={`w-full h-12 rounded-xl font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all ${
              isDateInvalid
                ? 'bg-surface-container-high text-on-surface-variant/70 border border-surface-container cursor-not-allowed opacity-75'
                : 'bg-primary hover:bg-primary-container text-on-primary active:scale-[0.99] cursor-pointer'
            }`}
            type="button"
          >
            <span>
              {selectedDayInfo?.isPast
                ? (language === 'fr' ? 'Date passée — Non réservable' : 'تاريخ منقضٍ — غير متاح للحجز')
                : selectedDayInfo?.isClosed
                ? (language === 'fr' ? 'Cabinet fermé ce jour' : 'العيادة مغلقة في هذا اليوم')
                : selectedDayInfo?.isFull
                ? (language === 'fr' ? 'Journée complète' : 'مكتمل الحجز')
                : !selectedTime
                ? (language === 'fr' ? 'Sélectionnez un créneau' : 'يرجى اختيار موعد')
                : (language === 'fr' ? 'Réserver la consultation' : 'حجز الاستشارة الطبية')}
            </span>
            {!isDateInvalid && (
              <span className={`material-symbols-outlined text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
                arrow_forward
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Modal Récapitulatif Obligatoire Avant Confirmation (Exigence 10) */}
      {showSummaryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-surface-container text-start animate-scaleUp max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-surface-container mb-4">
              <div>
                <h3 className="font-bold text-base text-on-surface">
                  {language === 'fr' ? 'Récapitulatif du Rendez-vous' : 'ملخص تفاصيل الموعد'}
                </h3>
                <p className="text-xs text-on-surface-variant">
                  {language === 'fr' ? 'Vérifiez les informations avant confirmation' : 'يرجى مراجعة التفاصيل قبل التأكيد النهائي'}
                </p>
              </div>
              <button
                onClick={() => setShowSummaryModal(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-surface-container text-outline"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <div className="flex flex-col gap-3.5 text-xs text-on-surface">
              {/* Médecin & Spécialité */}
              <div className="p-3 bg-surface-container-low rounded-xl flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary text-white flex items-center justify-center font-bold text-sm shrink-0">
                  {doc.initials}
                </div>
                <div>
                  <p className="font-bold text-sm text-on-surface">{language === 'fr' ? doc.title : doc.titleAr}</p>
                  <p className="text-primary font-semibold">{language === 'fr' ? doc.specialtyName : doc.specialtyNameAr}</p>
                </div>
              </div>

              {/* Établissement & Adresse */}
              <div className="flex items-start gap-2.5">
                <span className="material-symbols-outlined text-secondary text-[20px] shrink-0 mt-0.5">
                  location_on
                </span>
                <div>
                  <p className="font-bold text-on-surface">{establishment.name}</p>
                  <p className="text-on-surface-variant text-[11px]">{establishment.address}</p>
                </div>
              </div>

              {/* Date & Heure */}
              <div className="flex items-start gap-2.5">
                <span className="material-symbols-outlined text-primary text-[20px] shrink-0 mt-0.5">
                  calendar_month
                </span>
                <div>
                  <p className="font-bold text-on-surface">{formattedSelectedDay}</p>
                  <p className="text-on-surface-variant text-[11px]">
                    {language === 'fr' ? (
                      `Horaire retenu : ${selectedTime}`
                    ) : (
                      <>
                        التوقيت المختار : <span dir="ltr" className="inline-block tabular-nums font-mono font-bold">{selectedTime}</span>
                      </>
                    )}
                  </p>
                </div>
              </div>

              {/* Couverture santé */}
              <div className="flex items-start gap-2.5">
                <span className="material-symbols-outlined text-emerald-600 text-[20px] shrink-0 mt-0.5">
                  health_and_safety
                </span>
                <div>
                  <p className="font-bold text-on-surface">
                    {language === 'fr' ? 'Couverture & Prise en charge' : 'التغطية الصحية'}
                  </p>
                  <p className="text-on-surface-variant text-[11px]">
                    {patient.insuranceType === 'CNAM'
                      ? (language === 'fr' ? 'Conventionné CNAM (Tiers-payant appliqué au guichet)' : 'معتمد كنام (تطبيق الدفع الجزئي عند الشباك)')
                      : patient.insuranceType === 'CNASS'
                      ? (language === 'fr' ? 'Conventionné CNASS (Prise en charge directe)' : 'معتمد كناص (تكفل مباشر بالاستشارة)')
                      : (language === 'fr' ? "Accueil et admission au secrétariat de l'établissement" : 'الاستقبال والتسجيل لدى أمانة المؤسسة')}
                  </p>
                </div>
              </div>

              {/* Informations Importantes */}
              <div className="p-3 bg-amber-50 border border-amber-200/80 rounded-xl text-amber-900 text-[11px] leading-relaxed">
                <p className="font-bold mb-0.5 flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px]">info</span>
                  {language === 'fr' ? 'À présenter à l\'accueil :' : 'وثائق هامة عند الحضور:'}
                </p>
                <p>
                  {language === 'fr'
                    ? 'Votre pièce d\'identité (NNI), votre carte d\'assurance si applicable, et le Pass QR généré.'
                    : 'بطاقة التعريف الوطنية، بطاقة التأمين الصحي، والتصريح الرقمي QR.'}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 mt-5 pt-3 border-t border-surface-container">
              <button
                type="button"
                onClick={() => setShowSummaryModal(false)}
                className="px-4 py-2.5 text-xs font-bold text-on-surface-variant hover:bg-surface-container rounded-xl"
              >
                {language === 'fr' ? 'Modifier' : 'تعديل'}
              </button>
              <button
                type="button"
                onClick={handleFinalConfirm}
                className="px-5 py-2.5 bg-primary hover:bg-primary/95 text-on-primary text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
              >
                <span>{language === 'fr' ? 'Confirmer le rendez-vous' : 'تأكيد الحجز النهائي'}</span>
                <span className="material-symbols-outlined text-[16px]">check</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
