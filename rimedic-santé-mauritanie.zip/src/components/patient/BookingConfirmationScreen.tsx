import React from 'react';
import { useApp } from '../../context/AppContext';
import { QrCodeView } from '../common/QrCodeView';
import {
  translateDoctorTitle,
  translateSpecialtyName,
  translateEstablishmentName,
  translateDateFormatted,
} from '../../translations';

export const BookingConfirmationScreen: React.FC = () => {
  const {
    language,
    navigateTo,
    lastCreatedAppointment,
    patient,
    isRtl,
    showToast
  } = useApp();

  const apt = lastCreatedAppointment;

  if (!apt) {
    return (
      <div className="p-8 text-center">
        <p>{language === 'fr' ? 'Aucun rendez-vous récent.' : 'لا يوجد موعد حديث.'}</p>
        <button
          onClick={() => navigateTo('home')}
          className="mt-4 px-4 py-2 bg-primary text-white rounded-xl"
        >
          {language === 'fr' ? "Retour à l'accueil" : 'الرجوع للرئيسية'}
        </button>
      </div>
    );
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Pass RIMEDIC - Consultation',
        text: `Pass rendez-vous ${apt.referenceNumber} pour ${apt.practitionerName} à ${apt.establishmentName} le ${apt.dateFormatted} à ${apt.time}.`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      showToast(
        language === 'fr' ? 'Pass copié !' : 'تم نسخ التصريح !',
        language === 'fr' ? `Référence : ${apt.referenceNumber}` : `المرجع : ${apt.referenceNumber}`
      );
    }
  };

  const handleAddToCalendar = () => {
    showToast(
      language === 'fr' ? 'Ajouté à l\'agenda !' : 'تمت الإضافة للتقويم !',
      `${apt.dateFormatted} ${language === 'fr' ? `à ${apt.time}` : `عند الساعة \u2066\u200E${apt.time}\u200E\u2069`}`
    );
  };

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Success Top Icon & Title */}
      <div className="w-full px-4 pt-4 flex flex-col items-center text-center">
        <div className="relative flex items-center justify-center mb-3">
          <div className="w-20 h-20 rounded-full bg-secondary-container flex items-center justify-center shadow-xs">
            <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center text-on-primary shadow-md">
              <span className="material-symbols-outlined text-[32px]">check</span>
            </div>
          </div>
          <div className="absolute -bottom-1 -right-1 bg-surface-container-lowest text-primary rounded-full p-1 shadow-xs border border-surface-container">
            <span className="material-symbols-outlined text-[18px]">verified</span>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-on-surface tracking-tight mb-1">
          {language === 'fr' ? 'Rendez-vous confirmé !' : 'تم تأكيد موعدك بنجاح !'}
        </h2>
        <p className="text-xs text-on-surface-variant max-w-[320px]">
          {language === 'fr'
            ? 'Votre consultation a été enregistrée auprès de l\'établissement.'
            : 'تم تسجيل استشارتك رسمياً في المنشأة الصحية.'}
        </p>

        <div className="mt-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-tertiary-fixed text-on-tertiary-fixed text-xs font-bold">
          <span className="material-symbols-outlined text-[16px] text-tertiary">tag</span>
          <span>
            {language === 'fr' ? 'Dossier N°' : 'رقم الملف'} <span className="tracking-wide">{apt.referenceNumber}</span>
          </span>
        </div>
      </div>

      {/* Ticket Pass Container with Perforation Effect */}
      <div className="px-4 mt-4 w-full">
        <div className="w-full bg-surface-container-lowest rounded-2xl shadow-md border border-surface-container overflow-hidden relative">
          <div className="p-4 bg-surface-container-lowest">
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary-container flex items-center justify-center text-on-primary">
                  <span className="material-symbols-outlined text-[18px]">health_and_safety</span>
                </div>
                <div className="flex flex-col text-left">
                  <span className="font-bold text-xs text-primary tracking-wide">
                    {language === 'fr' ? 'RIMEDIC' : 'ريميديك'}
                  </span>
                  <span className="text-[10px] text-on-surface-variant">
                    {language === 'fr' ? 'Pass Consultation' : 'تصريح الاستشارة'}
                  </span>
                </div>
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[11px] font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
                <span>{language === 'fr' ? 'Confirmé' : 'مؤكد'}</span>
              </span>
            </div>

            {/* QR Code Presentation Box */}
            <div className="flex flex-col items-center text-center p-4 rounded-2xl bg-surface-container-low border border-surface-container">
              <div className="p-2 bg-white rounded-xl shadow-xs mb-2">
                <QrCodeView value={apt.qrCodeData} size={140} />
              </div>
              <span className="text-xs text-on-surface-variant mb-1 font-medium">
                {language === 'fr'
                  ? 'Présentez ce QR code à l\'accueil de la clinique'
                  : 'أظهر رمز QR عند مكتب الاستقبال في العيادة'}
              </span>
              <span className="text-xs font-bold text-primary tracking-widest bg-surface-container px-3 py-1 rounded-full font-mono">
                {apt.referenceNumber}
              </span>
            </div>
          </div>

          {/* Ticket Perforation Notch */}
          <div className="relative w-full flex items-center justify-between px-2 bg-surface-container-lowest">
            <div className="w-5 h-5 -ml-4 rounded-full bg-[#faf8ff] border-r border-surface-container"></div>
            <div className="flex-1 mx-2 flex items-center justify-between overflow-hidden">
              <div className="w-full border-t-2 border-dashed border-surface-container"></div>
            </div>
            <div className="w-5 h-5 -mr-4 rounded-full bg-[#faf8ff] border-l border-surface-container"></div>
          </div>

          {/* Appointment Meta Details */}
          <div className="p-4 bg-surface-container-lowest space-y-3">
            <div className="flex items-start gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-secondary-container text-on-secondary-container flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-[18px]">person_outline</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-[10px] text-on-surface-variant uppercase font-bold">
                  {language === 'fr' ? 'Praticien' : 'الطبيب'}
                </span>
                <span className="font-bold text-xs text-on-surface truncate">{translateDoctorTitle(apt.practitionerName, language)}</span>
                <span className="text-[11px] text-secondary">
                  {translateSpecialtyName(apt.practitionerSpecialty, language)}
                </span>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-surface-container-high text-primary flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-[18px]">local_hospital</span>
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-[10px] text-on-surface-variant uppercase font-bold">
                  {language === 'fr' ? 'Établissement & Lieu' : 'العيادة والموقع'}
                </span>
                <span className="font-bold text-xs text-on-surface">
                  {translateEstablishmentName(apt.establishmentName, language)}
                </span>
                <span className="text-[11px] text-on-surface-variant">
                  {language === 'fr' ? apt.establishmentAddress : 'نواكشوط، موريتانيا'}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <div className="p-2.5 rounded-xl bg-surface-container-low flex flex-col border border-surface-container">
                <span className="text-[10px] text-on-surface-variant flex items-center gap-1 font-semibold">
                  <span className="material-symbols-outlined text-[13px]">calendar_today</span>
                  <span>{language === 'fr' ? 'Date & Heure' : 'التاريخ والتوقيت'}</span>
                </span>
                <span className="font-bold text-xs text-on-surface mt-1">{translateDateFormatted(apt.dateFormatted, language)}</span>
                <span dir="ltr" className="text-xs text-primary font-bold tabular-nums font-mono">{apt.time}</span>
              </div>

              <div className="p-2.5 rounded-xl bg-surface-container-low flex flex-col border border-surface-container">
                <span className="text-[10px] text-on-surface-variant flex items-center gap-1 font-semibold">
                  <span className="material-symbols-outlined text-[13px]">badge</span>
                  <span>{language === 'fr' ? 'Patient' : 'المريض'}</span>
                </span>
                <span className="font-bold text-xs text-on-surface mt-1 truncate">{apt.patientName}</span>
                <span className="text-[11px] text-secondary flex items-center gap-0.5">
                  <span className="material-symbols-outlined text-[12px]">verified</span>
                  <span>{language === 'fr' ? 'Dossier vérifié' : 'ملف معتمد'}</span>
                </span>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-surface-container-low flex items-center justify-between border border-surface-container">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[18px] text-primary">health_and_safety</span>
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-on-surface">
                    {language === 'fr' ? 'Couverture santé' : 'التغطية الصحية'}
                  </span>
                  <span className="text-[10px] text-on-surface-variant">
                    {apt.insuranceType && apt.insuranceType !== 'NONE'
                      ? `${apt.insuranceType} • ${language === 'fr' ? 'Tiers-payant' : 'الدفع الجزئي'}`
                      : (language === 'fr' ? 'Règlement au guichet' : 'دفع عند الاستقبال')}
                  </span>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold">
                {language === 'fr' ? 'Conventionné' : 'معتمد'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Arrival Instructions Card */}
      <div className="px-4 mt-3 w-full">
        <div className="p-4 rounded-2xl bg-surface-container-lowest shadow-sm border border-surface-container space-y-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[20px]">info</span>
            <h3 className="font-bold text-xs text-on-surface">
              {language === 'fr' ? 'Consignes d\'arrivée' : 'تعليمات الحضور للعيادة'}
            </h3>
          </div>

          <div className="space-y-2.5 text-xs">
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center shrink-0 text-primary">
                <span className="material-symbols-outlined text-[18px]">schedule</span>
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-on-surface">
                  {language === 'fr' ? 'Ponctualité' : 'الالتزام بالموعد'}
                </span>
                <p className="text-[11px] text-on-surface-variant leading-relaxed">
                  {language === 'fr'
                    ? 'Arrivez 10 minutes avant l\'heure pour formaliser votre accueil au guichet.'
                    : 'يرجى الحضور قبل الموعد بـ ١٠ دقائق لإنهاء إجراءات التسجيل بالشباك.'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center shrink-0 text-primary">
                <span className="material-symbols-outlined text-[18px]">badge</span>
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-on-surface">
                  {language === 'fr' ? 'Documents requis' : 'الوثائق المطلوبة'}
                </span>
                <p className="text-[11px] text-on-surface-variant leading-relaxed">
                  {language === 'fr'
                    ? 'Présentez votre pièce d\'identité officielle et votre carte CNAM / CNASS valide.'
                    : 'أحضر بطاقة الهوية الوطنية وبطاقة التأمين كنام أو كناص سارية المفعول.'}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center shrink-0 text-primary">
                <span className="material-symbols-outlined text-[18px]">pin_drop</span>
              </div>
              <div className="flex flex-col flex-1">
                <span className="font-bold text-on-surface">
                  {language === 'fr' ? 'Localisation' : 'الموقع'}
                </span>
                <p className="text-[11px] text-on-surface-variant">
                  {apt.establishmentAddress}
                </p>
                <button
                  onClick={() => navigateTo('map')}
                  className="inline-flex items-center gap-1 text-primary font-bold text-xs mt-1"
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">navigation</span>
                  <span>{language === 'fr' ? 'Ouvrir l\'itinéraire GPS' : 'فتح مسار الخريطة'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons Stack */}
      <div className="px-4 mt-3 w-full flex flex-col gap-2">
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleAddToCalendar}
            className="w-full h-11 rounded-xl bg-surface-container text-on-surface flex items-center justify-center gap-1.5 font-bold text-xs active:scale-95 transition-transform"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">event</span>
            <span>{language === 'fr' ? 'Ajouter au calendrier' : 'إضافة للتقويم'}</span>
          </button>

          <button
            onClick={handleShare}
            className="w-full h-11 rounded-xl bg-surface-container text-on-surface flex items-center justify-center gap-1.5 font-bold text-xs active:scale-95 transition-transform"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">share</span>
            <span>{language === 'fr' ? 'Partager le pass' : 'مشاركة التصريح'}</span>
          </button>
        </div>

        <button
          onClick={() => navigateTo('appointments')}
          className="w-full h-12 rounded-xl bg-primary text-on-primary flex items-center justify-center gap-2 font-bold text-sm shadow-md active:scale-95 transition-transform"
          type="button"
        >
          <span className="material-symbols-outlined text-[20px]">assignment_turned_in</span>
          <span>{language === 'fr' ? 'Voir dans Mes Rendez-vous' : 'عرض في قائمة مواعيدي'}</span>
        </button>

        <div className="pt-1 text-center">
          <button
            onClick={() => navigateTo('appointments')}
            className="text-on-surface-variant font-medium text-xs underline active:text-primary transition-colors"
          >
            {language === 'fr'
              ? 'Modifier ou annuler le rendez-vous sans frais jusqu\'à 4h avant'
              : 'يمكنك تعديل أو إلغاء الموعد مجاناً حتى ٤ ساعات قبل توقيته'}
          </button>
        </div>
      </div>
    </div>
  );
};
