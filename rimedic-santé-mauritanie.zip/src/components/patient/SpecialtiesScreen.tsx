import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SPECIALTIES_DATA } from '../../data/mockData';
import { Specialty } from '../../types';

export const SpecialtiesScreen: React.FC = () => {
  const {
    t,
    language,
    navigateTo,
    setSelectedSpecialtyId,
    setSelectedSubspecialtyName,
    isRtl
  } = useApp();

  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [expandedSpecialty, setExpandedSpecialty] = useState<string>('odontologie'); // Open by default as in Stitch mockup

  const categories = [
    { id: 'all', label: t.categoryAll, count: SPECIALTIES_DATA.length },
    { id: 'dentaire', label: t.categoryDental, icon: 'dentistry' },
    { id: 'mere-enfant', label: t.categoryMotherChild, icon: 'child_care' },
    { id: 'consultation', label: t.categoryConsultation, icon: 'stethoscope' },
    { id: 'chirurgie', label: t.categorySurgery, icon: 'medical_services' },
  ];

  const normalize = (s: string) =>
    (s || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim();

  const quickPills = [
    { label: language === 'fr' ? 'Diabète' : 'السكري', query: 'diabète' },
    { label: language === 'fr' ? 'Dentaire' : 'أسنان', query: 'dentaire' },
    { label: language === 'fr' ? 'Cardiologie' : 'قلب', query: 'cardiologie' },
    { label: language === 'fr' ? 'Pédiatrie' : 'أطفال', query: 'pédiatrie' },
    { label: language === 'fr' ? 'Gynécologie' : 'نساء', query: 'gynécologie' },
    { label: language === 'fr' ? 'Ophtalmologie' : 'عيون', query: 'ophtalmologie' },
  ];

  const filteredSpecialties = SPECIALTIES_DATA.filter(spec => {
    const matchesCategory = activeCategory === 'all' || spec.category === activeCategory;
    if (!search.trim()) return matchesCategory;

    const q = normalize(search);
    const qStem = q.endsWith('s') && q.length > 3 ? q.slice(0, -1) : q;
    const haystack = normalize(
      `${spec.name} ${spec.nameAr} ${spec.subtitle} ${spec.subtitleAr} ${(spec.keywords || []).join(' ')} ${spec.subspecialties.map(sub => `${sub.name} ${sub.nameAr}`).join(' ')}`
    );
    const matchesSearch = haystack.includes(q) || haystack.includes(qStem);
    return matchesCategory && matchesSearch;
  });

  const handleSubspecialtyClick = (specialty: Specialty, subspecialtyName: string) => {
    setSelectedSpecialtyId(specialty.id);
    setSelectedSubspecialtyName(subspecialtyName);
    navigateTo('doctor-list', { specialtyId: specialty.id, subspecialty: subspecialtyName });
  };

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Header Context */}
      <div className="px-4 pt-3 pb-2 flex flex-col gap-1">
        <div className="flex items-center gap-1.5 text-primary text-xs font-bold uppercase tracking-wider">
          <span className="material-symbols-outlined text-[16px]">local_hospital</span>
          <span>{language === 'fr' ? 'Répertoire National RIMEDIC' : 'دليل ريميديك الصحي الوطني'}</span>
        </div>
        <h2 className="text-2xl font-bold text-on-surface">{t.allSpecialtiesTitle}</h2>
        <p className="text-xs text-on-surface-variant leading-relaxed">{t.allSpecialtiesDesc}</p>
      </div>

      {/* Search Bar */}
      <div className="px-4 py-1.5">
        <div className="relative flex items-center w-full bg-surface-container-lowest rounded-xl shadow-xs border border-surface-container">
          <span className="material-symbols-outlined text-outline ml-3 mr-2 select-none text-[20px]">search</span>
          <input
            type="search"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={t.searchSpecialtyPlaceholder}
            className="w-full h-11 px-1 bg-transparent text-sm text-on-surface focus:outline-none placeholder:text-outline"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="pr-3 text-outline hover:text-on-surface"
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">close</span>
            </button>
          )}
        </div>

        {/* Quick Suggestion Pills */}
        <div className="flex items-center gap-1.5 mt-2 overflow-x-auto no-scrollbar">
          <span className="text-[10px] font-bold text-outline uppercase tracking-wider shrink-0 mr-1">
            {language === 'fr' ? 'Populaire :' : 'شائع :'}
          </span>
          {quickPills.map(pill => {
            const isSelected = search.toLowerCase().includes(pill.query.toLowerCase());
            return (
              <button
                key={pill.query}
                type="button"
                onClick={() => setSearch(isSelected ? '' : pill.query)}
                className={`px-2.5 py-1 rounded-full text-xs font-semibold shrink-0 transition-colors ${
                  isSelected
                    ? 'bg-primary text-on-primary'
                    : 'bg-surface-container-low text-on-surface-variant hover:bg-secondary-container/50'
                }`}
              >
                {pill.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Category Pills (Horizontal Scroll) */}
      <div className="py-2">
        <div className="flex items-center gap-1.5 px-4 overflow-x-auto no-scrollbar">
          {categories.map(cat => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all shrink-0 flex items-center gap-1 ${
                  isActive
                    ? 'bg-primary text-on-primary shadow-xs'
                    : 'bg-surface-container-low text-on-surface-variant hover:text-primary'
                }`}
                type="button"
              >
                {cat.icon && <span className="material-symbols-outlined text-[16px]">{cat.icon}</span>}
                <span>{cat.label}</span>
                {cat.count !== undefined && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isActive ? 'bg-white/20' : 'bg-surface-container'}`}>
                    {cat.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Approved Doctors Banner */}
      <div className="px-4 mb-2">
        <div className="bg-surface-container-low rounded-xl p-2.5 flex items-center justify-between border border-surface-container">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-full bg-secondary-container flex items-center justify-center shrink-0 text-on-secondary-container">
              <span className="material-symbols-outlined text-[18px]">verified</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-xs font-bold text-on-surface truncate">{t.certifiedDoctorsBanner}</span>
              <span className="text-[11px] text-on-surface-variant truncate">{t.certifiedDoctorsSub}</span>
            </div>
          </div>
          <span className="text-xs font-bold text-primary px-2 py-0.5 rounded bg-surface-container-lowest shrink-0">
            {language === 'fr' ? '430+ Méd.' : '٤٣٠+ طبيب'}
          </span>
        </div>
      </div>

      {/* Specialties List */}
      <div className="px-4 flex flex-col gap-2.5">
        {filteredSpecialties.length === 0 ? (
          <div className="py-8 flex flex-col items-center justify-center text-center gap-2">
            <div className="w-14 h-14 rounded-full bg-surface-container-high flex items-center justify-center text-outline">
              <span className="material-symbols-outlined text-[28px]">search_off</span>
            </div>
            <h4 className="text-sm font-bold text-on-surface">
              {language === 'fr' ? 'Aucune spécialité trouvée' : 'لم يتم العثور على أي تخصص'}
            </h4>
            <p className="text-xs text-on-surface-variant max-w-[280px]">
              {language === 'fr'
                ? 'Vérifiez l\'orthographe ou essayez un mot clé comme "dentiste", "yeux" ou "cœur".'
                : 'تحقق من الكلمة المكتوبة أو جرب البحث بكلمات مثل "أسنان"، "عيون" أو "قلب".'}
            </p>
            <button
              onClick={() => {
                setSearch('');
                setActiveCategory('all');
              }}
              className="mt-2 px-4 py-2 rounded-xl bg-surface-container-low text-primary text-xs font-bold hover:bg-secondary-container transition-colors"
            >
              {language === 'fr' ? 'Réinitialiser la recherche' : 'إعادة ضبط البحث'}
            </button>
          </div>
        ) : (
          filteredSpecialties.map(spec => {
            const hasSubspecialties = spec.subspecialties && spec.subspecialties.length > 0;
            const isExpanded = expandedSpecialty === spec.id;

            return (
              <div
                key={spec.id}
                className="bg-surface-container-lowest rounded-2xl shadow-[0_4px_20px_-2px_rgba(6,78,59,0.04)] border border-surface-container overflow-hidden transition-all duration-200"
              >
                {/* Specialty Header Row */}
                <div
                  onClick={() => {
                    if (hasSubspecialties) {
                      setExpandedSpecialty(isExpanded ? '' : spec.id);
                    } else {
                      setSelectedSpecialtyId(spec.id);
                      setSelectedSubspecialtyName('');
                      navigateTo('doctor-list');
                    }
                  }}
                  className="p-3.5 flex flex-col gap-2 cursor-pointer hover:bg-surface-container-low/40 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-11 h-11 rounded-xl bg-secondary-container text-on-secondary-container flex items-center justify-center shrink-0 shadow-xs">
                        <span className="material-symbols-outlined text-[24px]">{spec.icon}</span>
                      </div>
                      <div className="flex flex-col min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h3 className="font-bold text-sm text-on-surface truncate">
                            {language === 'fr' ? spec.name : spec.nameAr}
                          </h3>
                          {spec.isPopular && (
                            <span className="px-2 py-0.2 rounded-full text-[10px] font-bold bg-tertiary-fixed text-on-tertiary-fixed flex items-center gap-0.5">
                              <span className="material-symbols-outlined text-[12px]">local_fire_department</span>
                              <span>{language === 'fr' ? 'Très demandé' : 'أكثر طلباً'}</span>
                            </span>
                          )}
                        </div>
                        <span className="text-xs text-on-surface-variant font-medium">
                          {language === 'fr' ? spec.subtitle : spec.subtitleAr}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      aria-label={language === 'fr' ? "Déplier" : "توسيع"}
                      className="w-8 h-8 rounded-full bg-surface-container-low flex items-center justify-center text-on-surface-variant hover:text-primary transition-transform shrink-0"
                    >
                      <span
                        className={`material-symbols-outlined text-[20px] transition-transform duration-200 ${
                          isExpanded ? 'rotate-180' : ''
                        }`}
                      >
                        {hasSubspecialties ? 'expand_more' : isRtl ? 'chevron_left' : 'chevron_right'}
                      </span>
                    </button>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1 border-t border-surface-container/60">
                    <div className="flex items-center gap-1.5 text-primary font-semibold">
                      <span className="w-2 h-2 rounded-full bg-primary-container animate-pulse"></span>
                      <span>
                        {spec.specialistCount} {language === 'fr' ? 'praticiens à Nouakchott & Régions' : 'طبيباً في نواكشوط والولايات'}
                      </span>
                    </div>
                    <span className="text-tertiary font-bold flex items-center gap-0.5 text-xs">
                      <span className="material-symbols-outlined text-[14px]">bolt</span>
                      <span>{language === 'fr' ? spec.availableDelay : spec.availableDelayAr}</span>
                    </span>
                  </div>
                </div>

                {/* Subspecialties Accordion View */}
                {hasSubspecialties && isExpanded && (
                  <div className="px-3.5 pb-3.5 pt-1 flex flex-col gap-2 bg-surface-container-low/30 border-t border-surface-container">
                    <div className="text-[11px] font-bold text-outline uppercase tracking-wider">
                      {t.subspecialtiesAvailable}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {spec.subspecialties.map(sub => (
                        <button
                          key={sub.id}
                          onClick={() => handleSubspecialtyClick(spec, sub.name)}
                          className="p-2.5 rounded-xl bg-white hover:bg-secondary-container/40 border border-surface-container transition-all flex items-center justify-between text-left group cursor-pointer"
                          type="button"
                        >
                          <div className="flex flex-col min-w-0 pr-2">
                            <span className="text-xs font-bold text-on-surface group-hover:text-primary transition-colors leading-tight">
                              {language === 'fr' ? sub.name : sub.nameAr}
                            </span>
                            <span className="text-[10px] text-on-surface-variant mt-0.5">
                              {sub.doctorCount} {language === 'fr' ? 'praticiens' : 'طبيباً'}
                            </span>
                          </div>
                          <span className={`material-symbols-outlined text-outline text-[16px] group-hover:text-primary transition-colors shrink-0 ${isRtl ? 'rotate-180' : ''}`}>
                            chevron_right
                          </span>
                        </button>
                      ))}
                    </div>

                    {/* Primary Button to explore all specialists in this branch */}
                    <button
                      onClick={() => {
                        setSelectedSpecialtyId(spec.id);
                        setSelectedSubspecialtyName('');
                        navigateTo('doctor-list');
                      }}
                      className="w-full mt-1 py-2.5 rounded-xl bg-primary text-on-primary font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm active:scale-[0.99] transition-transform"
                      type="button"
                    >
                      <span>
                        {language === 'fr' ? `Explorer tous les spécialistes (${spec.name})` : `عرض جميع أطباء ${spec.nameAr}`}
                      </span>
                      <span className={`material-symbols-outlined text-[16px] ${isRtl ? 'rotate-180' : ''}`}>
                        arrow_forward
                      </span>
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Bottom Medical Emergency Callout */}
      <div className="px-4 pt-4 pb-2">
        <div className="p-3.5 rounded-2xl bg-secondary-container text-on-secondary-container flex items-center justify-between gap-3 shadow-sm border border-secondary-container">
          <div className="flex items-center gap-3 min-w-0">
            <span className="material-symbols-outlined text-[28px] text-primary shrink-0">
              emergency
            </span>
            <div className="flex flex-col min-w-0">
              <span className="font-bold text-xs">
                {language === 'fr' ? 'Urgences Médicales Mauritanie' : 'طوارئ الإسعاف الوطني'}
              </span>
              <span className="text-[11px] text-on-surface-variant truncate">
                {language === 'fr' ? 'SAMU national mauritanien (appel gratuit)' : 'خدمة الإسعاف والاستعجال الوطني'}
              </span>
            </div>
          </div>
          <a
            href="tel:101"
            className="px-3.5 py-1.5 rounded-xl bg-primary text-white font-bold text-xs shrink-0 shadow-sm hover:opacity-95 transition-opacity flex items-center gap-1"
          >
            <span className="material-symbols-outlined text-[14px]">call</span>
            <span>101</span>
          </a>
        </div>
      </div>
    </div>
  );
};
