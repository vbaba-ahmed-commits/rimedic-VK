import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { SPECIALTIES_DATA, PRACTITIONERS_DATA, ESTABLISHMENTS_DATA } from '../../data/mockData';
import {
  translateNeighborhood,
  translateDoctorTitle,
  translateSpecialtyName,
  translateEstablishmentName,
  translateDateFormatted,
} from '../../translations';

export const HomeScreen: React.FC = () => {
  const {
    t,
    language,
    setLanguage,
    navigateTo,
    selectedCity,
    setIsCityModalOpen,
    upcomingAppointments,
    patient,
    isRtl,
    setCurrentRole,
    setSelectedSpecialtyId,
    setSelectedSubspecialtyName,
    setSelectedPractitioner,
    setSelectedEstablishment
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [showSamuConfirm, setShowSamuConfirm] = useState(false);

  // Search query normalization helper (accents, lowercase, trim)
  const normalize = (s: string) =>
    (s || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim();

  const qClean = normalize(searchQuery);
  const qStem = qClean.endsWith('s') && qClean.length > 3 ? qClean.slice(0, -1) : qClean;

  // Global search filtering
  const matchingSpecialties = searchQuery.trim()
    ? SPECIALTIES_DATA.filter(s => {
        const text = normalize(
          `${s.name} ${s.nameAr} ${s.subtitle} ${s.subtitleAr} ${(s.keywords || []).join(' ')} ${s.subspecialties.map(sub => `${sub.name} ${sub.nameAr}`).join(' ')}`
        );
        return text.includes(qClean) || text.includes(qStem);
      })
    : [];

  const matchingDoctors = searchQuery.trim()
    ? PRACTITIONERS_DATA.filter(d => {
        const text = normalize(
          `${d.title} ${d.titleAr} ${d.specialtyName} ${d.specialtyNameAr} ${d.subspecialtyNames.join(' ')} ${d.establishmentName} ${d.establishmentNameAr} ${d.neighborhood} ${d.education || ''} ${d.bio || ''}`
        );
        return text.includes(qClean) || text.includes(qStem);
      })
    : [];

  const matchingEstablishments = searchQuery.trim()
    ? ESTABLISHMENTS_DATA.filter(e => {
        const text = normalize(`${e.name} ${e.nameAr} ${e.neighborhood} ${e.typeLabel} ${e.typeLabelAr}`);
        return text.includes(qClean) || text.includes(qStem);
      })
    : [];

  // Strictly dynamic temporal check: next appointment is only future appointments!
  const hasUpcomingAppointments = upcomingAppointments.length > 0;
  const nextAppointment = upcomingAppointments[0];

  const popularSpecialties = [
    {
      id: 'diabetologie',
      title: language === 'fr' ? 'Diabète' : 'السكري',
      sub: language === 'fr' ? 'Diabétologie' : 'تنظيم السكر والغدد',
      icon: 'bloodtype',
      bgClass: 'bg-emerald-50 text-emerald-800 border border-emerald-200/50',
    },
    {
      id: 'odontologie',
      subspecialty: 'Chirurgiens-dentistes',
      title: language === 'fr' ? 'Dentaire' : 'أسنان',
      sub: language === 'fr' ? 'Odontologie' : 'تقويم وجراحة',
      icon: 'dentistry',
      bgClass: 'bg-surface-container-low text-primary',
    },
    {
      id: 'cardiologie',
      title: language === 'fr' ? 'Cardiologie' : 'أمراض القلب',
      sub: language === 'fr' ? 'Cœur & Vaisseaux' : 'تخطيط وقسطرة',
      icon: 'favorite',
      bgClass: 'bg-error-container/40 text-error',
    },
    {
      id: 'pediatrie',
      title: language === 'fr' ? 'Pédiatrie' : 'طب الأطفال',
      sub: language === 'fr' ? 'Enfants & Bébés' : 'حديثو الولادة',
      icon: 'child_care',
      bgClass: 'bg-secondary-container/50 text-secondary',
    },
    {
      id: 'gynecologie',
      title: language === 'fr' ? 'Gynécologie' : 'النساء والتوليد',
      sub: language === 'fr' ? 'Obstétrique' : 'متابعة الحمل',
      icon: 'pregnant_woman',
      bgClass: 'bg-surface-container text-primary',
    },
    {
      id: 'ophtalmologie',
      title: language === 'fr' ? 'Vision' : 'طب العيون',
      sub: language === 'fr' ? 'Ophtalmologie' : 'فحص البصر',
      icon: 'visibility',
      bgClass: 'bg-tertiary-fixed/60 text-on-tertiary-fixed',
    },
  ];

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Section 1: Salutation chaleureuse & Contexte Mauritanien */}
      <section className="px-4 pt-3 pb-2 flex flex-col gap-1">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setIsCityModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-secondary-container text-on-secondary-container text-xs font-semibold hover:bg-secondary-container/80 transition-colors"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
            <span>{language === 'fr' ? `${selectedCity.name}, MR` : `${selectedCity.nameAr}، موريتانيا`}</span>
            <span className="material-symbols-outlined text-[14px]">expand_more</span>
          </button>

          <div className="flex items-center bg-surface-container-low px-2 py-0.5 rounded-full text-xs font-semibold border border-surface-container">
            <button
              onClick={() => setLanguage('fr')}
              className={`${language === 'fr' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              FR
            </button>
            <span className="mx-1 text-outline-variant">|</span>
            <button
              onClick={() => setLanguage('ar')}
              className={`${language === 'ar' ? 'text-primary font-bold' : 'text-on-surface-variant'}`}
            >
              عربي
            </button>
          </div>
        </div>

        <div className="mt-1">
          <div className="flex items-baseline gap-2">
            <h2 className="text-2xl font-bold text-on-surface">
              {language === 'fr'
                ? `Bonjour${patient.firstName ? ', ' + patient.firstName : ''}`
                : `مرحباً${patient.firstName ? '، ' + patient.firstName : ''}`}
            </h2>
          </div>
          <p className="text-sm text-on-surface-variant mt-0.5">{t.greetingSubtitle}</p>
        </div>
      </section>

      {/* Section 2: Doctolib-Style Search Hub with Real-Time Mauritanian Index */}
      <section className="px-4 my-2 relative">
        <div className="bg-surface-container-lowest rounded-2xl p-3 shadow-[0_8px_24px_-4px_rgba(0,105,72,0.08)] border border-surface-container flex flex-col gap-2">
          {/* Search Input Line */}
          <div className="relative flex items-center bg-surface-container-low rounded-xl px-3 py-2.5 border border-surface-container">
            <span className="material-symbols-outlined text-primary text-[22px] shrink-0 mr-2">search</span>
            <input
              type="text"
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                setShowSearchResults(e.target.value.trim().length > 0);
              }}
              onFocus={() => setShowSearchResults(searchQuery.trim().length > 0)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-transparent text-sm text-on-surface placeholder:text-outline focus:outline-none min-w-0"
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setShowSearchResults(false);
                }}
                className="text-outline hover:text-on-surface p-1"
              >
                <span className="material-symbols-outlined text-[18px]">cancel</span>
              </button>
            )}
          </div>

          {/* Quick Context / Location Toggle Row */}
          <div className="flex items-center justify-between pt-0.5">
            <button
              onClick={() => setIsCityModalOpen(true)}
              className="flex items-center gap-1.5 py-1 px-2.5 rounded-full bg-surface-container-low hover:bg-surface-container text-on-surface-variant transition-colors"
              type="button"
            >
              <span className="material-symbols-outlined text-primary text-[18px]">location_on</span>
              <span className="text-xs font-bold text-on-surface">
                {language === 'fr' ? selectedCity.name : selectedCity.nameAr}
              </span>
              <span className="material-symbols-outlined text-[16px] text-outline">expand_more</span>
            </button>

            <button
              onClick={() => navigateTo('specialties')}
              className="flex items-center gap-1 py-1 px-3 rounded-full bg-primary-fixed text-on-primary-fixed text-xs font-bold hover:bg-primary-fixed-dim transition-colors shadow-xs"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">tune</span>
              <span>{t.filtersBtn}</span>
            </button>
          </div>
        </div>

        {/* Real-time search dropdown results */}
        {showSearchResults && (
          <div className="absolute left-4 right-4 top-full mt-1.5 bg-white rounded-2xl shadow-2xl border border-surface-container p-3 z-50 max-h-[380px] overflow-y-auto flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs font-bold text-outline pb-1 border-b border-surface-container">
              <span>{language === 'fr' ? 'Résultats pour :' : 'نتائج البحث عن :'} "{searchQuery}"</span>
              <button onClick={() => setShowSearchResults(false)} className="text-primary hover:underline">
                {language === 'fr' ? 'Fermer' : 'إغلاق'}
              </button>
            </div>

            {matchingEstablishments.length === 0 && matchingDoctors.length === 0 && matchingSpecialties.length === 0 ? (
              <div className="py-6 text-center text-on-surface-variant text-sm">
                <span className="material-symbols-outlined text-[28px] text-outline mb-1 block">search_off</span>
                <p>{language === 'fr' ? 'Aucun résultat trouvé' : 'لم يتم العثور على نتائج'}</p>
                <p className="text-xs text-outline mt-1">
                  {language === 'fr' ? 'Essayez "dentiste", "Ibn Sina" ou "cardiologie"' : 'جرب كلمة "أسنان" أو "ابن سينا" أو "قلب"'}
                </p>
              </div>
            ) : (
              <>
                {/* Establishments Results (e.g. Clinique Ibn Sina) */}
                {matchingEstablishments.length > 0 && (
                  <div>
                    <span className="text-[11px] font-bold text-primary uppercase tracking-wider block mb-1">
                      {language === 'fr' ? 'Établissements' : 'المستشفيات والعيادات'}
                    </span>
                    {matchingEstablishments.slice(0, 3).map(est => (
                      <div
                        key={est.id}
                        onClick={() => {
                          setSelectedEstablishment(est);
                          setShowSearchResults(false);
                          navigateTo('establishment-detail', { establishment: est });
                        }}
                        className="p-2.5 rounded-xl bg-surface-container-low hover:bg-secondary-container/30 cursor-pointer flex items-center justify-between transition-colors mb-1"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span className="material-symbols-outlined text-primary text-[20px]">local_hospital</span>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-on-surface truncate">
                              {language === 'fr' ? est.name : est.nameAr}
                            </p>
                            <p className="text-[11px] text-on-surface-variant truncate">
                              {translateNeighborhood(est.neighborhood, language)} • {language === 'fr' ? est.typeLabel : (est.typeLabelAr || est.typeLabel)}
                            </p>
                          </div>
                        </div>
                        <span className="material-symbols-outlined text-outline text-[16px]">chevron_right</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Specialties Results (e.g. Odontologie -> Orthodontistes) */}
                {matchingSpecialties.length > 0 && (
                  <div>
                    <span className="text-[11px] font-bold text-secondary uppercase tracking-wider block mb-1">
                      {language === 'fr' ? 'Spécialités' : 'التخصصات'}
                    </span>
                    {matchingSpecialties.slice(0, 3).map(spec => (
                      <div
                        key={spec.id}
                        onClick={() => {
                          setSelectedSpecialtyId(spec.id);
                          setSelectedSubspecialtyName('');
                          setShowSearchResults(false);
                          navigateTo('doctor-list', { specialtyId: spec.id });
                        }}
                        className="p-2.5 rounded-xl bg-surface-container-low hover:bg-secondary-container/30 cursor-pointer flex items-center justify-between transition-colors mb-1"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="material-symbols-outlined text-secondary text-[20px]">{spec.icon}</span>
                          <div>
                            <p className="text-xs font-bold text-on-surface">
                              {language === 'fr' ? spec.name : spec.nameAr}
                            </p>
                            <p className="text-[11px] text-on-surface-variant">
                              {spec.subspecialties.length} {language === 'fr' ? 'sous-branches' : 'تخصصاً فرعياً'}
                            </p>
                          </div>
                        </div>
                        <span className="material-symbols-outlined text-outline text-[16px]">chevron_right</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Doctors Results */}
                {matchingDoctors.length > 0 && (
                  <div>
                    <span className="text-[11px] font-bold text-on-surface uppercase tracking-wider block mb-1">
                      {language === 'fr' ? 'Praticiens' : 'الأطباء'}
                    </span>
                    {matchingDoctors.slice(0, 3).map(doc => (
                      <div
                        key={doc.id}
                        onClick={() => {
                          setSelectedPractitioner(doc);
                          setShowSearchResults(false);
                          navigateTo('doctor-profile', { doctor: doc });
                        }}
                        className="p-2.5 rounded-xl bg-surface-container-low hover:bg-secondary-container/30 cursor-pointer flex items-center justify-between transition-colors mb-1"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className="w-8 h-8 rounded-full bg-secondary-container text-on-secondary-container flex items-center justify-center font-bold text-xs shrink-0">
                            {doc.initials}
                          </div>
                          <div className="min-w-0">
                            <p className="text-xs font-bold text-on-surface truncate">
                              {language === 'fr' ? doc.title : doc.titleAr}
                            </p>
                            <p className="text-[11px] text-on-surface-variant truncate">
                              {language === 'fr' ? doc.specialtyName : doc.specialtyNameAr} • {language === 'fr' ? doc.establishmentName : (doc.establishmentNameAr || doc.establishmentName)}
                            </p>
                          </div>
                        </div>
                        <span className="material-symbols-outlined text-outline text-[16px]">chevron_right</span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </section>

      {/* Section 3: Raccourcis / Cartes Tactiles d'accès direct */}
      <section className="px-4 my-2">
        <div className="grid grid-cols-3 gap-2">
          {/* Spécialités */}
          <button
            onClick={() => navigateTo('specialties')}
            className="group flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-lowest shadow-[0_4px_16px_rgba(0,0,0,0.03)] border border-surface-container hover:shadow-md transition-all active:scale-95 text-center"
            type="button"
          >
            <div className="w-12 h-12 rounded-full bg-secondary-container flex items-center justify-center text-on-secondary-container group-hover:scale-105 transition-transform mb-2">
              <span className="material-symbols-outlined text-[26px]">stethoscope</span>
            </div>
            <span className="text-xs font-bold text-on-surface">{t.quickSpecialties}</span>
            <span className="text-[10px] text-outline mt-0.5">{t.quickSpecialtiesSub}</span>
          </button>

          {/* Établissements */}
          <button
            onClick={() => {
              setSelectedEstablishment(ESTABLISHMENTS_DATA[0]);
              navigateTo('establishment-detail');
            }}
            className="group flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-lowest shadow-[0_4px_16px_rgba(0,0,0,0.03)] border border-surface-container hover:shadow-md transition-all active:scale-95 text-center"
            type="button"
          >
            <div className="w-12 h-12 rounded-full bg-surface-container-high flex items-center justify-center text-primary group-hover:scale-105 transition-transform mb-2">
              <span className="material-symbols-outlined text-[26px]">local_hospital</span>
            </div>
            <span className="text-xs font-bold text-on-surface">{t.quickEstablishments}</span>
            <span className="text-[10px] text-outline mt-0.5">{t.quickEstablishmentsSub}</span>
          </button>

          {/* Carte Santé */}
          <button
            onClick={() => navigateTo('map')}
            className="group flex flex-col items-center justify-center p-3 rounded-2xl bg-surface-container-lowest shadow-[0_4px_16px_rgba(0,0,0,0.03)] border border-surface-container hover:shadow-md transition-all active:scale-95 text-center"
            type="button"
          >
            <div className="w-12 h-12 rounded-full bg-tertiary-fixed flex items-center justify-center text-on-tertiary-fixed group-hover:scale-105 transition-transform mb-2">
              <span className="material-symbols-outlined text-[26px]">explore</span>
            </div>
            <span className="text-xs font-bold text-on-surface">{t.quickMap}</span>
            <span className="text-[10px] text-outline mt-0.5">{t.quickMapSub}</span>
          </button>
        </div>
      </section>

      {/* Section 4: Spécialités Populaires (3 colonnes compacte et fluide) */}
      <section className="my-3">
        <div className="px-4 flex items-center justify-between mb-2">
          <div className="flex flex-col">
            <h3 className="font-bold text-base text-on-surface">{t.popularSpecialties}</h3>
            <p className="text-xs text-on-surface-variant">{t.popularSubtitle}</p>
          </div>
          <button
            onClick={() => navigateTo('specialties')}
            className="flex items-center gap-0.5 text-primary text-xs font-bold hover:underline"
          >
            <span>{t.viewAll}</span>
            <span className={`material-symbols-outlined text-[16px] ${isRtl ? 'rotate-180' : ''}`}>
              arrow_forward
            </span>
          </button>
        </div>

        <div className="px-4 grid grid-cols-3 gap-2">
          {popularSpecialties.map(spec => (
            <div
              key={spec.id}
              onClick={() => {
                setSelectedSpecialtyId(spec.id);
                setSelectedSubspecialtyName('');
                navigateTo('doctor-list');
              }}
              className="flex flex-col items-center bg-surface-container-lowest p-3 rounded-2xl shadow-[0_2px_8px_rgba(0,0,0,0.03)] border border-surface-container hover:shadow-[0_6px_16px_rgba(0,105,72,0.08)] transition-all cursor-pointer group"
            >
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors group-hover:scale-105 ${spec.bgClass}`}
              >
                <span className="material-symbols-outlined text-[22px]">{spec.icon}</span>
              </div>
              <span className="text-xs font-bold text-on-surface mt-2 text-center line-clamp-1">
                {spec.title}
              </span>
              <span className="text-[10px] text-outline truncate">{spec.sub}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Section 5: Mes prochains rendez-vous */}
      <section className="px-4 my-3">
        <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-[0_4px_24px_-4px_rgba(0,105,72,0.06)] border border-surface-container flex flex-col">
          {/* Top Section Header */}
          <div className="w-full flex items-center justify-between pb-2 mb-3 border-b border-surface-container">
            <span className="font-bold text-sm text-on-surface">{t.myNextAppointment}</span>
            <span className="px-2 py-0.5 rounded-full bg-surface-container text-on-surface-variant text-[11px] font-bold">
              {hasUpcomingAppointments
                ? (language === 'fr' ? '1 à venir' : '١ قادم')
                : (language === 'fr' ? '0 à venir' : 'لا توجد مواعيد')}
            </span>
          </div>

          {hasUpcomingAppointments && nextAppointment ? (
            /* Upcoming Appointment Card */
            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-xl bg-secondary-container flex items-center justify-center text-primary font-bold text-sm shrink-0">
                  <span className="material-symbols-outlined text-[24px]">medical_services</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <h4 className="font-bold text-sm text-on-surface truncate">
                      {translateDoctorTitle(nextAppointment.practitionerName, language)}
                    </h4>
                    <span className="px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold shrink-0">
                      {language === 'fr' ? 'Confirmé' : 'مؤكد'}
                    </span>
                  </div>
                  <p className="text-xs text-primary font-semibold truncate">
                    {translateSpecialtyName(nextAppointment.practitionerSpecialty, language)}
                  </p>
                  <p className="text-[11px] text-on-surface-variant truncate mt-0.5">
                    {translateEstablishmentName(nextAppointment.establishmentName, language)}
                  </p>
                </div>
              </div>

              <div className="p-2.5 bg-surface-container-low rounded-xl flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary text-[18px]">calendar_month</span>
                  <div>
                    <span className="font-bold text-on-surface block">{translateDateFormatted(nextAppointment.dateFormatted, language)}</span>
                    <span className="text-on-surface-variant text-[11px]">
                      {language === 'fr' ? `Horaire : ` : `الموعد: `}
                      <span dir="ltr" className="inline-block tabular-nums font-mono font-semibold">{nextAppointment.time}</span>
                    </span>
                  </div>
                </div>
                <div className="text-end">
                  <span className="text-[10px] text-outline block">{language === 'fr' ? 'Couverture' : 'التأمين'}</span>
                  <span className="font-bold text-secondary">{nextAppointment.insuranceType || 'CNAM'}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => navigateTo('appointments')}
                  className="py-2.5 px-3 rounded-xl bg-surface-container-high text-primary text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-surface-container transition-colors"
                >
                  <span className="material-symbols-outlined text-[16px]">qr_code_2</span>
                  <span>{language === 'fr' ? 'Voir Pass QR' : 'عرض تصريح QR'}</span>
                </button>
                <button
                  onClick={() => navigateTo('specialties')}
                  className="py-2.5 px-3 rounded-xl bg-primary text-on-primary text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm active:scale-95 transition-transform"
                >
                  <span className="material-symbols-outlined text-[16px]">add</span>
                  <span>{language === 'fr' ? 'Autre RDV' : 'موعد آخر'}</span>
                </button>
              </div>
            </div>
          ) : (
            /* Tactile Delight Empty State from Stitch */
            <div className="flex flex-col items-center text-center py-2">
              <div className="relative w-16 h-16 my-1 flex items-center justify-center">
                <div className="absolute inset-0 rounded-full bg-secondary-container/40 animate-pulse"></div>
                <div className="relative w-12 h-12 rounded-full bg-surface-container-low flex items-center justify-center text-primary shadow-inner">
                  <span className="material-symbols-outlined text-[28px]">event_available</span>
                </div>
                <span className="absolute -top-1 -right-1 flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-secondary-fixed opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-primary text-white items-center justify-center">
                    <span className="material-symbols-outlined text-[10px]">check</span>
                  </span>
                </span>
              </div>

              <h4 className="font-bold text-sm text-on-surface mt-2">{t.noAppointmentTitle}</h4>
              <p className="text-xs text-on-surface-variant max-w-xs mt-1 leading-relaxed">
                {t.noAppointmentDesc}
              </p>

              <button
                onClick={() => {
                  navigateTo('specialties');
                }}
                className="w-full mt-3 h-12 bg-primary hover:bg-primary-container text-on-primary font-bold text-sm rounded-xl flex items-center justify-center gap-2 shadow-[0_4px_14px_rgba(0,105,72,0.25)] active:scale-[0.98] transition-all"
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">add_circle</span>
                <span>{t.bookAppointmentBtn}</span>
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Section 6: Local Healthcare Trust & Emergency Banner (Mauritanie) */}
      <section className="px-4 my-2 flex flex-col gap-2.5">
        {/* CNAM / CNASS Mauritanie Coverage Card */}
        <div className="bg-gradient-to-r from-surface-container to-surface-container-high p-3.5 rounded-2xl flex items-start gap-3 shadow-xs border border-surface-container">
          <div className="w-10 h-10 rounded-xl bg-surface-container-lowest flex items-center justify-center text-primary shrink-0 shadow-xs mt-0.5">
            <span className="material-symbols-outlined text-[22px]">verified_user</span>
          </div>
          <div className="flex flex-col min-w-0 flex-grow">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-bold text-xs text-on-surface">{t.partnerCnamTitle}</span>
              <span className="px-1.5 py-0.2 rounded bg-primary/10 text-primary text-[10px] font-bold uppercase">
                {t.officialBadge}
              </span>
            </div>
            <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">{t.partnerCnamDesc}</p>
          </div>
        </div>

        {/* SOS / Urgences Mauritanie 101 SAMU */}
        <div className="bg-error-container/40 p-3.5 rounded-2xl flex items-center justify-between shadow-xs border border-error-container/60">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-full bg-error text-on-error flex items-center justify-center shrink-0 shadow-xs">
              <span className="material-symbols-outlined text-[22px]">e911_emergency</span>
            </div>
            <div className="flex flex-col min-w-0">
              <span className="font-bold text-xs text-on-error-container">{t.emergencyTitle}</span>
              <span className="text-[11px] text-on-surface-variant truncate">{t.emergencySubtitle}</span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowSamuConfirm(true)}
            className="shrink-0 px-3 py-1.5 rounded-xl bg-error hover:bg-error-container text-on-error font-bold text-xs flex items-center gap-1 shadow-xs active:scale-95 transition-transform cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">call</span>
            <span>101</span>
          </button>
        </div>

        {/* Micro-mention culturelle rassurante */}
        <div className="py-1 text-center">
          <p className="text-[11px] text-outline">{t.footerTrust}</p>
        </div>
      </section>

      {/* Confirmation Appel SAMU 101 (Exigence 31) */}
      {showSamuConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-sm bg-white rounded-2xl p-5 shadow-2xl border border-error-container text-start animate-scaleUp">
            <div className="w-12 h-12 rounded-full bg-error-container text-error flex items-center justify-center mb-3">
              <span className="material-symbols-outlined text-[28px]">emergency</span>
            </div>
            <h3 className="font-bold text-base text-on-surface mb-1">
              {language === 'fr' ? 'Appeler le SAMU 101 ?' : 'الاتصال بالإسعاف ١٠١؟'}
            </h3>
            <p className="text-xs text-on-surface-variant mb-4 leading-relaxed">
              {language === 'fr'
                ? 'Le 101 est le numéro national d\'urgence médicale gratuit en Mauritanie, accessible 24h/24 et 7j/7.'
                : 'الرقم ١٠١ هو خط النجدة والإسعاف الطبي الوطني المجاني في موريتانيا متاح على مدار الساعة.'}
            </p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowSamuConfirm(false)}
                className="px-3 py-2 text-xs font-bold text-on-surface-variant hover:bg-surface-container rounded-xl"
              >
                {language === 'fr' ? 'Annuler' : 'إلغاء'}
              </button>
              <a
                href="tel:101"
                onClick={() => setShowSamuConfirm(false)}
                className="px-4 py-2 bg-error hover:bg-error/90 text-on-error text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm"
              >
                <span className="material-symbols-outlined text-[16px]">call</span>
                <span>{language === 'fr' ? 'Appeler' : 'اتصال الآن'}</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
