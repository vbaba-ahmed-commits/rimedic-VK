import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db, auth } from '../../firebase';
import { AppleSignInModal } from '../auth/AppleSignInModal';

export const PatientProfileScreen: React.FC = () => {
  const {
    language,
    setLanguage,
    patient,
    setPatient,
    appointments,
    upcomingAppointments,
    pastAppointments,
    navigateTo,
    setCurrentRole,
    showToast,
    isRtl,
    firebaseUser,
    loginWithGoogle,
    loginWithApple,
    loginWithAppleCredentials,
    logoutUser,
    logoutFirebase,
    switchAccount,
    organizationUser,
    logoutOrganization,
  } = useApp();

  const [smsEnabled, setSmsEnabled] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isAppleModalOpen, setIsAppleModalOpen] = useState(false);
  const [editFirstName, setEditFirstName] = useState(patient.firstName || '');
  const [editLastName, setEditLastName] = useState(patient.lastName || '');

  // Keep editing state in sync when patient loads from Firestore / Auth
  React.useEffect(() => {
    setEditFirstName(patient.firstName || '');
    setEditLastName(patient.lastName || '');
  }, [patient.firstName, patient.lastName]);

  const upcomingCount = upcomingAppointments.length;
  const completedCount = pastAppointments.length;

  const handleSaveProfile = async () => {
    setPatient(prev => ({
      ...prev,
      firstName: editFirstName,
      lastName: editLastName
    }));
    setIsEditing(false);

    if (auth.currentUser) {
      try {
        const userRef = doc(db, 'users', auth.currentUser.uid);
        await updateDoc(userRef, {
          firstName: editFirstName,
          lastName: editLastName,
          updatedAt: new Date().toISOString()
        });
      } catch (e) {
        console.warn('Error saving profile to Firestore:', e);
      }
    }

    showToast(
      language === 'fr' ? 'Profil mis à jour' : 'تم تحديث الملف الشخصي',
      `${editFirstName} ${editLastName}`
    );
  };

  const handleLogout = () => {
    showToast(
      language === 'fr' ? 'Session terminée' : 'تم تسجيل الخروج',
      language === 'fr' ? 'À bientôt sur RIMEDIC' : 'إلى اللقاء على ريميديك',
      'info'
    );
    navigateTo('auth-login');
  };

  return (
    <div className="flex flex-col w-full pb-28">
      {/* En-tête Profil Utilisateur */}
      <section className="px-4 pt-3 pb-2">
        <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container relative overflow-hidden">
          <div className="flex items-start gap-3.5 relative z-10">
            {/* Avatar Médaillon */}
            <div className="relative shrink-0">
              <div className="w-16 h-16 rounded-full bg-secondary-container flex items-center justify-center shadow-inner">
                <span className="text-base font-bold text-on-secondary-container tracking-wider">
                  {patient.firstName.charAt(0)}{patient.lastName.charAt(0)}
                </span>
              </div>
              <div
                className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary flex items-center justify-center text-on-primary shadow-sm"
                title={language === 'fr' ? "Profil vérifié" : "ملف موثق"}
              >
                <span className="material-symbols-outlined text-[14px]">verified</span>
              </div>
            </div>

            {/* Détails Patient */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h1 className="font-bold text-base text-on-surface truncate">
                  {patient.firstName} {patient.lastName}
                </h1>
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  aria-label={language === 'fr' ? "Modifier profil" : "تعديل الملف"}
                  className="text-primary hover:text-primary-container p-1 rounded-lg transition-colors"
                  type="button"
                >
                  <span className="material-symbols-outlined text-[20px]">
                    {isEditing ? 'close' : 'edit_note'}
                  </span>
                </button>
              </div>

              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs text-on-surface-variant font-medium">{patient.phone}</span>
                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold">
                  <span className="material-symbols-outlined text-[11px]">check_circle</span>
                  <span>{language === 'fr' ? 'Vérifié' : 'مفعل'}</span>
                </span>
              </div>

              <div className="flex items-center gap-1 mt-1 text-on-surface-variant text-xs">
                <span className="material-symbols-outlined text-[14px]">badge</span>
                <span className="font-medium tracking-wide">NNI : {patient.nni.slice(0, 4)}••••{patient.nni.slice(-2)}</span>
              </div>

              {patient.organization && (
                <div className="flex items-center gap-1.5 mt-1 text-xs">
                  <span className="material-symbols-outlined text-[14px] text-primary">domain</span>
                  <span className="font-semibold text-primary text-[11px] truncate">
                    {patient.organization}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Inline Edit Form */}
          {isEditing && (
            <div className="mt-3 pt-3 border-t border-surface-container flex flex-col gap-2">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={editFirstName}
                  onChange={e => setEditFirstName(e.target.value)}
                  placeholder={language === 'fr' ? "Prénom" : "الاسم الأول"}
                  className="px-3 py-1.5 rounded-lg bg-surface-container-low text-xs border border-surface-container outline-none"
                />
                <input
                  type="text"
                  value={editLastName}
                  onChange={e => setEditLastName(e.target.value)}
                  placeholder={language === 'fr' ? "Nom" : "اللقب"}
                  className="px-3 py-1.5 rounded-lg bg-surface-container-low text-xs border border-surface-container outline-none"
                />
              </div>
              <button
                onClick={handleSaveProfile}
                className="py-1.5 px-3 bg-primary text-white rounded-lg text-xs font-bold shadow-xs"
              >
                {language === 'fr' ? 'Enregistrer modifications' : 'حفظ التعديلات'}
              </button>
            </div>
          )}

          {/* Quick Pill Action Bar */}
          <div className="mt-3 pt-3 border-t border-surface-container flex items-center justify-between gap-2 text-xs">
            <span className="inline-flex items-center gap-1 text-secondary font-semibold">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
              <span>{language === 'fr' ? 'Dossier Médical RIMEDIC actif' : 'الملف الطبي نشط ومحدث'}</span>
            </span>

            <button
              onClick={() => setIsEditing(!isEditing)}
              className="px-2.5 py-1 rounded-lg bg-surface-container text-primary font-bold hover:bg-surface-container-high transition-colors"
            >
              {language === 'fr' ? 'Modifier les infos' : 'تعديل البيانات'}
            </button>
          </div>
        </div>
      </section>

      {/* Carte Couverture Santé & Assurance CNAM / CNASS Mauritanie */}
      <section className="px-4 py-1.5">
        <div className="bg-gradient-to-br from-[#006948] to-[#00855d] rounded-2xl p-4 text-white shadow-md relative overflow-hidden">
          <div className="absolute -right-6 -bottom-6 w-28 h-28 rounded-full bg-white/10 pointer-events-none"></div>

          <div className="flex items-start justify-between gap-2 relative z-10">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-white/80">
                {language === 'fr' ? 'Régime Obligatoire & Prise en charge' : 'نظام التأمين الإجباري والتغطية'}
              </span>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="material-symbols-outlined text-[20px] text-tertiary-fixed">health_and_safety</span>
                <h2 className="text-base font-bold">{language === 'fr' ? 'CNAM Mauritanie' : 'الصندوق الوطني للتأمين الصحي (كنام)'}</h2>
              </div>
            </div>
            <span className="px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-xs text-white text-[10px] font-bold">
              {language === 'fr' ? 'Conventionné' : 'معتمد'}
            </span>
          </div>

          <div className="mt-3 bg-white/10 rounded-xl p-3 backdrop-blur-xs relative z-10 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-[10px] uppercase text-white/70 font-semibold">{language === 'fr' ? 'N° IMMATRICULATION' : 'رقم التسجيل بالتأمين'}</span>
              <span className="font-mono font-bold tracking-wider text-xs">
                {patient.insuranceNumber || 'CNAM-849-012948-2'}
              </span>
            </div>
            <div className="mt-2 pt-2 border-t border-white/15 flex items-center gap-1.5 text-white/90 text-xs">
              <span className="material-symbols-outlined text-[16px] text-secondary-fixed">verified</span>
              <span>{language === 'fr' ? 'Tiers-payant actif : Consultations & Radiologie' : 'دفع مباشر نشط : استشارات وأشعة'}</span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between gap-2 relative z-10">
            <button
              onClick={() => showToast(
                language === 'fr' ? 'Carte CNASS / CNAM' : 'بطاقة التأمين كنام / كناص',
                language === 'fr' ? 'Télétransmission automatique active.' : 'الربط الرقمي التلقائي مفعل.'
              )}
              className="flex-1 py-2 px-3 rounded-xl bg-white text-primary text-xs font-bold text-center shadow-xs hover:bg-slate-100 transition-colors"
              type="button"
            >
              {language === 'fr' ? 'Mettre à jour / Carte CNASS' : 'تحديث بطاقة التأمين'}
            </button>
            <button
              onClick={() => showToast(
                language === 'fr' ? 'Justificatif CNAM' : 'إفادة كنام',
                language === 'fr' ? 'Matricule officiel vérifié.' : 'رقم التأمين الرسمي موثق.'
              )}
              aria-label={language === 'fr' ? "Afficher justificatif" : "عرض الإفادة"}
              className="p-2 rounded-xl bg-white/15 text-white hover:bg-white/25 transition-colors"
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">visibility</span>
            </button>
          </div>
        </div>
      </section>

      {/* Raccourcis Rapides (Pass QR Code & Documents) */}
      <section className="px-4 py-1.5">
        <div className="grid grid-cols-2 gap-2">
          {/* Pass QR Code Clinique */}
          <button
            onClick={() => navigateTo('appointments')}
            className="bg-surface-container-lowest p-3 rounded-2xl text-left shadow-xs border border-surface-container hover:shadow-sm transition-all flex flex-col justify-between"
            type="button"
          >
            <div className="flex items-center justify-between w-full mb-2">
              <div className="w-9 h-9 rounded-xl bg-secondary-container text-on-secondary-container flex items-center justify-center">
                <span className="material-symbols-outlined text-[20px]">qr_code_2</span>
              </div>
              <span className="w-2 h-2 rounded-full bg-primary"></span>
            </div>
            <div>
              <span className="text-xs font-bold text-on-surface block leading-tight">
                {language === 'fr' ? 'Pass Accueil' : 'بطاقة الدخول'}
              </span>
              <span className="text-[11px] text-on-surface-variant block mt-0.5">
                {language === 'fr' ? 'Badge numérique QR' : 'رمز الاستجابة السريع'}
              </span>
            </div>
          </button>

          {/* Mes Documents Médicaux */}
          <button
            onClick={() => showToast(
              language === 'fr' ? 'Mes Documents' : 'وثائقي الطبية',
              language === 'fr' ? '3 ordonnances et comptes-rendus archivés.' : '٣ وصفات وتقارير محفوظة في الأرشيف.'
            )}
            className="bg-surface-container-lowest p-3 rounded-2xl text-left shadow-xs border border-surface-container hover:shadow-sm transition-all flex flex-col justify-between"
            type="button"
          >
            <div className="flex items-center justify-between w-full mb-2">
              <div className="w-9 h-9 rounded-xl bg-surface-container text-primary flex items-center justify-center">
                <span className="material-symbols-outlined text-[20px]">folder_open</span>
              </div>
              <span className="px-1.5 py-0.2 rounded-full bg-primary/10 text-primary text-[10px] font-bold">
                {language === 'fr' ? '3 docs' : '٣ وثائق'}
              </span>
            </div>
            <div>
              <span className="text-xs font-bold text-on-surface block leading-tight">
                {language === 'fr' ? 'Documents' : 'الوثائق الصحية'}
              </span>
              <span className="text-[11px] text-on-surface-variant block mt-0.5">
                {language === 'fr' ? 'Analyses & ordonnances' : 'فحوصات ووصفات'}
              </span>
            </div>
          </button>
        </div>
      </section>

      {/* Navigation Menu Groups from Stitch */}
      <section className="px-4 pt-1 space-y-3">
        {/* Groupe: Dossier & Santé */}
        <div className="bg-surface-container-lowest rounded-2xl shadow-xs border border-surface-container overflow-hidden">
          <div className="px-4 pt-3 pb-1 text-on-surface-variant text-[10px] font-bold uppercase tracking-wider">
            {language === 'fr' ? 'Gestion Médicale & Droits' : 'إدارة الملف الطبي'}
          </div>

          <div
            onClick={() => setIsEditing(!isEditing)}
            className="flex items-center justify-between px-4 py-3 hover:bg-surface-container-low transition-colors cursor-pointer border-b border-surface-container/60"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                <span className="material-symbols-outlined text-[18px]">person</span>
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-on-surface block truncate">
                  {language === 'fr' ? 'Informations personnelles' : 'المعلومات الشخصية'}
                </span>
                <span className="text-[11px] text-on-surface-variant block truncate">
                  {language === 'fr' ? "État civil, contact d'urgence, ville" : 'الحالة المدنية، هاتف الطوارئ، المدينة'}
                </span>
              </div>
            </div>
            <span className={`material-symbols-outlined text-outline text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
              chevron_right
            </span>
          </div>

          <div
            onClick={() => showToast(
              language === 'fr' ? 'Régime de Sécurité Sociale' : 'نظام الضمان الصحي',
              language === 'fr' ? 'Conventionné CNAM & CNASS 80%' : 'معتمد كنام وكناص بنسبة تغطية 80%'
            )}
            className="flex items-center justify-between px-4 py-3 hover:bg-surface-container-low transition-colors cursor-pointer border-b border-surface-container/60"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-secondary-container flex items-center justify-center text-on-secondary-container shrink-0">
                <span className="material-symbols-outlined text-[18px]">shield</span>
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-on-surface">
                    {language === 'fr' ? 'Assurance & Tiers-payant' : 'التأمين والدفع المباشر'}
                  </span>
                  <span className="px-1.5 py-0.2 rounded bg-secondary-container text-on-secondary-container text-[10px] font-bold">
                    {language === 'fr' ? 'CNAM' : 'كنام'}
                  </span>
                </div>
                <span className="text-[11px] text-on-surface-variant block truncate">
                  {language === 'fr' ? 'CNAM, CNASS, mutuelles et statuts' : 'كنام، كناص، الصناديق التكافلية والحالة'}
                </span>
              </div>
            </div>
            <span className={`material-symbols-outlined text-outline text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
              chevron_right
            </span>
          </div>

          <div
            onClick={() => navigateTo('appointments')}
            className="flex items-center justify-between px-4 py-3 hover:bg-surface-container-low transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-surface-container-high flex items-center justify-center text-primary shrink-0">
                <span className="material-symbols-outlined text-[18px]">event_note</span>
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-on-surface block truncate">
                  {language === 'fr' ? 'Historique des rendez-vous' : 'سجل المواعيد الطبية'}
                </span>
                <span className="text-[11px] text-on-surface-variant block truncate">
                  {language === 'fr'
                    ? `${upcomingCount} prévu • ${completedCount} archivés`
                    : `${upcomingCount} قادم • ${completedCount} منجز`}
                </span>
              </div>
            </div>
            <span className={`material-symbols-outlined text-outline text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
              chevron_right
            </span>
          </div>
        </div>

        {/* Groupe: Préférences & Système */}
        <div className="bg-surface-container-lowest rounded-2xl shadow-xs border border-surface-container overflow-hidden">
          <div className="px-4 pt-3 pb-1 text-on-surface-variant text-[10px] font-bold uppercase tracking-wider">
            {language === 'fr' ? 'Préférences & Notifications' : 'التفضيلات والإشعارات'}
          </div>

          {/* SMS Toggle */}
          <div className="flex items-center justify-between px-4 py-3 hover:bg-surface-container-low transition-colors border-b border-surface-container/60">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-on-surface-variant shrink-0">
                <span className="material-symbols-outlined text-[18px]">notifications_active</span>
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-on-surface block truncate">
                  {language === 'fr' ? 'Rappels de RDV & SMS' : 'تذكير المواعيد عبر الرسائل النصية (SMS)'}
                </span>
                <span className="text-[11px] text-on-surface-variant block truncate">
                  {language === 'fr' ? 'SMS 24h avant & alertes cliniques' : 'رسالة قبل ٢٤ ساعة وتنبيهات العيادة'}
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                setSmsEnabled(!smsEnabled);
                showToast(
                  language === 'fr' ? 'Rappels SMS' : 'التذكير عبر SMS',
                  !smsEnabled
                    ? (language === 'fr' ? 'Activé (Opérateurs Mauritel/Mattel)' : 'مفعل (شبكات موريتل، ماتال، شنقيتل)')
                    : (language === 'fr' ? 'Désactivé' : 'معطل')
                );
              }}
              className="px-2 py-0.5 rounded-full text-xs font-bold text-primary bg-secondary-container"
            >
              {smsEnabled
                ? (language === 'fr' ? 'Activé' : 'مفعل')
                : (language === 'fr' ? 'Désactivé' : 'معطل')}
            </button>
          </div>

          {/* Sélecteur de Langue */}
          <div className="flex items-center justify-between px-4 py-3 hover:bg-surface-container-low transition-colors border-b border-surface-container/60">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-on-surface-variant shrink-0">
                <span className="material-symbols-outlined text-[18px]">translate</span>
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-on-surface block truncate">
                  {language === 'fr' ? "Langue d'affichage" : 'لغة التطبيق'}
                </span>
                <span className="text-[11px] text-on-surface-variant block truncate">
                  {language === 'fr' ? 'Français (Mauritanie)' : 'العربية (موريتانيا)'}
                </span>
              </div>
            </div>
            <div className="flex items-center bg-surface-container rounded-full p-0.5 border border-surface-container">
              <button
                onClick={() => setLanguage('fr')}
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  language === 'fr' ? 'bg-white text-primary shadow-xs' : 'text-on-surface-variant'
                }`}
              >
                FR
              </button>
              <button
                onClick={() => setLanguage('ar')}
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  language === 'ar' ? 'bg-white text-primary shadow-xs' : 'text-on-surface-variant'
                }`}
              >
                عربي
              </button>
            </div>
          </div>

          {/* Compte Google Firebase Auth */}
          <div className="flex items-center justify-between px-4 py-3 hover:bg-surface-container-low transition-colors border-b border-surface-container/60">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-secondary-container flex items-center justify-center text-primary shrink-0">
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-on-surface block truncate">
                  {language === 'fr' ? 'Compte Google Mail' : 'حساب Google'}
                </span>
                <span className="text-[11px] text-on-surface-variant block truncate">
                  {firebaseUser ? (firebaseUser.email || (language === 'fr' ? 'Compte Google connecté' : 'حساب Google متصل')) : (language === 'fr' ? 'Non connecté à Google' : 'غير متصل بـ Google')}
                </span>
              </div>
            </div>
            {firebaseUser ? (
              <button
                type="button"
                onClick={logoutFirebase}
                className="text-[11px] font-bold text-outline hover:text-error px-2 py-1 rounded-lg border border-surface-container hover:border-error transition-colors"
              >
                {language === 'fr' ? 'Déconnecter' : 'خروج'}
              </button>
            ) : (
              <button
                type="button"
                onClick={loginWithGoogle}
                className="text-[11px] font-bold text-primary hover:underline px-2.5 py-1 rounded-lg bg-secondary-container/50 border border-secondary-container transition-colors flex items-center gap-1"
              >
                <span>{language === 'fr' ? 'Connexion Google' : 'دخول Google'}</span>
              </button>
            )}
          </div>

          {/* Compte Apple iOS */}
          <div className="flex items-center justify-between px-4 py-3 hover:bg-surface-container-low transition-colors border-b border-surface-container/60">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-black text-white flex items-center justify-center shrink-0">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 0.92-2.87-.93.04-2.02.63-2.66 1.38-.56.65-.97 1.7-.85 2.73 1.03.08 2.05-.56 2.59-1.24z"/>
                </svg>
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-on-surface block truncate">
                  {language === 'fr' ? 'Compte Apple iCloud' : 'حساب Apple iCloud'}
                </span>
                <span className="text-[11px] text-on-surface-variant block truncate">
                  {patient.organization === 'Apple iCloud' || firebaseUser?.providerData?.some(p => p.providerId === 'apple.com')
                    ? (patient.email || firebaseUser?.email || (language === 'fr' ? 'Compte iCloud connecté' : 'حساب iCloud متصل'))
                    : (language === 'fr' ? 'Connexion via @icloud.com' : 'تسجيل الدخول عبر iCloud')}
                </span>
              </div>
            </div>
            {patient.organization === 'Apple iCloud' || firebaseUser?.providerData?.some(p => p.providerId === 'apple.com') ? (
              <span className="text-[11px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                {language === 'fr' ? 'Actif' : 'نشط'}
              </span>
            ) : (
              <button
                type="button"
                onClick={() => setIsAppleModalOpen(true)}
                className="text-[11px] font-bold text-on-surface hover:text-primary px-2.5 py-1 rounded-lg bg-surface-container border border-surface-container transition-colors flex items-center gap-1"
              >
                <span>{language === 'fr' ? 'Connexion iCloud' : 'دخول iCloud'}</span>
              </button>
            )}
          </div>

          {/* Sécurité */}
          <div
            onClick={() => showToast(
              language === 'fr' ? 'Sécurité & Chiffrement' : 'الأمان والتشفير',
              language === 'fr'
                ? 'Données protégées conformément à la loi mauritanienne n° 2017-020'
                : 'البيانات محمية وفقاً للقانون الموريتاني رقم 2017-020 لحماية البيانات الشخصية'
            )}
            className="flex items-center justify-between px-4 py-3 hover:bg-surface-container-low transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-on-surface-variant shrink-0">
                <span className="material-symbols-outlined text-[18px]">lock</span>
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-on-surface block truncate">
                  {language === 'fr' ? 'Sécurité & Confidentialité' : 'الأمان والخصوصية'}
                </span>
                <span className="text-[11px] text-on-surface-variant block truncate">
                  {language === 'fr' ? 'Code secret PIN, appareils reconnus' : 'الرمز السري PIN والأجهزة الموثوقة'}
                </span>
              </div>
            </div>
            <span className={`material-symbols-outlined text-outline text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
              chevron_right
            </span>
          </div>
        </div>
      </section>

      {/* Déconnexion & Changement de compte (Exigence 4 & 32) */}
      <section className="px-4 pt-4 pb-2 flex flex-col items-center">
        <div className="grid grid-cols-2 gap-2 w-full">
          <button
            onClick={switchAccount}
            className="py-3 px-3 rounded-xl bg-surface-container hover:bg-surface-container-high text-on-surface font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-xs active:scale-[0.99] cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px] text-primary">switch_account</span>
            <span>{language === 'fr' ? 'Changer de compte' : 'تبديل الحساب'}</span>
          </button>

          <button
            onClick={logoutUser}
            className="py-3 px-3 rounded-xl bg-error-container text-on-error-container font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-error-container/80 transition-colors shadow-xs active:scale-[0.99] cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">logout</span>
            <span>{language === 'fr' ? 'Se déconnecter' : 'تسجيل الخروج'}</span>
          </button>
        </div>

        <div className="mt-4 text-center">
          <p className="text-[11px] font-bold text-on-surface-variant">
            {language === 'fr' ? 'RIMEDIC Mauritanie • Plateforme Santé' : 'ريميديك موريتانيا • المنصة الصحية الرقمية'}
          </p>
          <p className="text-[10px] text-outline mt-0.5">
            {language === 'fr'
              ? 'Système de Coordination Médicale & Tiers-Payant'
              : 'نظام التنسيق الطبي وخدمات الدفع المباشر كنام وكناص'}
          </p>
        </div>
      </section>

      {/* Apple Sign-In Modal */}
      <AppleSignInModal
        isOpen={isAppleModalOpen}
        onClose={() => setIsAppleModalOpen(false)}
        onConfirmAppleUser={async (email, fullName) => {
          await loginWithAppleCredentials(email, fullName);
        }}
        onRetryRealAppleAuth={async () => {
          try {
            await loginWithApple();
          } catch {
            setIsAppleModalOpen(true);
          }
        }}
      />
    </div>
  );
};
