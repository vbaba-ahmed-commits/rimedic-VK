import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RimedLogo } from '../common/RimedLogo';

interface PractitionerSecurityGateProps {
  onSuccess?: () => void;
}

export const PractitionerSecurityGate: React.FC<PractitionerSecurityGateProps> = ({ onSuccess }) => {
  const { language, unlockPractitionerSession, navigateTo, setCurrentRole, showToast } = useApp();

  const [orderNumber, setOrderNumber] = useState('ONMM-2018-0419');
  const [pinCode, setPinCode] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!orderNumber.trim()) {
      setErrorMessage(
        language === 'fr'
          ? 'Veuillez saisir votre numéro d\'ordre national des médecins.'
          : 'يرجى إدخال رقم تسجيلك في نقابة الأطباء.'
      );
      return;
    }

    // Default accepted PIN is 2026 or any 4 digits for demo testing
    if (pinCode.trim().length < 4) {
      setErrorMessage(
        language === 'fr'
          ? 'Le code PIN doit comporter au moins 4 chiffres (ex: 2026).'
          : 'يجب أن يتكون رمز PIN من 4 أرقام على الأقل (مثال: 2026).'
      );
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      unlockPractitionerSession(orderNumber, pinCode);
      if (onSuccess) {
        onSuccess();
      }
    }, 400);
  };

  const handleQuickDemoUnlock = () => {
    setIsLoading(true);
    setPinCode('2026');
    setOrderNumber('ONMM-2018-0419');
    setTimeout(() => {
      setIsLoading(false);
      unlockPractitionerSession('ONMM-2018-0419', '2026');
      if (onSuccess) {
        onSuccess();
      }
    }, 300);
  };

  const handleBackToPatient = () => {
    setCurrentRole('PATIENT');
    navigateTo('home');
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 py-8 animate-fadeIn text-center">
      <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-xl border border-surface-container flex flex-col items-center gap-4">
        {/* Security Shield Icon */}
        <div className="relative">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-[#006948] flex items-center justify-center border border-emerald-200 shadow-sm">
            <span className="material-symbols-outlined text-[36px]">encrypted</span>
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[#006948] text-white flex items-center justify-center border-2 border-white shadow-xs">
            <span className="material-symbols-outlined text-[14px]">lock</span>
          </div>
        </div>

        {/* Header Title & Badges */}
        <div>
          <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100/80 text-[#006948] text-[10px] font-bold uppercase tracking-wider mb-1.5 border border-emerald-200">
            <span className="material-symbols-outlined text-[13px]">verified_user</span>
            <span>{language === 'fr' ? 'Secret Médical Garanti' : 'السر الطبي مضمون ومحمي'}</span>
          </div>
          <h2 className="text-lg font-black text-on-surface">
            {language === 'fr' ? 'Accès Sécurisé Praticien' : 'الدخول الآمن للأطباء'}
          </h2>
          <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
            {language === 'fr'
              ? 'Conformément à la loi n° 2017-020, cet espace est strictement réservé aux médecins et professionnels de santé agréés.'
              : 'وفقاً للقانون رقم 2017-020، هذا الفضاء مخصص حصرياً للأطباء المعتمدين.'}
          </p>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="w-full p-2.5 rounded-xl bg-error-container text-on-error-container text-xs font-semibold flex items-center gap-2 text-start">
            <span className="material-symbols-outlined text-[18px] text-error shrink-0">error</span>
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Verification Form */}
        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-3 text-start">
          <div>
            <label className="block text-xs font-bold text-on-surface mb-1">
              {language === 'fr' ? 'N° Ordre des Médecins (ONMM) :' : 'رقم التسجيل في نقابة الأطباء:'}
            </label>
            <div className="relative flex items-center">
              <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">badge</span>
              <input
                type="text"
                required
                value={orderNumber}
                onChange={e => setOrderNumber(e.target.value)}
                placeholder="ONMM-2018-0419"
                className="w-full pl-9 pr-3 py-2.5 bg-surface-container-low rounded-xl border border-surface-container text-xs font-bold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-on-surface mb-1">
              {language === 'fr' ? 'Code PIN de Sécurité (4 chiffres) :' : 'رمز PIN السري (٤ أرقام):'}
            </label>
            <div className="relative flex items-center">
              <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">pin</span>
              <input
                type="password"
                required
                maxLength={6}
                value={pinCode}
                onChange={e => setPinCode(e.target.value)}
                placeholder={language === 'fr' ? '•••• (Démovérif: 2026)' : '•••• (تجريبي: 2026)'}
                className="w-full pl-9 pr-3 py-2.5 bg-surface-container-low rounded-xl border border-surface-container text-xs font-bold text-on-surface tracking-widest focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-1 py-3 bg-[#006948] hover:bg-[#015238] text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <span className="material-symbols-outlined text-[18px]">lock_open</span>
                <span>{language === 'fr' ? 'Déverrouiller l\'Espace Praticien' : 'فتح فضاء الطبيب'}</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Demo Credentials */}
        <div className="w-full p-3 rounded-2xl bg-surface-container-low border border-surface-container text-center">
          <span className="text-[10px] font-bold uppercase text-outline tracking-wider block mb-1">
            {language === 'fr' ? 'Testeur / Démonstration RIMEDIC' : 'دخول تجريبي سريع'}
          </span>
          <button
            type="button"
            onClick={handleQuickDemoUnlock}
            className="w-full py-2 px-3 rounded-xl bg-white hover:bg-emerald-50 text-[#006948] border border-emerald-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">touch_app</span>
            <span>{language === 'fr' ? 'Déverrouiller en 1 clic (Dr Mohamed Ould Ahmed)' : 'دخول سريع بنقرة واحدة (د. محمد ولد أحمد)'}</span>
          </button>
        </div>

        {/* Cancel / Back Button */}
        <button
          type="button"
          onClick={handleBackToPatient}
          className="text-xs font-bold text-on-surface-variant hover:text-on-surface py-1 transition-colors cursor-pointer flex items-center gap-1"
        >
          <span className="material-symbols-outlined text-[16px]">arrow_back</span>
          <span>{language === 'fr' ? 'Retourner à l\'Espace Patient' : 'العودة لفضاء المريض'}</span>
        </button>
      </div>
    </div>
  );
};
