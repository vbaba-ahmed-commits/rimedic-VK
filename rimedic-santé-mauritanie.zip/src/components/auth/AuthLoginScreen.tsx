import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RimedLogo } from '../common/RimedLogo';
import { TEST_USER_A, TEST_USER_B, TEST_APPOINTMENTS_A, TEST_APPOINTMENTS_B } from '../../data/mockData';
import { AppleSignInModal } from './AppleSignInModal';

export const AuthLoginScreen: React.FC = () => {
  const {
    language,
    navigateTo,
    setCurrentRole,
    unlockPractitionerSession,
    showToast,
    firebaseUser,
    loginWithGoogle,
    loginWithApple,
    loginWithAppleCredentials,
    logoutUser,
    loginAsPatient,
  } = useApp();

  const [authPortalType, setAuthPortalType] = useState<'patient' | 'practitioner'>('patient');

  // Patient Login state
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [isAppleLoading, setIsAppleLoading] = useState(false);
  const [isAppleModalOpen, setIsAppleModalOpen] = useState(false);
  const [forgotPasswordOpen, setForgotPasswordOpen] = useState(false);
  const [forgotPhone, setForgotPhone] = useState('');

  // Practitioner Login state
  const [orderNumber, setOrderNumber] = useState('ONMM-2018-0419');
  const [practitionerPin, setPractitionerPin] = useState('');
  const [showPractitionerPin, setShowPractitionerPin] = useState(false);
  const [isPractitionerLoading, setIsPractitionerLoading] = useState(false);

  const handleStandardLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) {
      showToast(
        language === 'fr' ? 'Champ requis' : 'حقل مطلوب',
        language === 'fr' ? 'Veuillez saisir votre numéro ou identifiant' : 'يرجى إدخال رقم الهاتف أو اسم المستخدم',
        'warning'
      );
      return;
    }

    // Check if it matches Test User A or B or creates a clean patient session
    const cleanId = identifier.replace(/\s+/g, '');
    let targetProfile = {
      id: `patient-${Date.now()}`,
      firstName: identifier.includes('@') ? identifier.split('@')[0] : 'Patient',
      lastName: '',
      birthDate: '1992-05-10',
      gender: 'male' as const,
      phone: identifier.includes('+222') ? identifier : `+222 ${identifier}`,
      nni: '7491028491',
      city: 'Nouakchott',
      neighborhood: 'Tevragh Zeina',
      insuranceType: 'CNAM' as const,
      insuranceNumber: 'CNAM-2026-9901',
    };

    if (cleanId.includes('45112233') || cleanId.toLowerCase().includes('ahmed')) {
      loginAsPatient(TEST_USER_A, TEST_APPOINTMENTS_A);
      return;
    } else if (cleanId.includes('36998877') || cleanId.toLowerCase().includes('mariem')) {
      loginAsPatient(TEST_USER_B, TEST_APPOINTMENTS_B);
      return;
    }

    loginAsPatient(targetProfile, []);
  };

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    try {
      await loginWithGoogle();
    } catch {
      // Handled in AppContext
    } finally {
      setIsGoogleLoading(false);
    }
  };

  const handleAppleClick = async () => {
    setIsAppleLoading(true);
    try {
      await loginWithApple();
    } catch {
      setIsAppleModalOpen(true);
    } finally {
      setIsAppleLoading(false);
    }
  };

  const handleForgotPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotPasswordOpen(false);
    showToast(
      language === 'fr' ? 'Code de réinitialisation transmis' : 'تم إرسال رمز استعادة الحساب',
      language === 'fr'
        ? `Un code de sécurité a été envoyé par SMS au ${forgotPhone || identifier || 'numéro indiqué'}`
        : 'تم إرسال رمز الأمان عبر رسالة نصية'
    );
  };

  const handlePractitionerLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!orderNumber.trim()) {
      showToast(
        language === 'fr' ? 'N° d\'Ordre requis' : 'رقم التسجيل مطلوب',
        language === 'fr' ? 'Veuillez saisir votre numéro d\'ordre national des médecins (ONMM)' : 'يرجى إدخال رقم التسجيل في نقابة الأطباء',
        'warning'
      );
      return;
    }
    if (practitionerPin.trim().length < 4) {
      showToast(
        language === 'fr' ? 'Code PIN requis' : 'رمز PIN مطلوب',
        language === 'fr' ? 'Le code PIN doit comporter au moins 4 chiffres (ex: 2026)' : 'يجب أن يتكون رمز PIN من 4 أرقام على الأقل',
        'warning'
      );
      return;
    }

    setIsPractitionerLoading(true);
    setTimeout(() => {
      setIsPractitionerLoading(false);
      unlockPractitionerSession(orderNumber, practitionerPin);
      setCurrentRole('PRACTITIONER');
      navigateTo('practitioner-dashboard');
      showToast(
        language === 'fr' ? 'Bienvenue Dr Mohamed' : 'مرحباً د. محمد',
        language === 'fr' ? 'Connexion réussie à votre espace médical' : 'تم تسجيل الدخول إلى فضاء الطبيب بنجاح'
      );
    }, 400);
  };

  const handleQuickPractitionerDemo = () => {
    setIsPractitionerLoading(true);
    setOrderNumber('ONMM-2018-0419');
    setPractitionerPin('2026');
    setTimeout(() => {
      setIsPractitionerLoading(false);
      unlockPractitionerSession('ONMM-2018-0419', '2026');
      setCurrentRole('PRACTITIONER');
      navigateTo('practitioner-dashboard');
      showToast(
        language === 'fr' ? 'Bienvenue Dr Mohamed' : 'مرحباً د. محمد',
        language === 'fr' ? 'Session praticien sécurisée activée' : 'تم تفعيل الجلسة الآمنة للطبيب'
      );
    }, 300);
  };

  return (
    <div className="flex flex-col w-full min-h-[calc(100vh-64px)] justify-between px-4 pt-4 pb-8 max-w-md mx-auto">
      <div className="flex flex-col items-center text-center">
        {/* Official RIMEDIC Logo */}
        <div className="mb-2">
          <RimedLogo size="lg" showText={true} />
        </div>

        {/* Dual Mode Switcher: Soit Patient Soit Praticien */}
        <div className="w-full max-w-sm my-3 p-1 bg-surface-container rounded-2xl flex items-center shadow-2xs border border-surface-container-high">
          <button
            type="button"
            onClick={() => setAuthPortalType('patient')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              authPortalType === 'patient'
                ? 'bg-white text-primary shadow-xs scale-[1.01]'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">person</span>
            <span>{language === 'fr' ? 'Espace Patient' : 'فضاء المريض'}</span>
          </button>

          <button
            type="button"
            onClick={() => setAuthPortalType('practitioner')}
            className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              authPortalType === 'practitioner'
                ? 'bg-[#006948] text-white shadow-xs scale-[1.01]'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">badge</span>
            <span>{language === 'fr' ? 'Espace Praticien' : 'فضاء الطبيب'}</span>
          </button>
        </div>

        {/* ========================================================== */}
        {/* CAS 1 : CONNEXION PATIENT                                  */}
        {/* ========================================================== */}
        {authPortalType === 'patient' ? (
          <div className="w-full flex flex-col items-center">
            <span className="text-[11px] font-bold uppercase tracking-wider text-secondary bg-secondary-container/60 px-3 py-0.5 rounded-full mb-1">
              {language === 'fr' ? 'Plateforme Santé Mauritanie' : 'المنصة الطبية الوطنية في موريتانيا'}
            </span>

            <h2 className="text-xl font-black text-on-surface mb-1">
              {language === 'fr' ? 'Connexion Patient' : 'تسجيل دخول المريض'}
            </h2>
            <p className="text-xs text-on-surface-variant max-w-[340px] leading-relaxed">
              {language === 'fr'
                ? 'Accédez à votre espace patient sécurisé, vos rendez-vous et vos ordonnances.'
                : 'سجل دخولك للوصول إلى مواعيدك الطبية، ملفاتك الصحية والوصفات الطبية.'}
            </p>

            {/* Formulaire Patient */}
            <div className="w-full mt-4 bg-surface-container-lowest rounded-2xl p-5 shadow-sm border border-surface-container text-start">
              <form onSubmit={handleStandardLogin} className="flex flex-col gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-on-surface mb-1">
                    {language === 'fr' ? 'Numéro de téléphone ou Identifiant' : 'رقم الهاتف أو المعرف'}
                  </label>
                  <div className="relative flex items-center">
                    <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">
                      smartphone
                    </span>
                    <input
                      type="text"
                      required
                      value={identifier}
                      onChange={e => setIdentifier(e.target.value)}
                      placeholder={language === 'fr' ? 'Ex: 45 11 22 33 ou email' : 'مثال: 45 11 22 33'}
                      className="w-full pl-9 pr-3 py-2.5 bg-surface-container-low rounded-xl text-xs font-medium text-on-surface border border-surface-container focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-on-surface">
                      {language === 'fr' ? 'Mot de passe ou Code secret' : 'كلمة المرور أو الرمز السري'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setForgotPasswordOpen(true)}
                      className="text-[11px] font-semibold text-primary hover:underline"
                    >
                      {language === 'fr' ? 'Mot de passe oublié ?' : 'نسيت كلمة المرور؟'}
                    </button>
                  </div>
                  <div className="relative flex items-center">
                    <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">
                      lock
                    </span>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-10 py-2.5 bg-surface-container-low rounded-xl text-xs font-medium text-on-surface border border-surface-container focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 text-outline hover:text-on-surface"
                      aria-label={language === 'fr' ? "Afficher le mot de passe" : "عرض كلمة المرور"}
                    >
                      <span className="material-symbols-outlined text-[18px]">
                        {showPassword ? 'visibility_off' : 'visibility'}
                      </span>
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full h-11 bg-primary hover:bg-primary/95 text-on-primary font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition-transform active:scale-[0.99] cursor-pointer mt-1"
                >
                  <span>{language === 'fr' ? 'Se connecter' : 'تسجيل الدخول'}</span>
                  <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
                </button>
              </form>

              {/* Lien Inscription */}
              <div className="mt-4 pt-3 border-t border-surface-container/60 text-center">
                <p className="text-xs text-on-surface-variant">
                  {language === 'fr' ? 'Vous n\'avez pas encore de compte ?' : 'ليس لديك حساب بعد؟'}{' '}
                  <button
                    type="button"
                    onClick={() => navigateTo('auth-register')}
                    className="font-bold text-primary hover:underline ml-1"
                  >
                    {language === 'fr' ? 'Créer un compte' : 'إنشاء حساب جديد'}
                  </button>
                </p>
              </div>

              <div className="relative flex py-3 items-center">
                <div className="flex-grow border-t border-surface-container"></div>
                <span className="flex-shrink mx-2 text-[10px] uppercase font-bold text-outline">
                  {language === 'fr' ? 'Ou continuer avec' : 'أو المتابعة عبر'}
                </span>
                <div className="flex-grow border-t border-surface-container"></div>
              </div>

              {/* Boutons Fournisseurs Externes */}
              <div className="flex flex-col gap-2">
                <button
                  type="button"
                  disabled={isGoogleLoading}
                  onClick={handleGoogleSignIn}
                  className="w-full h-11 bg-white hover:bg-slate-50 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 shadow-xs flex items-center justify-center gap-2.5 transition-all active:scale-[0.99] disabled:opacity-60 cursor-pointer"
                >
                  {isGoogleLoading ? (
                    <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                    </svg>
                  )}
                  <span>
                    {language === 'fr' ? 'Se connecter avec Google' : 'تسجيل الدخول عبر Google'}
                  </span>
                </button>

                <button
                  type="button"
                  disabled={isAppleLoading}
                  onClick={handleAppleClick}
                  className="w-full h-11 bg-black hover:bg-neutral-900 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2.5 transition-all active:scale-[0.99] disabled:opacity-60 cursor-pointer"
                >
                  {isAppleLoading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 0.92-2.87-.93.04-2.02.63-2.66 1.38-.56.65-.97 1.7-.85 2.73 1.03.08 2.05-.56 2.59-1.24z"/>
                    </svg>
                  )}
                  <span>
                    {language === 'fr' ? 'Se connecter avec Apple ID' : 'تسجيل الدخول مع Apple ID'}
                  </span>
                </button>
              </div>
            </div>

            {/* Test Multi-Utilisateurs Patient */}
            <div className="w-full mt-4 bg-surface-container-low rounded-2xl p-3.5 border border-surface-container text-start">
              <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-secondary mb-1">
                <span className="material-symbols-outlined text-[15px]">verified_user</span>
                <span>{language === 'fr' ? 'Comptes Patients Démonstration' : 'حسابات تجريبية للمرضى'}</span>
              </div>
              <p className="text-[11px] text-on-surface-variant mb-2.5 leading-relaxed">
                {language === 'fr'
                  ? 'Connectez-vous en 1 clic avec deux profils distincts pour vérifier l\'isolation des données :'
                  : 'قم بالتبديل بين الحسابين التاليين للتأكد من عزل البيانات تماماً:'}
              </p>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => loginAsPatient(TEST_USER_A, TEST_APPOINTMENTS_A)}
                  className="p-2.5 bg-white hover:bg-emerald-50 border border-emerald-200/80 rounded-xl text-start transition-all active:scale-[0.98] shadow-2xs cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-[10px] font-black uppercase text-emerald-700 bg-emerald-100 px-1.5 py-0.2 rounded">
                      {language === 'fr' ? 'Patient A' : 'المريض (أ)'}
                    </span>
                    <span className="text-[10px] text-outline">CNAM</span>
                  </div>
                  <p className="font-bold text-xs text-on-surface truncate">Ahmed Ould Cheikh</p>
                  <p className="text-[10px] text-on-surface-variant truncate">
                    {language === 'fr' ? '2 rendez-vous' : 'موعدان'}
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => loginAsPatient(TEST_USER_B, TEST_APPOINTMENTS_B)}
                  className="p-2.5 bg-white hover:bg-sky-50 border border-sky-200/80 rounded-xl text-start transition-all active:scale-[0.98] shadow-2xs cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-[10px] font-black uppercase text-sky-700 bg-sky-100 px-1.5 py-0.2 rounded">
                      {language === 'fr' ? 'Patient B' : 'المريض (ب)'}
                    </span>
                    <span className="text-[10px] text-outline">CNASS</span>
                  </div>
                  <p className="font-bold text-xs text-on-surface truncate">Mariem Mint Bilal</p>
                  <p className="text-[10px] text-on-surface-variant truncate">
                    {language === 'fr' ? '1 rendez-vous' : 'موعد واحد'}
                  </p>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* ========================================================== */
          /* CAS 2 : CONNEXION PRATICIEN (MÉDECINS & SPÉCIALISTES)     */
          /* ========================================================== */
          <div className="w-full flex flex-col items-center">
            <span className="inline-flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-[#006948] bg-emerald-100 px-3 py-0.5 rounded-full mb-1 border border-emerald-200">
              <span className="material-symbols-outlined text-[13px]">verified_user</span>
              <span>{language === 'fr' ? 'Secret Médical • ONMM' : 'نقابة الأطباء الموريتانية'}</span>
            </span>

            <h2 className="text-xl font-black text-on-surface mb-1">
              {language === 'fr' ? 'Connexion Praticien' : 'تسجيل دخول الطبيب'}
            </h2>
            <p className="text-xs text-on-surface-variant max-w-[340px] leading-relaxed">
              {language === 'fr'
                ? 'Espace réservé aux médecins : gérez votre agenda, vos horaires de consultation et vos patients.'
                : 'فضاء مخصص للأطباء: إدارة جدول المواعيد، ساعات الاستشارة وملفات المرضى.'}
            </p>

            {/* Formulaire Praticien */}
            <div className="w-full mt-4 bg-surface-container-lowest rounded-2xl p-5 shadow-sm border border-emerald-200/80 text-start">
              <form onSubmit={handlePractitionerLogin} className="flex flex-col gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-on-surface mb-1">
                    {language === 'fr' ? 'N° d\'Ordre des Médecins (ONMM) ou Email Pro' : 'رقم نقابة الأطباء أو البريد المهني'}
                  </label>
                  <div className="relative flex items-center">
                    <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">
                      badge
                    </span>
                    <input
                      type="text"
                      required
                      value={orderNumber}
                      onChange={e => setOrderNumber(e.target.value)}
                      placeholder="ONMM-2018-0419"
                      className="w-full pl-9 pr-3 py-2.5 bg-surface-container-low rounded-xl text-xs font-bold text-on-surface border border-surface-container focus:outline-none focus:ring-2 focus:ring-[#006948]"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-on-surface">
                      {language === 'fr' ? 'Code PIN de Sécurité (4 chiffres)' : 'رمز PIN السري (٤ أرقام)'}
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        showToast(
                          language === 'fr' ? 'Support Ordre des Médecins' : 'دعم نقابة الأطباء',
                          language === 'fr' ? 'Code PIN démo : 2026. En cabinet : contactez le +222 45 25 00 00' : 'رمز PIN التجريبي: 2026'
                        );
                      }}
                      className="text-[11px] font-semibold text-[#006948] hover:underline"
                    >
                      {language === 'fr' ? 'Code oublié ?' : 'نسيت الرمز؟'}
                    </button>
                  </div>
                  <div className="relative flex items-center">
                    <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">
                      pin
                    </span>
                    <input
                      type={showPractitionerPin ? 'text' : 'password'}
                      required
                      maxLength={6}
                      value={practitionerPin}
                      onChange={e => setPractitionerPin(e.target.value)}
                      placeholder={language === 'fr' ? '•••• (Démovérif: 2026)' : '•••• (تجريبي: 2026)'}
                      className="w-full pl-9 pr-10 py-2.5 bg-surface-container-low rounded-xl text-xs font-bold text-on-surface tracking-widest border border-surface-container focus:outline-none focus:ring-2 focus:ring-[#006948]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPractitionerPin(!showPractitionerPin)}
                      className="absolute right-3 text-outline hover:text-on-surface"
                      aria-label={language === 'fr' ? 'Afficher le code PIN' : 'إظهار الرمز السري'}
                    >
                      <span className="material-symbols-outlined text-[18px]">
                        {showPractitionerPin ? 'visibility_off' : 'visibility'}
                      </span>
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isPractitionerLoading}
                  className="w-full h-11 bg-[#006948] hover:bg-[#015238] text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-2 transition-transform active:scale-[0.99] cursor-pointer mt-1 disabled:opacity-60"
                >
                  {isPractitionerLoading ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span className="material-symbols-outlined text-[18px]">lock_open</span>
                      <span>{language === 'fr' ? 'Se connecter à mon Espace Praticien' : 'دخول فضاء الطبيب'}</span>
                    </>
                  )}
                </button>
              </form>

              {/* Accès Démo Praticien 1-clic */}
              <div className="mt-4 pt-3 border-t border-surface-container/60">
                <span className="text-[10px] font-bold uppercase text-outline tracking-wider block mb-1.5 text-center">
                  {language === 'fr' ? 'Accès Démonstration Praticien' : 'دخول تجريبي للطبيب'}
                </span>
                <button
                  type="button"
                  onClick={handleQuickPractitionerDemo}
                  className="w-full py-2.5 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-[#006948] border border-emerald-300 font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-2xs cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[18px]">stethoscope</span>
                  <span>{language === 'fr' ? 'Connexion Rapide : Dr Mohamed Ould Ahmed' : 'دخول سريع: د. محمد ولد أحمد'}</span>
                </button>
              </div>
            </div>

            {/* Assistance & Déontologie */}
            <div className="w-full mt-4 p-3 rounded-2xl bg-surface-container-low border border-surface-container text-xs text-on-surface-variant flex items-start gap-2.5 text-start">
              <span className="material-symbols-outlined text-[18px] text-[#006948] shrink-0 mt-0.5">
                verified
              </span>
              <div>
                <span className="font-bold text-on-surface block text-[11px]">
                  {language === 'fr' ? 'Secret Médical & Loi n° 2017-020' : 'حماية البيانات الطبية'}
                </span>
                <span className="text-[10px] text-on-surface-variant leading-relaxed">
                  {language === 'fr'
                    ? 'Espace réservé aux praticiens certifiés. Pour raccorder un nouveau cabinet : +222 45 25 00 00.'
                    : 'فضاء مخصص للأطباء المعتمدين في موريتانيا وفقاً للقانون الصحي.'}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Security Footer */}
      <div className="mt-4 text-center text-[10px] text-outline">
        <p>
          {language === 'fr'
            ? 'Hébergement Cloud Firestore RIMEDIC • Données de santé protégées en Mauritanie'
            : 'استضافة سحابية مشفرة RIMEDIC • بيانات صحية مؤمنة في موريتانيا'}
        </p>
      </div>

      {/* Modal Mot de passe oublié */}
      {forgotPasswordOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-sm bg-white rounded-2xl p-5 shadow-xl border border-surface-container text-start">
            <h3 className="font-bold text-base text-on-surface mb-1">
              {language === 'fr' ? 'Réinitialiser le mot de passe' : 'استعادة كلمة المرور'}
            </h3>
            <p className="text-xs text-on-surface-variant mb-3">
              {language === 'fr'
                ? 'Saisissez votre numéro de téléphone mauritanien pour recevoir un code SMS.'
                : 'أدخل رقم هاتفك لتلقي رمز التحقق عبر الرسائل النصية.'}
            </p>
            <form onSubmit={handleForgotPasswordSubmit} className="flex flex-col gap-3">
              <input
                type="tel"
                required
                value={forgotPhone}
                onChange={e => setForgotPhone(e.target.value)}
                placeholder="+222 45 00 00 00"
                className="w-full px-3 py-2 bg-surface-container-low rounded-xl text-xs font-medium border border-surface-container focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <div className="flex items-center justify-end gap-2 mt-1">
                <button
                  type="button"
                  onClick={() => setForgotPasswordOpen(false)}
                  className="px-3 py-2 text-xs font-bold text-on-surface-variant hover:bg-surface-container rounded-lg"
                >
                  {language === 'fr' ? 'Annuler' : 'إلغاء'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-primary text-white text-xs font-bold rounded-lg shadow-xs"
                >
                  {language === 'fr' ? 'Envoyer le code' : 'إرسال الرمز'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Apple Sign-In Modal */}
      <AppleSignInModal
        isOpen={isAppleModalOpen}
        onClose={() => setIsAppleModalOpen(false)}
        onConfirmAppleUser={loginWithAppleCredentials}
        onRetryRealAppleAuth={handleAppleClick}
      />
    </div>
  );
};
