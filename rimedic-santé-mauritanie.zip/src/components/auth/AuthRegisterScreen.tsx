import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { InsuranceType } from '../../types';

export const AuthRegisterScreen: React.FC = () => {
  const { language, navigateTo, setPatient, showToast, isRtl } = useApp();

  const [firstName, setFirstName] = useState('Mohamed');
  const [lastName, setLastName] = useState('Ould Bilal');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [nni, setNni] = useState('4829104821');
  const [wilaya, setWilaya] = useState('Nouakchott (Tevragh Zeina)');
  const [insurance, setInsurance] = useState<InsuranceType>('CNAM');
  const [insuranceNumber, setInsuranceNumber] = useState('849-012948-2');
  const [hasFileUploaded, setHasFileUploaded] = useState(true);
  const [agreed, setAgreed] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreed) {
      showToast(
        language === 'fr' ? 'Consentement requis' : 'الموافقة مطلوبة',
        language === 'fr' ? 'Veuillez accepter les conditions d\'utilisation' : 'يرجى الموافقة على شروط الاستخدام',
        'warning'
      );
      return;
    }

    setPatient({
      id: `pat-${Date.now()}`,
      firstName,
      lastName,
      birthDate: '1992-11-14',
      gender,
      phone: '+222 45 25 00 00',
      nni,
      city: 'Nouakchott',
      neighborhood: 'Tevragh Zeina',
      insuranceType: insurance,
      insuranceNumber: insuranceNumber,
    });

    showToast(
      language === 'fr' ? 'Compte patient créé !' : 'تم إنشاء حساب المريض بنجاح !',
      `${firstName} ${lastName} • ${insurance} ${language === 'fr' ? 'Validé' : 'مؤكد'}`
    );
    navigateTo('home');
  };

  return (
    <div className="flex flex-col w-full max-w-md mx-auto pb-12">
      {/* Progress Tracker from Stitch */}
      <div className="px-4 pt-3 pb-2 bg-surface-container-low border-b border-surface-container">
        <div className="flex items-center justify-between relative px-2">
          <div className="absolute left-6 right-6 top-3 h-0.5 bg-surface-container-highest -z-0">
            <div className="h-full bg-primary" style={{ width: '50%' }}></div>
          </div>

          <div className="flex flex-col items-center gap-1 relative z-10">
            <div className="w-7 h-7 rounded-full bg-primary text-on-primary flex items-center justify-center text-xs shadow-xs">
              <span className="material-symbols-outlined text-[16px]">check</span>
            </div>
            <span className="text-[10px] font-bold text-primary">
              {language === 'fr' ? 'Téléphone' : 'الهاتف'}
            </span>
          </div>

          <div className="flex flex-col items-center gap-1 relative z-10">
            <div className="w-7 h-7 rounded-full bg-primary text-on-primary flex items-center justify-center text-xs shadow-md ring-4 ring-secondary-container">
              <span className="material-symbols-outlined text-[16px]">badge</span>
            </div>
            <span className="text-[10px] font-bold text-primary">
              {language === 'fr' ? 'Identité' : 'الهوية'}
            </span>
          </div>

          <div className="flex flex-col items-center gap-1 relative z-10">
            <div className="w-7 h-7 rounded-full bg-surface-container-highest text-on-surface-variant flex items-center justify-center text-xs">
              <span className="material-symbols-outlined text-[16px]">verified_user</span>
            </div>
            <span className="text-[10px] text-on-surface-variant">
              {language === 'fr' ? 'Finalisation' : 'التأكيد'}
            </span>
          </div>
        </div>
      </div>

      {/* Intro Greeting */}
      <div className="px-4 pt-4 pb-2">
        <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[11px] font-bold mb-1">
          <span className="material-symbols-outlined text-[14px]">shield</span>
          <span>{language === 'fr' ? 'Dossier Médical Sécurisé' : 'الملف الطبي المؤمن'}</span>
        </div>
        <h2 className="text-xl font-bold text-on-surface">
          {language === 'fr' ? 'Créer mon compte patient' : 'إنشاء حساب مريض جديد'}
        </h2>
        <p className="text-xs text-on-surface-variant mt-0.5 leading-relaxed">
          {language === 'fr'
            ? 'Renseignez vos informations pour faciliter la prise en charge de vos consultations et le tiers-payant.'
            : 'أدخل بياناتك لتسهيل تنظيم مواعيدك والاستفادة من خدمات الدفع الجزئي والتأمين الصحي.'}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="px-4 flex flex-col gap-3 mt-2">
        {/* Section 1: Informations personnelles */}
        <div className="bg-surface-container-lowest p-4 rounded-2xl shadow-sm border border-surface-container flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-secondary-container flex items-center justify-center text-primary">
              <span className="material-symbols-outlined text-[18px]">person</span>
            </div>
            <div>
              <h3 className="font-bold text-xs text-on-surface">
                {language === 'fr' ? 'Informations personnelles' : 'المعلومات الشخصية'}
              </h3>
              <p className="text-[10px] text-on-surface-variant">
                {language === 'fr' ? 'Conformes aux pièces officielles mauritaniennes' : 'مطابقة للوثائق الرسمية الموريتانية'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-on-surface">
                {language === 'fr' ? 'Prénom' : 'الاسم الأول'}
              </label>
              <input
                type="text"
                value={firstName}
                onChange={e => setFirstName(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-xl bg-surface-container-low text-xs text-on-surface font-semibold border border-surface-container focus:bg-white outline-none"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-on-surface">
                {language === 'fr' ? 'Nom de famille' : 'اسم العائلة'}
              </label>
              <input
                type="text"
                value={lastName}
                onChange={e => setLastName(e.target.value)}
                required
                className="w-full px-3 py-2 rounded-xl bg-surface-container-low text-xs text-on-surface font-semibold border border-surface-container focus:bg-white outline-none"
              />
            </div>
          </div>

          {/* Date de naissance */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-on-surface">
              {language === 'fr' ? 'Date de naissance' : 'تاريخ الميلاد'}
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              <select className="px-2 py-2 rounded-xl bg-surface-container-low text-xs font-semibold text-on-surface border border-surface-container outline-none">
                <option>14</option>
                <option>01</option>
                <option>05</option>
                <option>20</option>
                <option>28</option>
              </select>
              <select className="px-2 py-2 rounded-xl bg-surface-container-low text-xs font-semibold text-on-surface border border-surface-container outline-none">
                <option>{language === 'fr' ? 'Novembre' : 'نوفمبر'}</option>
                <option>{language === 'fr' ? 'Janvier' : 'يناير'}</option>
                <option>{language === 'fr' ? 'Avril' : 'أبريل'}</option>
                <option>{language === 'fr' ? 'Août' : 'أغسطس'}</option>
              </select>
              <select className="px-2 py-2 rounded-xl bg-surface-container-low text-xs font-semibold text-on-surface border border-surface-container outline-none">
                <option>1992</option>
                <option>1985</option>
                <option>1990</option>
                <option>1998</option>
                <option>2002</option>
              </select>
            </div>
          </div>

          {/* Sexe */}
          <div className="flex flex-col gap-1">
            <span className="text-xs font-bold text-on-surface">
              {language === 'fr' ? 'Sexe' : 'الجنس'}
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setGender('male')}
                className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  gender === 'male'
                    ? 'bg-primary text-white shadow-xs'
                    : 'bg-surface-container-low text-on-surface-variant border border-surface-container'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">male</span>
                <span>{language === 'fr' ? 'Homme' : 'ذكر'}</span>
              </button>
              <button
                type="button"
                onClick={() => setGender('female')}
                className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                  gender === 'female'
                    ? 'bg-primary text-white shadow-xs'
                    : 'bg-surface-container-low text-on-surface-variant border border-surface-container'
                }`}
              >
                <span className="material-symbols-outlined text-[16px]">female</span>
                <span>{language === 'fr' ? 'Femme' : 'أنثى'}</span>
              </button>
            </div>
          </div>

          {/* NNI */}
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-xs">
              <label className="font-bold text-on-surface">
                {language === 'fr' ? "Numéro National d'Identification (NNI)" : 'الرقم الوطني للتعريف (NNI)'}
              </label>
              <span className="text-primary font-bold text-[10px]">
                {language === 'fr' ? 'Biométrie' : 'بيومتري'}
              </span>
            </div>
            <div className="relative">
              <input
                type="text"
                maxLength={10}
                value={nni}
                onChange={e => setNni(e.target.value.replace(/\D/g, ''))}
                className="w-full pl-3 pr-8 py-2 rounded-xl bg-surface-container-low text-xs text-on-surface font-mono font-bold tracking-wider border border-surface-container outline-none"
              />
              <span className="material-symbols-outlined absolute right-2.5 top-1/2 -translate-y-1/2 text-primary text-[18px]">
                check_circle
              </span>
            </div>
            <p className="text-[10px] text-on-surface-variant">
              {language === 'fr'
                ? "10 chiffres figurant sur votre carte d'identité biométrique mauritanienne."
                : '١٠ أرقام مسجلة على بطاقة التعريف الوطنية الموريتانية.'}
            </p>
          </div>

          {/* Wilaya */}
          <div className="flex flex-col gap-1">
            <label className="text-xs font-bold text-on-surface">
              {language === 'fr' ? 'Wilaya & Ville de résidence' : 'الولاية ومقاطعة السكن'}
            </label>
            <select
              value={wilaya}
              onChange={e => setWilaya(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-surface-container-low text-xs text-on-surface font-semibold border border-surface-container outline-none"
            >
              <option value="Nouakchott (Tevragh Zeina)">{language === 'fr' ? 'Nouakchott (Tevragh Zeina)' : 'نواكشوط (تفرغ زينة)'}</option>
              <option value="Nouakchott (Ksar)">{language === 'fr' ? 'Nouakchott (Ksar)' : 'نواكشوط (لكصر)'}</option>
              <option value="Nouakchott (Sebkha)">{language === 'fr' ? 'Nouakchott (Sebkha)' : 'نواكشوط (السبخة)'}</option>
              <option value="Nouakchott (Arafat)">{language === 'fr' ? 'Nouakchott (Arafat)' : 'نواكشوط (عرفات)'}</option>
              <option value="Nouakchott (Dar Naïm)">{language === 'fr' ? 'Nouakchott (Dar Naïm)' : 'نواكشوط (دار النعيم)'}</option>
              <option value="Nouakchott (Toujounine)">{language === 'fr' ? 'Nouakchott (Toujounine)' : 'نواكشوط (توجنين)'}</option>
              <option value="Nouakchott (Teyarett)">{language === 'fr' ? 'Nouakchott (Teyarett)' : 'نواكشوط (تيارت)'}</option>
              <option value="Nouakchott (El Mina)">{language === 'fr' ? 'Nouakchott (El Mina)' : 'نواكشوط (الميناء)'}</option>
              <option value="Nouakchott (Riyadh)">{language === 'fr' ? 'Nouakchott (Riyadh)' : 'نواكشوط (الرياض)'}</option>
            </select>
          </div>
        </div>

        {/* Section 2: Régime d'assurance & Tiers-payant */}
        <div className="bg-surface-container-lowest p-4 rounded-2xl shadow-sm border border-surface-container flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-secondary-container flex items-center justify-center text-primary">
              <span className="material-symbols-outlined text-[18px]">health_and_safety</span>
            </div>
            <div>
              <h3 className="font-bold text-xs text-on-surface">
                {language === 'fr' ? "Régime d'assurance & Tiers-payant" : 'نظام التأمين والدفع الجزئي'}
              </h3>
              <p className="text-[10px] text-on-surface-variant">
                {language === 'fr' ? 'Prise en charge directe en clinique' : 'تغطية ورعاية مباشرة في العيادات'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-2">
            {/* CNAM */}
            <div
              onClick={() => setInsurance('CNAM')}
              className={`p-3 rounded-xl cursor-pointer border flex items-center justify-between transition-all ${
                insurance === 'CNAM'
                  ? 'bg-secondary-container/60 border-primary text-on-secondary-container'
                  : 'bg-surface-container-low border-surface-container text-on-surface'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-primary shadow-xs">
                  <span className="material-symbols-outlined text-[20px]">verified</span>
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs">CNAM Mauritanie</span>
                    <span className="px-1.5 py-0.2 rounded-full bg-primary text-white text-[9px] font-bold">
                      {language === 'fr' ? 'Officiel' : 'رسمي'}
                    </span>
                  </div>
                  <p className="text-[10px] text-on-surface-variant">
                    {language === 'fr' ? "Caisse Nationale d'Assurance Maladie" : 'الصندوق الوطني للتأمين الصحي'}
                  </p>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full flex items-center justify-center ${
                  insurance === 'CNAM' ? 'bg-primary text-white' : 'bg-surface-container text-transparent'
                }`}
              >
                <span className="material-symbols-outlined text-[13px]">check</span>
              </div>
            </div>

            {/* CNASS */}
            <div
              onClick={() => setInsurance('CNASS')}
              className={`p-3 rounded-xl cursor-pointer border flex items-center justify-between transition-all ${
                insurance === 'CNASS'
                  ? 'bg-secondary-container/60 border-primary text-on-secondary-container'
                  : 'bg-surface-container-low border-surface-container text-on-surface'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-secondary shadow-xs">
                  <span className="material-symbols-outlined text-[20px]">diversity_1</span>
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-xs">CNASS</span>
                    <span className="px-1.5 py-0.2 rounded-full bg-secondary-container text-on-secondary-container text-[9px] font-bold">
                      {language === 'fr' ? 'Solidarité' : 'تضامن'}
                    </span>
                  </div>
                  <p className="text-[10px] text-on-surface-variant">
                    {language === 'fr' ? 'Caisse Nat. de Solidarité en Santé' : 'الصندوق الوطني للتضامن الصحي'}
                  </p>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full flex items-center justify-center ${
                  insurance === 'CNASS' ? 'bg-primary text-white' : 'bg-surface-container text-transparent'
                }`}
              >
                <span className="material-symbols-outlined text-[13px]">check</span>
              </div>
            </div>

            {/* Private */}
            <div
              onClick={() => setInsurance('PRIVATE')}
              className={`p-3 rounded-xl cursor-pointer border flex items-center justify-between transition-all ${
                insurance === 'PRIVATE'
                  ? 'bg-secondary-container/60 border-primary text-on-secondary-container'
                  : 'bg-surface-container-low border-surface-container text-on-surface'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-on-surface-variant shadow-xs">
                  <span className="material-symbols-outlined text-[20px]">corporate_fare</span>
                </div>
                <div>
                  <span className="font-bold text-xs">
                    {language === 'fr' ? 'Assurance privée / Mutuelle' : 'تأمين خاص / تعاضدية'}
                  </span>
                  <p className="text-[10px] text-on-surface-variant">Gras Savoye, Taamine, SAAR, etc.</p>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full flex items-center justify-center ${
                  insurance === 'PRIVATE' ? 'bg-primary text-white' : 'bg-surface-container text-transparent'
                }`}
              >
                <span className="material-symbols-outlined text-[13px]">check</span>
              </div>
            </div>

            {/* None */}
            <div
              onClick={() => setInsurance('NONE')}
              className={`p-3 rounded-xl cursor-pointer border flex items-center justify-between transition-all ${
                insurance === 'NONE'
                  ? 'bg-secondary-container/60 border-primary text-on-secondary-container'
                  : 'bg-surface-container-low border-surface-container text-on-surface'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-on-surface-variant shadow-xs">
                  <span className="material-symbols-outlined text-[20px]">payments</span>
                </div>
                <div>
                  <span className="font-bold text-xs">
                    {language === 'fr' ? 'Aucune assurance' : 'بدون تأمين'}
                  </span>
                  <p className="text-[10px] text-on-surface-variant">
                    {language === 'fr'
                      ? 'Règlement direct (Espèces, Bankily, Masrivi)'
                      : 'دفع مباشر (نقداً، بنكيلي، مصريفي)'}
                  </p>
                </div>
              </div>
              <div
                className={`w-5 h-5 rounded-full flex items-center justify-center ${
                  insurance === 'NONE' ? 'bg-primary text-white' : 'bg-surface-container text-transparent'
                }`}
              >
                <span className="material-symbols-outlined text-[13px]">check</span>
              </div>
            </div>
          </div>

          {/* Conditional CNAM / CNASS matricule details */}
          {(insurance === 'CNAM' || insurance === 'CNASS') && (
            <div className="p-3 rounded-xl bg-surface-container-low flex flex-col gap-2.5 border border-surface-container">
              <div className="flex flex-col gap-1">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-bold text-on-surface">
                    {language === 'fr' ? `Numéro d'immatriculation ${insurance}` : `رقم التسجيل في ${insurance}`}
                  </label>
                  <span className="text-primary font-bold text-[10px]">
                    {language === 'fr' ? 'Obligatoire' : 'إجباري'}
                  </span>
                </div>
                <input
                  type="text"
                  value={insuranceNumber}
                  onChange={e => setInsuranceNumber(e.target.value)}
                  placeholder="ex: 849-012948-2"
                  className="w-full px-3 py-2 rounded-xl bg-white text-xs font-mono font-bold text-on-surface border border-surface-container outline-none"
                />
              </div>

              {/* Upload simulation */}
              <div className="flex flex-col gap-1">
                <span className="text-xs font-bold text-on-surface">
                  {language === 'fr' ? `Carte d'assuré ${insurance} (Recommandé)` : `بطاقة التأمين ${insurance} (موصى به)`}
                </span>
                {hasFileUploaded ? (
                  <div className="p-2.5 rounded-xl bg-white flex items-center justify-between border border-surface-container">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="material-symbols-outlined text-primary text-[20px]">photo_camera</span>
                      <div className="truncate">
                        <p className="text-xs font-bold text-on-surface truncate">carte_cnam_recto.jpg</p>
                        <p className="text-[10px] text-primary">
                          {language === 'fr' ? 'Téléchargé avec succès (1.2 Mo)' : 'تم الرفع بنجاح (١.٢ ميغابايت)'}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setHasFileUploaded(false)}
                      className="text-outline hover:text-error p-1"
                    >
                      <span className="material-symbols-outlined text-[16px]">close</span>
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => setHasFileUploaded(true)}
                    className="p-3 rounded-xl bg-white border border-dashed border-primary text-center text-xs text-primary font-bold hover:bg-surface-container-low transition-colors"
                  >
                    {language === 'fr' ? "+ Prendre en photo ma carte d'assuré" : '+ تصوير بطاقة التأمين'}
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Consent Checkbox */}
        <div className="p-3 rounded-2xl bg-surface-container-low flex items-start gap-2 border border-surface-container">
          <input
            id="terms"
            type="checkbox"
            checked={agreed}
            onChange={e => setAgreed(e.target.checked)}
            className="w-4 h-4 rounded mt-0.5 accent-primary cursor-pointer"
          />
          <label htmlFor="terms" className="text-xs text-on-surface cursor-pointer leading-relaxed">
            {language === 'fr' ? (
              <>
                J'accepte les <span className="text-primary font-bold">conditions d'utilisation</span> de la plateforme RIMEDIC et certifie l'exactitude de mes informations médicales et d'assurance.
              </>
            ) : (
              <>
                أوافق على <span className="text-primary font-bold">شروط الاستخدام</span> لمنصة ريميديك وأؤكد صحة معلوماتي الطبية والتأمينية.
              </>
            )}
          </label>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full h-12 bg-primary hover:bg-primary-container text-on-primary font-bold text-sm rounded-xl shadow-md flex items-center justify-center gap-2 active:scale-[0.99] transition-all cursor-pointer"
        >
          <span>{language === 'fr' ? 'Créer mon compte patient' : 'إنشاء حسابي'}</span>
          <span className={`material-symbols-outlined text-[18px] ${isRtl ? 'rotate-180' : ''}`}>arrow_forward</span>
        </button>

        <div className="flex items-center justify-center gap-1.5 text-center px-2 pt-1 text-[10px] text-on-surface-variant">
          <span className="material-symbols-outlined text-primary text-[15px]">verified_user</span>
          <p>
            {language === 'fr'
              ? 'Données de santé hébergées en conformité avec la loi mauritanienne n° 2017-020.'
              : 'بيانات صحية مشفرة وفقاً للقانون الموريتاني رقم 2017-020.'}
          </p>
        </div>
      </form>
    </div>
  );
};

