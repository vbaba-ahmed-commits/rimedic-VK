import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ESTABLISHMENTS_DATA } from '../../data/mockData';
import { translateNeighborhood } from '../../translations';

interface EstablishmentSecurityGateProps {
  onSuccess?: () => void;
}

export const EstablishmentSecurityGate: React.FC<EstablishmentSecurityGateProps> = ({ onSuccess }) => {
  const { language, unlockEstablishmentSession, navigateTo, setCurrentRole, setSelectedEstablishment } = useApp();

  const [selectedFacilityId, setSelectedFacilityId] = useState(ESTABLISHMENTS_DATA[0].id);
  const [badgeCode, setBadgeCode] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (badgeCode.trim().length < 4) {
      setErrorMessage(
        language === 'fr'
          ? 'Le code badge ou PIN agent doit comporter au moins 4 chiffres (ex: 1234).'
          : 'يجب أن يتكون رمز الشارة أو PIN من 4 أرقام على الأقل (مثال: 1234).'
      );
      return;
    }

    const facility = ESTABLISHMENTS_DATA.find(e => e.id === selectedFacilityId) || ESTABLISHMENTS_DATA[0];
    setSelectedEstablishment(facility);

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      unlockEstablishmentSession(selectedFacilityId, badgeCode);
      if (onSuccess) {
        onSuccess();
      }
    }, 400);
  };

  const handleQuickDemoUnlock = () => {
    setIsLoading(true);
    const facility = ESTABLISHMENTS_DATA[0]; // Clinique Ibn Sina
    setSelectedEstablishment(facility);
    setBadgeCode('1234');
    setTimeout(() => {
      setIsLoading(false);
      unlockEstablishmentSession(facility.id, '1234');
      if (onSuccess) {
        onSuccess();
      }
    }, 300);
  };

  const handleBackToPatient = () => {
    setCurrentRole('PATIENT');
    navigateTo('home');
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] px-4 py-8 animate-fadeIn text-center">
      <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-xl border border-surface-container flex flex-col items-center gap-4">
        {/* Security QR / Hospital Icon */}
        <div className="relative">
          <div className="w-16 h-16 rounded-2xl bg-sky-50 text-sky-800 flex items-center justify-center border border-sky-200 shadow-sm">
            <span className="material-symbols-outlined text-[36px]">local_hospital</span>
          </div>
          <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-sky-700 text-white flex items-center justify-center border-2 border-white shadow-xs">
            <span className="material-symbols-outlined text-[14px]">qr_code_scanner</span>
          </div>
        </div>

        {/* Header Title & Badges */}
        <div>
          <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-sky-100/80 text-sky-900 text-[10px] font-bold uppercase tracking-wider mb-1.5 border border-sky-200">
            <span className="material-symbols-outlined text-[13px]">verified</span>
            <span>{language === 'fr' ? 'Admission & Tiers-Payant CNAM' : 'الاستقبال والدفع الجزئي للتأمين'}</span>
          </div>
          <h2 className="text-lg font-black text-on-surface">
            {language === 'fr' ? 'Guichet Clinique Sécurisé' : 'شباك الاستقبال المعتمد'}
          </h2>
          <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">
            {language === 'fr'
              ? 'Accès réservé aux secrétariats et agents d\'accueil des cliniques partenaires de Nouakchott.'
              : 'دخول مخصص لموظفي استقبال المصحات والعيادات المعتمدة في نواكشوط.'}
          </p>
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="w-full p-2.5 rounded-xl bg-error-container text-on-error-container text-xs font-semibold flex items-center gap-2 text-start">
            <span className="material-symbols-outlined text-[18px] text-error shrink-0">error</span>
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Verification Form */}
        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-3 text-start">
          <div>
            <label className="block text-xs font-bold text-on-surface mb-1">
              {language === 'fr' ? 'Structure Médicale :' : 'المنشأة الطبية:'}
            </label>
            <div className="relative flex items-center">
              <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">apartment</span>
              <select
                value={selectedFacilityId}
                onChange={e => setSelectedFacilityId(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-surface-container-low rounded-xl border border-surface-container text-xs font-bold text-on-surface focus:outline-none focus:ring-2 focus:ring-primary appearance-none"
              >
                {ESTABLISHMENTS_DATA.slice(0, 10).map(est => (
                  <option key={est.id} value={est.id}>
                    {language === 'fr'
                      ? `${est.name} (${est.neighborhood})`
                      : `${est.nameAr || est.name} (${translateNeighborhood(est.neighborhood, language)})`}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-on-surface mb-1">
              {language === 'fr' ? 'Code Badge / PIN Guichet (4 chiffres) :' : 'رمز الشارة أو PIN (٤ أرقام):'}
            </label>
            <div className="relative flex items-center">
              <span className="material-symbols-outlined absolute left-3 text-outline text-[18px]">key</span>
              <input
                type="password"
                required
                maxLength={6}
                value={badgeCode}
                onChange={e => setBadgeCode(e.target.value)}
                placeholder={language === 'fr' ? '•••• (Démovérif: 1234)' : '•••• (تجريبي: 1234)'}
                className="w-full pl-9 pr-3 py-2.5 bg-surface-container-low rounded-xl border border-surface-container text-xs font-bold text-on-surface tracking-widest focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-1 py-3 bg-sky-800 hover:bg-sky-900 text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
          >
            {isLoading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <span className="material-symbols-outlined text-[18px]">lock_open</span>
                <span>{language === 'fr' ? 'Déverrouiller le Guichet' : 'فتح شباك الاستقبال'}</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Demo Credentials */}
        <div className="w-full p-3 rounded-2xl bg-surface-container-low border border-surface-container text-center">
          <span className="text-[10px] font-bold uppercase text-outline tracking-wider block mb-1">
            {language === 'fr' ? 'Testeur / Démonstration RIMEDIC' : 'دخول تجريبي سريع'}
          </span>
          <button
            type="button"
            onClick={handleQuickDemoUnlock}
            className="w-full py-2 px-3 rounded-xl bg-white hover:bg-sky-50 text-sky-800 border border-sky-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">touch_app</span>
            <span>{language === 'fr' ? 'Déverrouiller Guichet (Clinique Ibn Sina)' : 'دخول سريع للشباك (عيادة ابن سينا)'}</span>
          </button>
        </div>

        {/* Cancel / Back Button */}
        <button
          type="button"
          onClick={handleBackToPatient}
          className="text-xs font-bold text-on-surface-variant hover:text-on-surface py-1 transition-colors cursor-pointer flex items-center gap-1"
        >
          <span className="material-symbols-outlined text-[16px]">arrow_back</span>
          <span>{language === 'fr' ? 'Retourner à l\'Espace Patient' : 'العودة لفضاء المريض'}</span>
        </button>
      </div>
    </div>
  );
};
