import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';

export const AuthOtpScreen: React.FC = () => {
  const { language, navigateTo, goBack, showToast, currentRole, authPhoneNumber } = useApp();
  const [code, setCode] = useState('');
  const [countdown, setCountdown] = useState(42);

  // Masque le numéro de téléphone pour confidentialité (ex: +222 45 •• •• 89)
  const formatPhoneMask = (num: string) => {
    const raw = (num || '45 25 00 00').replace(/\s+/g, '');
    if (raw.length >= 8) {
      return `+222 ${raw.slice(0, 2)} •• •• ${raw.slice(-2)}`;
    }
    return `+222 ${num}`;
  };

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const handleKeyPress = (val: string) => {
    if (code.length < 6) {
      const newCode = code + val;
      setCode(newCode);
      if (newCode.length === 6) {
        setTimeout(() => {
          showToast(
            language === 'fr' ? 'Connexion réussie !' : 'تم التحقق بنجاح !',
            language === 'fr' ? 'Numéro vérifié avec succès via SMS' : 'تم التحقق من رقم الهاتف بنجاح'
          );
          if (currentRole === 'PRACTITIONER') {
            navigateTo('practitioner-dashboard');
          } else {
            navigateTo('home');
          }
        }, 300);
      }
    }
  };

  const handleBackspace = () => {
    setCode(prev => prev.slice(0, -1));
  };

  const handleValidate = () => {
    if (code.length < 4) {
      showToast(
        language === 'fr' ? 'Code incomplet' : 'الرمز غير مكتمل',
        language === 'fr' ? 'Veuillez saisir les 6 chiffres du code SMS' : 'يرجى إدخال أرقام الرمز الستة كاملة',
        'warning'
      );
      return;
    }
    showToast(
      language === 'fr' ? 'Connexion réussie !' : 'تم التحقق بنجاح !',
      language === 'fr' ? 'Session active sur RIMEDIC' : 'مرحباً بك في ريميديك'
    );
    if (currentRole === 'PRACTITIONER') {
      navigateTo('practitioner-dashboard');
    } else {
      navigateTo('home');
    }
  };

  return (
    <div className="flex flex-col w-full max-w-md mx-auto px-4 pt-2 pb-8">
      {/* Top Header Link */}
      <div className="flex items-center justify-between py-1">
        <button
          onClick={goBack}
          className="inline-flex items-center gap-1 text-xs text-on-surface-variant hover:text-primary transition-colors py-1"
        >
          <span className="material-symbols-outlined text-[18px]">arrow_back</span>
          <span className="font-bold">{language === 'fr' ? 'Modifier le numéro' : 'تغيير الرقم'}</span>
        </button>
      </div>

      {/* Security Verification Heading */}
      <div className="flex flex-col items-center text-center mt-3">
        <div className="relative flex items-center justify-center w-16 h-16 rounded-full bg-secondary-container text-on-secondary-container shadow-xs mb-2">
          <span className="material-symbols-outlined text-[32px]">verified_user</span>
          <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-4 w-4 bg-primary text-white items-center justify-center text-[10px]">
              <span className="material-symbols-outlined text-[10px]">sms</span>
            </span>
          </span>
        </div>

        <h2 className="text-xl font-bold text-on-surface">
          {language === 'fr' ? 'Vérification de sécurité SMS' : 'التحقق من أمان الحساب'}
        </h2>
        <p className="text-xs text-on-surface-variant mt-1 max-w-[280px]">
          {language === 'fr'
            ? 'Saisissez le code à 6 chiffres envoyé par SMS au numéro :'
            : 'أدخل رمز التحقق المرسل في رسالة قصيرة إلى الرقم:'}
        </p>

        <div className="inline-flex items-center gap-2 mt-2 px-3 py-1.5 rounded-full bg-surface-container border border-surface-container text-xs font-bold text-on-surface">
          <span className="material-symbols-outlined text-primary text-[16px]">phone_iphone</span>
          <span>{formatPhoneMask(authPhoneNumber)}</span>
          <button onClick={goBack} className="text-outline hover:text-primary">
            <span className="material-symbols-outlined text-[14px]">edit</span>
          </button>
        </div>
      </div>

      {/* 6 OTP Code Slots from Stitch */}
      <div className="mt-4 flex flex-col items-center">
        <div className="grid grid-cols-6 gap-2 w-full max-w-[320px]">
          {[0, 1, 2, 3, 4, 5].map(idx => {
            const hasChar = idx < code.length;
            const isCurrent = idx === code.length;
            return (
              <div
                key={idx}
                className={`h-12 rounded-xl flex items-center justify-center font-bold text-lg border transition-all ${
                  hasChar
                    ? 'bg-surface-container-lowest text-primary border-primary shadow-xs'
                    : isCurrent
                    ? 'bg-secondary-fixed border-primary shadow-xs'
                    : 'bg-surface-container-lowest text-outline-variant border-surface-container'
                }`}
              >
                {hasChar ? (
                  code[idx]
                ) : isCurrent ? (
                  <span className="w-2.5 h-2.5 rounded-full bg-primary animate-pulse"></span>
                ) : (
                  <span className="w-1.5 h-1.5 rounded-full bg-outline-variant"></span>
                )}
              </div>
            );
          })}
        </div>

        {/* Resend Timer & Links */}
        <div className="mt-3 text-center text-xs">
          <p className="text-on-surface-variant">
            {language === 'fr' ? 'Vous n\'avez pas reçu le code ?' : 'لم تستلم الرمز؟'}
          </p>
          <div className="mt-1 flex items-center justify-center gap-1 text-tertiary font-bold">
            <span className="material-symbols-outlined text-[15px]">schedule</span>
            <span>
              {language === 'fr' ? 'Renvoyer dans ' : 'إعادة الإرسال خلال '}
              <strong className="text-on-surface">00:{countdown < 10 ? `0${countdown}` : countdown}</strong>
            </span>
          </div>

          <div className="mt-1 flex items-center justify-center gap-3">
            <button
              disabled={countdown > 0}
              onClick={() => {
                setCountdown(45);
                showToast(
                  language === 'fr' ? 'Nouveau code SMS envoyé' : 'تم إعادة إرسال رمز التحقق',
                  language === 'fr' ? `SMS renvoyé au ${formatPhoneMask(authPhoneNumber)}` : 'تم إرسال رسالة SMS جديدة'
                );
              }}
              className={`font-bold text-xs flex items-center gap-1 ${
                countdown > 0 ? 'text-outline cursor-not-allowed opacity-50' : 'text-primary hover:underline'
              }`}
            >
              <span className="material-symbols-outlined text-[15px]">chat</span>
              <span>{language === 'fr' ? 'Renvoyer par SMS' : 'إعادة الإرسال عبر SMS'}</span>
            </button>
            <span className="w-1 h-1 rounded-full bg-outline-variant"></span>
            <button
              onClick={() =>
                showToast(
                  language === 'fr' ? 'Appel vocal / WhatsApp' : 'اتصال هاتفي / واتساب',
                  language === 'fr' ? 'Simulation: code 123456' : 'تجريبي: الرمز 123456'
                )
              }
              className="font-bold text-xs text-secondary hover:underline flex items-center gap-1"
            >
              <span className="material-symbols-outlined text-[15px]">call</span>
              <span>{language === 'fr' ? 'WhatsApp / Appel' : 'واتساب / اتصال'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Validate Button */}
      <div className="mt-4">
        <button
          onClick={handleValidate}
          className="w-full h-12 bg-primary hover:bg-primary-container text-on-primary font-bold text-sm rounded-xl shadow-md flex items-center justify-center gap-2 active:scale-[0.99] transition-all"
        >
          <span>{language === 'fr' ? 'Valider et continuer' : 'تأكيد ومتابعة'}</span>
          <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
        </button>
      </div>

      {/* Operator Compatibility Notice & Demo Fill */}
      <div className="mt-4 rounded-2xl bg-surface-container-low p-3.5 border border-surface-container flex flex-col gap-2">
        <div className="flex items-start gap-2">
          <span className="material-symbols-outlined text-primary text-[18px] mt-0.5">help_outline</span>
          <div>
            <p className="text-xs font-bold text-on-surface">
              {language === 'fr' ? 'Un problème de réception avec votre opérateur ?' : 'مشكلة في استلام الرسالة؟'}
            </p>
            <p className="text-[11px] text-on-surface-variant mt-0.5">
              {language === 'fr'
                ? 'Compatible avec réseaux Mauritel, Mattel & Chinguitel.'
                : 'متوافق مع شبكات موريتل، ماتال وشنقيتل.'}
            </p>
          </div>
        </div>

        {/* Quick Demo Fill button */}
        <div className="pt-2 border-t border-surface-container flex items-center justify-between text-xs">
          <div className="flex items-center gap-1 text-on-surface-variant text-[11px]">
            <span className="material-symbols-outlined text-[15px] text-tertiary">info</span>
            <span>{language === 'fr' ? 'Donnée de démonstration' : 'بيانات تجريبية'}</span>
          </div>
          <button
            onClick={() => setCode('123456')}
            className="px-2.5 py-1 rounded-lg bg-secondary-container text-on-secondary-container font-bold text-xs hover:opacity-90"
          >
            {language === 'fr' ? 'Code test : 123456' : 'رمز تجريبي : 123456'}
          </button>
        </div>
      </div>

      {/* Simulated Keypad from Stitch */}
      <div className="mt-4 grid grid-cols-3 gap-2 bg-surface-container-low p-3 rounded-2xl border border-surface-container">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
          <button
            key={num}
            type="button"
            onClick={() => handleKeyPress(num)}
            className="h-11 rounded-xl bg-white text-on-surface font-bold text-base shadow-xs active:bg-surface-container transition-colors border border-surface-container"
          >
            {num}
          </button>
        ))}
        <div></div>
        <button
          type="button"
          onClick={() => handleKeyPress('0')}
          className="h-11 rounded-xl bg-white text-on-surface font-bold text-base shadow-xs active:bg-surface-container transition-colors border border-surface-container"
        >
          0
        </button>
        <button
          type="button"
          onClick={handleBackspace}
          aria-label={language === 'fr' ? 'Effacer' : 'مسح'}
          className="h-11 rounded-xl bg-white text-on-surface-variant font-bold text-base shadow-xs active:bg-surface-container transition-colors border border-surface-container flex items-center justify-center"
        >
          <span className="material-symbols-outlined text-[20px]">backspace</span>
        </button>
      </div>
    </div>
  );
};
