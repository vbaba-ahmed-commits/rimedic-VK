import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { extractNamesFromUser } from '../../utils/nameHelper';

interface AppleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirmAppleUser: (email: string, fullName: string) => void;
  onRetryRealAppleAuth?: () => void;
}

export const AppleSignInModal: React.FC<AppleModalProps> = ({
  isOpen,
  onClose,
  onConfirmAppleUser,
  onRetryRealAppleAuth,
}) => {
  const { language } = useApp();
  const [appleEmail, setAppleEmail] = useState('');
  const [appleName, setAppleName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!appleEmail || !appleEmail.includes('@')) {
      return;
    }
    setIsSubmitting(true);
    const resolvedName = appleName.trim() || extractNamesFromUser(null, appleEmail).firstName;
    onConfirmAppleUser(appleEmail.trim().toLowerCase(), resolvedName);
    setIsSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div
        className="w-full max-w-md bg-white dark:bg-zinc-900 rounded-3xl p-6 shadow-2xl border border-zinc-200 dark:border-zinc-800 text-start relative animate-scaleUp"
        onClick={e => e.stopPropagation()}
      >
        {/* Bouton Fermer */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full text-zinc-400 hover:text-zinc-700 dark:hover:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
          type="button"
          aria-label={language === 'fr' ? "Fermer" : "إغلاق"}
        >
          <span className="material-symbols-outlined text-[20px]">close</span>
        </button>

        {/* Logo Apple */}
        <div className="flex flex-col items-center text-center mb-5">
          <div className="w-14 h-14 rounded-2xl bg-black text-white flex items-center justify-center shadow-md mb-3">
            <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
              <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 0.92-2.87-.93.04-2.02.63-2.66 1.38-.56.65-.97 1.7-.85 2.73 1.03.08 2.05-.56 2.59-1.24z"/>
            </svg>
          </div>
          <h3 className="text-xl font-bold text-zinc-900 dark:text-white">
            {language === 'fr' ? 'Connexion Officielle Apple' : 'تسجيل الدخول الرسمي من Apple'}
          </h3>
          <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-1 max-w-[320px]">
            {language === 'fr'
              ? 'Notification de sécurité Apple ID & Deux facteurs (2FA)'
              : 'إشعار الأمان بمعرف Apple والتحقق بخطوتين'}
          </p>
        </div>

        {/* Explication technique sur la vraie notification Apple */}
        <div className="p-3.5 bg-zinc-100 dark:bg-zinc-800/80 rounded-2xl border border-zinc-200 dark:border-zinc-700 text-xs text-zinc-700 dark:text-zinc-300 space-y-2 mb-4">
          <div className="flex items-start gap-2">
            <span className="material-symbols-outlined text-[18px] text-primary shrink-0 mt-0.5">info</span>
            <div>
              <p className="font-bold text-zinc-900 dark:text-white">
                {language === 'fr'
                  ? 'Comment recevoir la vraie notification Apple sur votre iPhone ?'
                  : 'كيف تتلقى إشعار Apple الحقيقي على جهازك؟'}
              </p>
              <p className="text-[11px] text-zinc-600 dark:text-zinc-400 mt-1 leading-relaxed">
                {language === 'fr'
                  ? 'Pour que les serveurs d\'Apple (appleid.apple.com) envoient la notification push officielle sur votre iPhone (« Demande de connexion avec l’identifiant Apple »), le fournisseur Apple doit être relié avec un compte Apple Developer dans la Console Firebase.'
                  : 'لكي ترسل خوادم Apple الإشعار الرسمي لجهاز iPhone الخاص بك، يلزم تفعيل مزود Apple بحساب Apple Developer في لوحة Firebase.'}
              </p>
            </div>
          </div>
        </div>

        {/* Bouton pour déclencher le vrai popup officiel Apple */}
        {onRetryRealAppleAuth && (
          <div className="mb-4">
            <button
              type="button"
              onClick={() => {
                onClose();
                onRetryRealAppleAuth();
              }}
              className="w-full py-3 px-4 bg-black hover:bg-zinc-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2.5 transition-all shadow-md active:scale-[0.98] cursor-pointer"
            >
              <svg className="w-4 h-4 fill-white" viewBox="0 0 24 24">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 6.37c.61-.75 1.04-1.8 0.92-2.87-.93.04-2.02.63-2.66 1.38-.56.65-.97 1.7-.85 2.73 1.03.08 2.05-.56 2.59-1.24z"/>
              </svg>
              <span>{language === 'fr' ? 'Ouvrir la fenêtre officielle Apple (OAuth)' : 'فتح نافذة تسجيل الدخول من Apple'}</span>
              <span className="material-symbols-outlined text-[16px]">open_in_new</span>
            </button>
          </div>
        )}

        <div className="relative flex py-2 items-center">
          <div className="flex-grow border-t border-zinc-200 dark:border-zinc-700"></div>
          <span className="flex-shrink mx-3 text-[10px] uppercase font-bold text-zinc-400">
            {language === 'fr' ? 'Ou connexion directe avec votre compte' : 'أو الدخول المباشر بالحساب'}
          </span>
          <div className="flex-grow border-t border-zinc-200 dark:border-zinc-700"></div>
        </div>

        {/* Formulaire de saisie directe compte Apple */}
        <form onSubmit={handleSubmit} className="flex flex-col gap-3 mt-2">
          <div>
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
              {language === 'fr' ? 'Votre identifiant ou e-mail iCloud / Apple' : 'بريد iCloud أو معرف Apple'}
            </label>
            <div className="relative flex items-center">
              <span className="material-symbols-outlined absolute left-3 text-zinc-400 text-[18px]">mail</span>
              <input
                type="email"
                required
                autoFocus
                placeholder="votre-compte@icloud.com"
                value={appleEmail}
                onChange={e => setAppleEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-xl text-xs font-medium text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-700 dark:text-zinc-300 mb-1">
              {language === 'fr' ? 'Nom et prénom (optionnel)' : 'الاسم الكامل (اختياري)'}
            </label>
            <div className="relative flex items-center">
              <span className="material-symbols-outlined absolute left-3 text-zinc-400 text-[18px]">person</span>
              <input
                type="text"
                placeholder={language === 'fr' ? 'Ex: Lala Habib' : 'مثال: لاله حبيب'}
                value={appleName}
                onChange={e => setAppleName(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-zinc-50 dark:bg-zinc-800 border border-zinc-300 dark:border-zinc-700 rounded-xl text-xs font-medium text-zinc-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={!appleEmail || isSubmitting}
              className="w-full py-3 px-4 bg-zinc-900 dark:bg-white hover:bg-zinc-800 dark:hover:bg-zinc-100 text-white dark:text-black font-bold text-xs rounded-xl flex items-center justify-center gap-2 disabled:opacity-50 transition-all active:scale-[0.98] shadow-sm cursor-pointer"
            >
              <span>{language === 'fr' ? 'Valider et synchroniser mon compte' : 'تأكيد الحساب ومزامنته'}</span>
              <span className="material-symbols-outlined text-[16px]">check</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
