import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Role } from '../../types';
import { RimedLogo } from './RimedLogo';
import { translateDoctorTitle, translateEstablishmentName, translateDateFormatted } from '../../translations';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    currentRole,
    setCurrentRole,
    currentScreen,
    navigateTo,
    goBack,
    t,
    isRtl,
    screenHistory,
    firebaseUser,
    organizationUser,
    patient,
    upcomingAppointments,
  } = useApp();

  const [showNotificationMenu, setShowNotificationMenu] = useState(false);

  const canGoBack = screenHistory.length > 1 && currentScreen !== 'home' && currentScreen !== 'practitioner-dashboard';

  const getScreenTitle = () => {
    switch (currentScreen) {
      case 'home':
        return language === 'fr' ? 'Accueil' : 'الرئيسية';
      case 'specialties':
        return language === 'fr' ? 'Spécialités' : 'التخصصات';
      case 'doctor-list':
        return language === 'fr' ? 'Praticiens' : 'الأطباء';
      case 'doctor-profile':
        return language === 'fr' ? 'Fiche Médecin' : 'ملف الطبيب';
      case 'establishment-detail':
        return language === 'fr' ? 'Établissement' : 'المنشأة الصحية';
      case 'booking-confirm':
        return language === 'fr' ? 'Confirmation Rendez-vous' : 'تأكيد الموعد';
      case 'appointments':
        return language === 'fr' ? 'Mes Rendez-vous' : 'مواعيدي';
      case 'map':
        return language === 'fr' ? 'Carte Santé' : 'خريطة المنشآت';
      case 'profile':
        return language === 'fr' ? 'Mon Profil' : 'حسابي';
      case 'auth-login':
        return language === 'fr' ? 'Connexion Mobile' : 'تسجيل الدخول';
      case 'auth-otp':
        return language === 'fr' ? 'Vérification OTP' : 'رمز التحقق';
      case 'auth-register':
        return language === 'fr' ? 'Inscription Patient' : 'إنشاء حساب';
      case 'practitioner-dashboard':
        return language === 'fr' ? 'Tableau de bord' : 'لوحة الطبيب';
      case 'practitioner-agenda':
        return language === 'fr' ? 'Agenda & Disponibilités' : 'الجدول والمواعيد';
      case 'practitioner-profile':
        return language === 'fr' ? 'Profil Médecin & Horaires' : 'ملف الطبيب والأوقات';
      case 'establishment-desk':
        return language === 'fr' ? 'Guichet Tiers-Payant' : 'شباك الاستقبال';
      default:
        return language === 'fr' ? 'RIMEDIC' : 'ريميديك';
    }
  };

  return (
    <header className="fixed top-0 inset-x-0 w-full z-50 pt-safe bg-surface/90 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,105,72,0.06)] border-b border-surface-container">
      <div className="max-w-2xl mx-auto h-16 px-4 flex items-center justify-between gap-2">
        {/* Left Side: Back button or Logo + Title */}
        <div className="flex items-center gap-2 min-w-0">
          {canGoBack ? (
            <button
              onClick={goBack}
              aria-label={language === 'fr' ? 'Retour' : 'رجوع'}
              className="w-10 h-10 -ml-1 rounded-full flex items-center justify-center text-on-surface hover:text-primary hover:bg-surface-container transition-all active:scale-95"
            >
              <span className={`material-symbols-outlined text-[24px] ${isRtl ? 'rotate-180' : ''}`}>
                arrow_back
              </span>
            </button>
          ) : (
            <button
              onClick={() => navigateTo('home')}
              className="flex items-center gap-1 group text-start focus:outline-none"
              type="button"
            >
              <RimedLogo size="sm" showText={false} />
            </button>
          )}

          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-[11px] uppercase tracking-wider text-primary leading-none">
                {language === 'fr' ? 'RIMEDIC' : 'ريميديك'}
              </span>
              {currentRole !== 'PATIENT' && (
                <span className="px-1.5 py-0.2 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold">
                  {currentRole === 'PRACTITIONER'
                    ? language === 'fr' ? 'Praticien' : 'طبيب'
                    : language === 'fr' ? 'Guichet' : 'منشأة'}
                </span>
              )}
            </div>
            <h1 className="font-semibold text-sm text-on-surface truncate leading-tight mt-0.5">
              {getScreenTitle()}
            </h1>
          </div>
        </div>

        {/* Right Side: Direct Pro/Patient Switcher, Language Toggle, Notification, Profile */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Direct Access to Espace Médecin / Pro Space */}
          {currentRole === 'PATIENT' ? (
            <button
              onClick={() => {
                setCurrentRole('PRACTITIONER');
                navigateTo('practitioner-profile');
              }}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 text-[#006948] hover:bg-emerald-100 border border-emerald-300 font-bold text-xs transition-all active:scale-95 cursor-pointer shadow-2xs"
              title={language === 'fr' ? 'Accéder à l\'Espace Médecin' : 'الدخول لفضاء الطبيب'}
              type="button"
            >
              <span className="material-symbols-outlined text-[15px]">badge</span>
              <span className="text-[11px] font-bold">{language === 'fr' ? 'Espace Pro' : 'فضاء الطبيب'}</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setCurrentRole('PATIENT');
                navigateTo('home');
              }}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-surface-container-high text-on-surface hover:text-primary font-bold text-[11px] transition-colors border border-surface-container cursor-pointer"
              title={language === 'fr' ? 'Revenir au mode Patient' : 'الرجوع لفضاء المريض'}
              type="button"
            >
              <span className="material-symbols-outlined text-[15px]">person</span>
              <span className="text-[11px] font-semibold">{language === 'fr' ? 'Patient' : 'المريض'}</span>
            </button>
          )}

          {/* Bilingual Language Switcher (FR / عربي) */}
          <div className="flex items-center bg-surface-container-low p-0.5 rounded-full shadow-[0_1px_2px_rgba(0,0,0,0.03)] border border-surface-container">
            <button
              onClick={() => setLanguage('fr')}
              className={`px-2 py-1 rounded-full font-bold text-[11px] transition-all min-w-[28px] min-h-[26px] flex items-center justify-center ${
                language === 'fr'
                  ? 'bg-white text-primary shadow-[0_1px_4px_rgba(0,0,0,0.06)]'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
              type="button"
            >
              {language === 'fr' ? 'FR' : 'فرنسية'}
            </button>
            <button
              onClick={() => setLanguage('ar')}
              className={`px-2 py-1 rounded-full font-bold text-[11px] transition-all min-w-[28px] min-h-[26px] flex items-center justify-center ${
                language === 'ar'
                  ? 'bg-white text-primary shadow-[0_1px_4px_rgba(0,0,0,0.06)]'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
              type="button"
            >
              {language === 'fr' ? 'عربي' : 'عربية'}
            </button>
          </div>

          {/* Notifications Trigger */}
          <div className="relative">
            <button
              onClick={() => setShowNotificationMenu(!showNotificationMenu)}
              aria-label={language === 'fr' ? "Notifications" : "الإشعارات"}
              className="relative w-9 h-9 flex items-center justify-center rounded-full text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
              type="button"
            >
              <span className="material-symbols-outlined text-[20px]">notifications</span>
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-error ring-2 ring-white"></span>
            </button>

            {showNotificationMenu && (
              <div
                className={`absolute top-full mt-1.5 ${isRtl ? 'left-0' : 'right-0'} w-72 bg-white rounded-xl shadow-xl border border-surface-container p-3 z-50 flex flex-col gap-2`}
              >
                <div className="flex items-center justify-between pb-1 border-b border-surface-container">
                  <span className="font-bold text-xs text-on-surface">
                    {language === 'fr' ? 'Notifications' : 'الإشعارات'}
                  </span>
                  <span className="text-[10px] text-primary font-semibold">
                    {upcomingAppointments.length > 0
                      ? (language === 'fr' ? `${upcomingAppointments.length} active(s)` : `${upcomingAppointments.length} نشطة`)
                      : (language === 'fr' ? '0 active' : 'لا توجد')}
                  </span>
                </div>
                <div className="flex flex-col gap-2 text-xs">
                  {upcomingAppointments.length > 0 ? (
                    upcomingAppointments.slice(0, 2).map(apt => (
                      <div key={apt.id} className="p-2 rounded-lg bg-surface-container-low flex items-start gap-2">
                        <span className="material-symbols-outlined text-primary text-[18px]">verified</span>
                        <div>
                          <p className="font-semibold text-on-surface truncate">
                            {translateDoctorTitle(apt.practitionerName, language)}
                          </p>
                          <p className="text-on-surface-variant text-[11px] truncate">
                            {language === 'fr' ? (
                              `${apt.dateFormatted} à ${apt.time} • ${apt.establishmentName}`
                            ) : (
                              <>
                                {translateDateFormatted(apt.dateFormatted, language)} في{' '}
                                <span dir="ltr" className="inline-block tabular-nums font-mono font-semibold">
                                  {apt.time}
                                </span>{' '}
                                • {translateEstablishmentName(apt.establishmentName, language)}
                              </>
                            )}
                          </p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-3 text-center text-outline text-xs">
                      {language === 'fr' ? 'Aucune notification en attente' : 'لا توجد إشعارات جديدة'}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Avatar */}
          <button
            onClick={() => navigateTo('profile')}
            aria-label={language === 'fr' ? "Profil" : "الملف الشخصي"}
            className="flex items-center justify-center rounded-full"
          >
            {firebaseUser?.photoURL ? (
              <img
                src={firebaseUser.photoURL}
                alt={firebaseUser.displayName || (language === 'fr' ? 'Google Profile' : 'حساب Google')}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-primary/40 shadow-xs"
              />
            ) : firebaseUser ? (
              <div
                className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xs ring-2 ring-primary/40 shadow-xs"
                title={firebaseUser.displayName || firebaseUser.email || (language === 'fr' ? 'Compte Google' : 'حساب Google')}
              >
                {(firebaseUser.displayName || firebaseUser.email || 'G').slice(0, 2).toUpperCase()}
              </div>
            ) : organizationUser ? (
              <div
                className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xs ring-2 ring-primary/40 shadow-xs"
                title={`${organizationUser.name} - ${organizationUser.organizationName}`}
              >
                {organizationUser.name.slice(0, 2).toUpperCase()}
              </div>
            ) : (
              <div className="w-8 h-8 rounded-full bg-secondary-container/70 text-on-secondary-container flex items-center justify-center font-bold text-xs ring-2 ring-primary/20 hover:ring-primary transition-all">
                {currentRole === 'PRACTITIONER'
                  ? 'MA'
                  : `${(patient.firstName || 'P').charAt(0)}${(patient.lastName || '').charAt(0)}`.toUpperCase() || 'P'}
              </div>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
