import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';

interface QrCodeViewProps {
  value: string;
  size?: number;
  className?: string;
}

export const QrCodeView: React.FC<QrCodeViewProps> = ({ value, size = 160, className = '' }) => {
  const [dataUrl, setDataUrl] = useState<string>('');

  useEffect(() => {
    QRCode.toDataURL(value, {
      width: size,
      margin: 1,
      color: {
        dark: '#006948', // Primary RIMEDIC emerald green
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url: string) => setDataUrl(url))
      .catch((err: any) => console.error('QR code generation error:', err));
  }, [value, size]);

  if (!dataUrl) {
    return (
      <div
        style={{ width: size, height: size }}
        className={`bg-surface-container-low flex items-center justify-center rounded-xl animate-pulse ${className}`}
      >
        <span className="material-symbols-outlined text-[32px] text-primary">qr_code_2</span>
      </div>
    );
  }

  return (
    <div className={`p-2 bg-white rounded-xl shadow-sm inline-block ${className}`}>
      <img
        src={dataUrl}
        alt={`QR Pass RIMEDIC: ${value}`}
        width={size}
        height={size}
        className="block rounded-lg"
      />
    </div>
  );
};
