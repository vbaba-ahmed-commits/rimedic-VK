import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CITIES_DATA } from '../../data/mockData';
import { City } from '../../types';

export const CityModal: React.FC = () => {
  const {
    isCityModalOpen,
    setIsCityModalOpen,
    selectedCity,
    setSelectedCity,
    language,
    showToast
  } = useApp();

  const [search, setSearch] = useState('');
  const [tempCity, setTempCity] = useState<City>(selectedCity);
  const [isDetectingGps, setIsDetectingGps] = useState(false);

  if (!isCityModalOpen) return null;

  const filteredCities = CITIES_DATA.filter(c => {
    const q = search.toLowerCase().trim();
    if (!q) return true;
    return (
      c.name.toLowerCase().includes(q) ||
      c.nameAr.toLowerCase().includes(q) ||
      c.wilaya.toLowerCase().includes(q) ||
      c.moughataas.some(m => m.toLowerCase().includes(q))
    );
  });

  const handleGpsDetect = () => {
    setIsDetectingGps(true);
    setTimeout(() => {
      setIsDetectingGps(false);
      const nkc = CITIES_DATA[0];
      setTempCity(nkc);
      showToast(
        language === 'fr' ? 'Position GPS détectée' : 'تم تحديد الموقع بنجاح',
        language === 'fr' ? 'Nouakchott (Tevragh-Zeina)' : 'نواكشوط (تفرغ زينة)'
      );
    }, 700);
  };

  const handleConfirm = () => {
    setSelectedCity(tempCity);
    setIsCityModalOpen(false);
    showToast(
      language === 'fr' ? 'Territoire mis à jour' : 'تم تحديث النطاق الصحي',
      `${tempCity.name} (${tempCity.wilaya})`
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-end justify-center p-0 sm:p-4">
      <div
        className="w-full max-w-lg bg-surface-container-lowest rounded-t-[28px] sm:rounded-2xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden animate-in slide-in-from-bottom duration-300"
        onClick={e => e.stopPropagation()}
      >
        {/* Drag handle */}
        <div className="w-full flex items-center justify-center pt-3 pb-1">
          <div className="w-12 h-1.5 rounded-full bg-surface-container-highest"></div>
        </div>

        {/* Modal Header */}
        <div className="px-4 pt-1 pb-3 flex items-start justify-between gap-3 border-b border-surface-container">
          <div>
            <div className="flex items-center gap-1.5 text-primary text-xs font-bold uppercase tracking-wider">
              <span className="material-symbols-outlined text-[18px]">explore</span>
              <span>{language === 'fr' ? 'Territoire RIMEDIC' : 'النطاق الجغرافي'}</span>
            </div>
            <h2 className="text-xl font-bold text-on-surface mt-0.5">
              {language === 'fr' ? 'Choisir votre ville' : 'اختر مدينتك أو ولايتك'}
            </h2>
            <p className="text-xs text-on-surface-variant mt-0.5">
              {language === 'fr'
                ? 'Recherchez des praticiens et établissements de santé à proximité'
                : 'ابحث عن أطباء ومستشفيات قريبة من موقعك'}
            </p>
          </div>
          <button
            onClick={() => setIsCityModalOpen(false)}
            aria-label={language === 'fr' ? "Fermer" : "إغلاق"}
            className="w-8 h-8 rounded-full bg-surface-container flex items-center justify-center text-on-surface-variant hover:bg-surface-container-high transition-colors"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* GPS Quick Detect */}
        <div className="px-4 py-2.5">
          <button
            onClick={handleGpsDetect}
            disabled={isDetectingGps}
            className="w-full bg-secondary-container/40 hover:bg-secondary-container/60 active:scale-[0.99] p-3 rounded-xl flex items-center justify-between text-left transition-all border border-secondary-container"
            type="button"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-on-primary shadow-sm shrink-0">
                <span className={`material-symbols-outlined text-[20px] ${isDetectingGps ? 'animate-spin' : ''}`}>
                  {isDetectingGps ? 'refresh' : 'near_me'}
                </span>
              </div>
              <div>
                <div className="text-sm font-bold text-on-surface flex items-center gap-1.5">
                  <span>{language === 'fr' ? 'Utiliser ma position actuelle (GPS)' : 'استخدام موقعي الحالي (GPS)'}</span>
                  <span className="w-2 h-2 rounded-full bg-primary animate-ping"></span>
                </div>
                <div className="text-xs text-on-surface-variant">
                  {language === 'fr'
                    ? 'Détection automatique de votre moughataa à Nouakchott'
                    : 'التعرف التلقائي على المقاطعة في نواكشوط'}
                </div>
              </div>
            </div>
            <span className="material-symbols-outlined text-primary text-[20px]">chevron_right</span>
          </button>
        </div>

        {/* Search input */}
        <div className="px-4 py-1">
          <div className="relative flex items-center bg-surface-container-low rounded-xl px-3 py-2.5 border border-surface-container">
            <span className="material-symbols-outlined text-outline text-[20px] shrink-0 mr-2">search</span>
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={
                language === 'fr'
                  ? 'Rechercher une ville, une wilaya ou une moughataa...'
                  : 'ابحث عن مدينة، ولاية، أو مقاطعة...'
              }
              className="w-full bg-transparent text-sm text-on-surface placeholder:text-outline outline-none"
            />
            {search && (
              <button onClick={() => setSearch('')} className="text-outline hover:text-on-surface">
                <span className="material-symbols-outlined text-[16px]">cancel</span>
              </button>
            )}
          </div>
        </div>

        {/* Villes List */}
        <div className="flex items-center justify-between px-4 pt-2 text-xs font-bold text-on-surface-variant uppercase tracking-wider">
          <span>{language === 'fr' ? 'Territoire actif (Nouakchott uniquement)' : 'النطاق الصحي المفعل (نواكشوط حالياً)'}</span>
          <span className="px-2 py-0.5 rounded-full bg-secondary-container text-primary font-bold">
            {filteredCities.length} {language === 'fr' ? 'capitale' : 'العاصمة'}
          </span>
        </div>

        <div className="flex-1 overflow-y-auto px-4 py-2 space-y-2 max-h-[380px]">
          {filteredCities.map(city => {
            const isSelected = tempCity.id === city.id;
            return (
              <div
                key={city.id}
                onClick={() => setTempCity(city)}
                className={`cursor-pointer rounded-xl p-3 border transition-all ${
                  isSelected
                    ? 'bg-secondary-container/30 border-primary shadow-sm'
                    : 'bg-white border-surface-container hover:bg-surface-container-low'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isSelected ? 'bg-primary text-on-primary' : 'bg-surface-container text-secondary'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[20px]">
                        {city.isCapital ? 'location_city' : 'apartment'}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-on-surface truncate">
                          {language === 'fr' ? city.name : city.nameAr}
                        </span>
                        {city.isCapital && (
                          <span className="px-2 py-0.2 rounded-full bg-primary text-on-primary text-[10px] font-bold">
                            {language === 'fr' ? 'Capitale' : 'العاصمة'}
                          </span>
                        )}
                        <span className="text-[11px] text-on-surface-variant bg-surface-container px-2 py-0.2 rounded-full truncate">
                          {language === 'fr' ? city.wilaya : city.wilayaAr}
                        </span>
                      </div>
                      <p className="text-xs text-on-surface-variant mt-1 line-clamp-2">
                        {(language === 'fr' ? city.moughataas : (city.moughataasAr || city.moughataas)).join(language === 'fr' ? ', ' : '، ')}
                      </p>
                      <div className="mt-1.5 flex items-center gap-2 text-xs">
                        <span className="text-primary font-semibold">
                          {city.practitionerCount} {language === 'fr' ? 'praticiens' : 'طبيباً'}
                        </span>
                        <span>•</span>
                        <span className="text-outline">
                          {city.centerCount} {language === 'fr' ? 'centres de santé' : 'مركزاً صحياً'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-1 transition-all ${
                      isSelected ? 'bg-primary text-on-primary' : 'bg-surface-container text-transparent'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[16px]">check</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Sticky Confirmation Dock */}
        <div className="p-4 bg-surface-container-lowest border-t border-surface-container flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs text-on-surface-variant">
            <span>{language === 'fr' ? 'Sélection active :' : 'المدينة المختارة :'}</span>
            <span className="font-bold text-primary flex items-center gap-1">
              <span className="material-symbols-outlined text-[16px]">location_on</span>
              {language === 'fr' ? tempCity.name : tempCity.nameAr}
            </span>
          </div>

          <button
            onClick={handleConfirm}
            className="w-full h-12 bg-primary hover:bg-primary-container text-on-primary rounded-xl font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
          >
            <span className="material-symbols-outlined text-[18px]">check_circle</span>
            <span>{language === 'fr' ? 'Confirmer la ville sélectionnée' : 'تأكيد المدينة المختارة'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
