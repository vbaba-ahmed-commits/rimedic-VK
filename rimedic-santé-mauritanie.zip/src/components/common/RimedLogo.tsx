import React from 'react';

interface RimedLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  textColor?: string;
}

export const RimedLogo: React.FC<RimedLogoProps> = ({
  className = '',
  size = 'md',
  showText = true,
  textColor,
}) => {
  const iconSizes = {
    sm: 24,
    md: 32,
    lg: 48,
    xl: 64,
  };

  const textSizes = {
    sm: 'text-sm font-black tracking-tight',
    md: 'text-lg font-black tracking-tight',
    lg: 'text-2xl font-black tracking-tight',
    xl: 'text-3xl font-black tracking-tight',
  };

  const currentSize = iconSizes[size];

  return (
    <div className={`flex items-center gap-2 select-none ${className}`}>
      {/* Official RIMEDIC Vector Icon */}
      <svg
        width={currentSize}
        height={currentSize}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0"
      >
        {/* Main "R" Body in Emerald Green */}
        {/* Vertical Left Stem */}
        <rect x="22" y="16" width="16" height="68" rx="3" fill="#006948" />

        {/* Top Loop */}
        <path
          d="M 26 16 H 62 C 77 16 84 26 84 39 C 84 52 75 60 60 60 H 34"
          stroke="#006948"
          strokeWidth="15"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />

        {/* Right Diagonal Leg */}
        <path
          d="M 48 54 L 76 84"
          stroke="#006948"
          strokeWidth="16"
          strokeLinecap="round"
          fill="none"
        />

        {/* Medical Cross '+' inside the loop */}
        <rect x="52" y="27" width="8" height="24" rx="2" fill="#143e2e" />
        <rect x="44" y="35" width="24" height="8" rx="2" fill="#143e2e" />

        {/* Red Crescent Swoosh */}
        <path
          d="M 18 42 C 14 55 24 70 38 72 C 30 68 24 58 26 48 Z"
          fill="#d32f2f"
        />

        {/* Golden Yellow Swoosh Curve */}
        <path
          d="M 24 58 C 30 70 52 74 74 54 C 64 68 42 70 28 62 Z"
          fill="#f59e0b"
        />
      </svg>

      {/* Official Typography: R (Green) + I (Red) + MEDIC (Green) */}
      {showText && (
        <span className={`inline-flex items-baseline font-black font-sans leading-none ${textSizes[size]}`}>
          <span className="text-[#006948]">R</span>
          <span className="text-[#d32f2f] mx-[0.5px]">I</span>
          <span className="text-[#006948]">MEDIC</span>
        </span>
      )}
    </div>
  );
};
