import React from 'react';
import { useApp } from '../../context/AppContext';
import { ScreenId } from '../../context/AppContext';

export const BottomNav: React.FC = () => {
  const { currentScreen, navigateTo, currentRole, setCurrentRole, t, language } = useApp();

  // If in auth flows, doctor profile (with its own sticky booking CTA) or booking confirmation, hide bottom nav
  const hideBottomNav =
    currentScreen === 'auth-login' ||
    currentScreen === 'auth-otp' ||
    currentScreen === 'auth-register' ||
    currentScreen === 'doctor-profile' ||
    currentScreen === 'booking-confirm';

  if (hideBottomNav) {
    return null;
  }

  // Patient Nav Items
  const patientNav: Array<{
    id: ScreenId;
    icon: string;
    label: string;
    action?: () => void;
  }> = [
    { id: 'home' as ScreenId, icon: 'home', label: t.navHome },
    { id: 'specialties' as ScreenId, icon: 'stethoscope', label: t.navSpecialties },
    { id: 'map' as ScreenId, icon: 'map', label: t.navMap },
    { id: 'appointments' as ScreenId, icon: 'calendar_month', label: t.navAppointments },
    { id: 'profile' as ScreenId, icon: 'person', label: t.navProfile },
  ];

  // Practitioner Nav Items
  const practitionerNav: Array<{
    id: ScreenId;
    icon: string;
    label: string;
    action?: () => void;
  }> = [
    {
      id: 'practitioner-dashboard' as ScreenId,
      icon: 'dashboard',
      label: language === 'fr' ? 'Tableau de bord' : 'لوحة القيادة',
    },
    {
      id: 'practitioner-agenda' as ScreenId,
      icon: 'calendar_month',
      label: language === 'fr' ? 'Agenda' : 'المواعيد',
    },
    {
      id: 'practitioner-profile' as ScreenId,
      icon: 'badge',
      label: language === 'fr' ? 'Mon Profil & Horaires' : 'الملف والأوقات',
    },
    {
      id: 'establishment-desk' as ScreenId,
      icon: 'qr_code_scanner',
      label: language === 'fr' ? 'Scanner Pass' : 'مسح تصريح',
    },
    {
      id: 'home' as ScreenId,
      icon: 'person',
      label: language === 'fr' ? 'Mode Patient' : 'فضاء المريض',
      action: () => {
        setCurrentRole('PATIENT');
        navigateTo('home');
      },
    },
  ];

  const items = currentRole === 'PRACTITIONER' ? practitionerNav : patientNav;

  const isActive = (itemId: ScreenId) => {
    if (itemId === currentScreen) return true;
    if (itemId === 'specialties' && (currentScreen === 'doctor-list' || currentScreen === 'establishment-detail')) {
      return true;
    }
    return false;
  };

  return (
    <nav className="fixed bottom-0 inset-x-0 w-full z-40 pb-safe bg-surface-container-lowest/95 backdrop-blur-xl border-t border-surface-container shadow-[0_-2px_12px_rgba(0,105,72,0.05)]">
      <div className="max-w-2xl mx-auto flex justify-around items-center h-16 px-1">
        {items.map(item => {
          const active = isActive(item.id);
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.action) {
                  item.action();
                } else {
                  navigateTo(item.id);
                }
              }}
              className={`flex flex-col items-center justify-center min-w-[50px] min-h-[44px] py-1 transition-all cursor-pointer ${
                active
                  ? 'text-primary font-bold relative after:content-[""] after:absolute after:bottom-0.5 after:w-1.5 after:h-1.5 after:bg-primary after:rounded-full'
                  : 'text-outline hover:text-on-surface'
              }`}
              type="button"
            >
              <span className={`material-symbols-outlined text-[22px] ${active ? 'fill-current' : ''}`}>
                {item.icon}
              </span>
              <span className="text-[10px] mt-0.5 tracking-tight font-medium text-center truncate max-w-[58px]">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
