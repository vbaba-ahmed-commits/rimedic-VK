import React from 'react';
import { useApp } from '../../context/AppContext';

export const Toast: React.FC = () => {
  const { toast, hideToast, language } = useApp();

  if (!toast) return null;

  const getIcon = () => {
    switch (toast.type) {
      case 'success':
        return 'check_circle';
      case 'warning':
        return 'warning';
      case 'error':
        return 'error';
      default:
        return 'info';
    }
  };

  const getBorderColor = () => {
    switch (toast.type) {
      case 'success':
        return 'border-primary';
      case 'warning':
        return 'border-tertiary';
      case 'error':
        return 'border-error';
      default:
        return 'border-secondary';
    }
  };

  return (
    <div className="fixed top-20 inset-x-4 max-w-md mx-auto z-50 animate-in fade-in slide-in-from-top-4 duration-300">
      <div
        className={`bg-inverse-surface text-inverse-on-surface p-3.5 rounded-2xl shadow-xl flex items-start gap-3 border-l-4 ${getBorderColor()}`}
      >
        <span className="material-symbols-outlined text-[24px] text-primary-fixed-dim shrink-0 mt-0.5">
          {getIcon()}
        </span>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-sm leading-tight text-white">{toast.title}</p>
          <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">{toast.message}</p>
        </div>
        <button
          onClick={hideToast}
          aria-label={language === 'fr' ? "Fermer" : "إغلاق"}
          className="text-slate-400 hover:text-white p-1 -mr-1 -mt-1 transition-colors"
        >
          <span className="material-symbols-outlined text-[18px]">close</span>
        </button>
      </div>
    </div>
  );
};
