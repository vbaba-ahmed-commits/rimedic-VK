import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const PractitionerAgenda: React.FC = () => {
  const {
    language,
    navigateTo,
    practitionerSlotsBlocked,
    toggleBlockSlot,
    showToast,
    patient,
    isRtl
  } = useApp();

  const [viewMode, setViewMode] = useState<'jour' | 'semaine' | 'mois'>('jour');
  const [smsActive, setSmsActive] = useState(true);

  const activePatientName = patient.firstName
    ? `${patient.firstName} ${patient.lastName}`.trim()
    : (language === 'fr' ? 'Fatimetou Mint Mohamed' : 'فاطمة منت محمد');
  const activeInitials = patient.firstName
    ? `${patient.firstName.charAt(0)}${patient.lastName ? patient.lastName.charAt(0) : ''}`
    : 'FM';

  const slots = [
    {
      timeStart: '09:00',
      timeEnd: '09:45',
      initials: 'OB',
      name: language === 'fr' ? 'Oumar Ba' : 'عمر با',
      reason: language === 'fr' ? 'Bilan orthodontique annuel' : 'فحص تقويم الأسنان السنوي',
      status: language === 'fr' ? 'Terminé' : 'منجز',
      statusClass: 'bg-surface-container-highest text-on-surface-variant',
      opacity: 'opacity-70',
    },
    {
      timeStart: '09:45',
      timeEnd: '10:30',
      initials: 'FS',
      name: language === 'fr' ? 'Fatimetou Mint Salem' : 'فاطمة منت السالم',
      reason: language === 'fr' ? 'Activation appareil multi-attache' : 'تعديل وشد جهاز التقويم',
      status: language === 'fr' ? 'Honoré' : 'مكتمل',
      statusClass: 'bg-secondary-container text-on-secondary-container',
      opacity: 'opacity-70',
    },
    {
      timeStart: '10:30',
      timeEnd: '11:30',
      isEmergencyLocked: true,
      name: language === 'fr' ? 'Garde Urgences Clinique' : 'مناوبة طوارئ العيادة',
      reason: language === 'fr' ? 'Créneau réservé au flux non programmé' : 'موعد مخصص للحالات المستعجلة',
      status: language === 'fr' ? 'Verrouillé' : 'مغلق',
      statusClass: 'bg-error-container text-on-error-container font-bold',
    },
    {
      isLunchPrayerBreak: true,
      timeText: language === 'fr' ? '11:30 - 14:30 • PAUSE DÉJEUNER & PRIÈRE' : '\u200E11:30 - 14:30\u200E • استراحة الغداء والصلاة',
      subText: language === 'fr' ? 'Non réservable • Fermeture temporaire du cabinet' : 'غير متاح للحجز • إغلاق مؤقت للعيادة',
    },
    {
      timeStart: '14:30',
      timeEnd: '15:15',
      initials: 'DK',
      name: language === 'fr' ? 'Dr Kane (Confrère)' : 'د. كان (استشارة زميل)',
      reason: language === 'fr' ? 'Consultation spéciale & plan chirurgical' : 'استشارة خاصة وخطة جراحية',
      status: language === 'fr' ? 'Avis croisé' : 'استشارة مشتركة',
      statusClass: 'bg-surface-container-highest text-on-surface font-semibold',
    },
    {
      timeStart: '15:30',
      timeEnd: '16:15',
      initials: activeInitials,
      name: activePatientName,
      reason: language === 'fr' ? 'Attache décollée' : 'انفصال سلك التقويم',
      fileNumber: 'SCAN-RIM-89412',
      isActivePatient: true,
      status: language === 'fr' ? 'Patiente arrivée' : 'وصلت المريضة',
    },
    {
      timeStart: '16:15',
      timeEnd: '17:00',
      initials: 'MB',
      name: language === 'fr' ? 'Mohamed Bilal' : 'محمد بلال',
      reason: language === 'fr' ? "Pose d'arc inférieur" : 'تركيب القوس السفلي',
      status: language === 'fr' ? 'Confirmé SMS' : 'مؤكد عبر SMS',
      statusClass: 'bg-secondary-container/70 text-on-secondary-container',
    },
    {
      timeStart: '17:00',
      timeEnd: '17:45',
      initials: 'AV',
      name: language === 'fr' ? 'Ahmed Vall' : 'أحمد فال',
      reason: language === 'fr' ? 'Douleur aiguë suite à choc' : 'ألم حاد إثر صدمة',
      status: language === 'fr' ? 'Urgence déclarée' : 'طوارئ مسجلة',
      statusClass: 'bg-error-container text-on-error-container font-bold',
    },
    {
      timeStart: '17:45',
      timeEnd: '18:30',
      isFreeSlot: true,
      name: language === 'fr' ? 'Créneau Libre' : 'موعد متاح',
      reason: language === 'fr' ? 'Réservable en ligne par le patient' : 'متاح للحجز عبر الإنترنت',
    },
  ];

  return (
    <div className="flex flex-col w-full pb-28">
      {/* En-tête de l'Agenda */}
      <section className="px-4 pt-3 pb-2 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase tracking-wider text-primary font-bold">
              {language === 'fr' ? 'Cabinet Tevragh-Zeina' : 'عيادة تفرغ زينة'}
            </span>
            <h1 className="text-xl font-bold text-on-surface tracking-tight">
              {language === 'fr' ? 'Mon Agenda & Disponibilités' : 'جدول مواعيدي والأوقات المتاحة'}
            </h1>
          </div>
          <div className="w-10 h-10 rounded-xl bg-surface-container-high flex items-center justify-center text-primary">
            <span className="material-symbols-outlined text-[22px]">calendar_today</span>
          </div>
        </div>

        {/* View Mode Selector */}
        <div className="flex p-1 bg-surface-container rounded-xl w-full border border-surface-container">
          <button
            onClick={() => setViewMode('jour')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all text-center ${
              viewMode === 'jour' ? 'bg-white text-primary shadow-xs' : 'text-on-surface-variant'
            }`}
          >
            {language === 'fr' ? 'Jour' : 'اليوم'}
          </button>
          <button
            onClick={() => setViewMode('semaine')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all text-center ${
              viewMode === 'semaine' ? 'bg-white text-primary shadow-xs' : 'text-on-surface-variant'
            }`}
          >
            {language === 'fr' ? 'Semaine' : 'الأسبوع'}
          </button>
          <button
            onClick={() => setViewMode('mois')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all text-center ${
              viewMode === 'mois' ? 'bg-white text-primary shadow-xs' : 'text-on-surface-variant'
            }`}
          >
            {language === 'fr' ? 'Mois' : 'الشهر'}
          </button>
        </div>

        {/* Date Selector Row */}
        <div className="flex items-center justify-between p-2.5 bg-surface-container-lowest rounded-2xl shadow-xs border border-surface-container">
          <button
            aria-label={language === 'fr' ? "Jour précédent" : "اليوم السابق"}
            className="w-8 h-8 rounded-xl bg-surface-container flex items-center justify-center text-on-surface-variant active:scale-95 transition-transform"
          >
            <span className={`material-symbols-outlined text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
              chevron_left
            </span>
          </button>
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-[18px]">event</span>
            <span className="text-xs font-bold text-on-surface">
              {language === 'fr' ? 'Lundi 28 Septembre 2026' : 'الإثنين ٢٨ سبتمبر ٢٠٢٦'}
            </span>
          </div>
          <button
            aria-label={language === 'fr' ? "Jour suivant" : "اليوم التالي"}
            className="w-8 h-8 rounded-xl bg-surface-container flex items-center justify-center text-on-surface-variant active:scale-95 transition-transform"
          >
            <span className={`material-symbols-outlined text-[18px] ${isRtl ? 'rotate-180' : ''}`}>
              chevron_right
            </span>
          </button>
        </div>

        {/* Action Shortcuts */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => showToast(
              language === 'fr' ? 'Blocage créneau' : 'قفل موعد',
              language === 'fr' ? 'Créneau 18:00 verrouillé pour interventions' : 'تم قفل موعد \u200E18:00\u200E للحالات الخاصة'
            )}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-primary text-on-primary text-xs font-bold shadow-xs active:scale-98 transition-transform"
          >
            <span className="material-symbols-outlined text-[16px]">event_busy</span>
            <span>{language === 'fr' ? '+ Bloquer un créneau' : '+ قفل موعد'}</span>
          </button>
          <button
            onClick={() => navigateTo('practitioner-profile')}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-surface-container-high hover:bg-surface-container-highest text-on-surface text-xs font-bold transition-colors cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">tune</span>
            <span>{language === 'fr' ? 'Modifier mes horaires' : 'تعديل الأوقات'}</span>
          </button>
        </div>
      </section>

      {/* Saturation Gauge from Stitch */}
      <section className="px-4 my-1">
        <div className="p-3.5 bg-surface-container-lowest rounded-2xl shadow-xs border border-surface-container flex flex-col gap-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-on-surface">
                {language === 'fr' ? 'Charge de la consultation' : 'نسبة امتلاء العيادة'}
              </span>
              <span className="px-2 py-0.2 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold">
                70%
              </span>
            </div>
            <span className="text-on-surface-variant font-medium">
              {language === 'fr' ? '7 / 10 créneaux' : '٧ / ١٠ مواعيد'}
            </span>
          </div>

          <div className="w-full bg-surface-container rounded-full h-2 overflow-hidden flex">
            <div className="bg-primary h-full rounded-full transition-all duration-500" style={{ width: '70%' }}></div>
          </div>

          <div className="flex items-center gap-2 text-xs text-on-surface-variant pt-0.5">
            <span className="w-2 h-2 rounded-full bg-primary shrink-0"></span>
            <p>
              {language === 'fr' ? (
                <>
                  <strong className="text-primary font-bold">3 créneaux encore ouverts</strong> à la réservation en ligne
                </>
              ) : (
                <>
                  <strong className="text-primary font-bold">٣ مواعيد متبقية</strong> متاحة للحجز الرقمي
                </>
              )}
            </p>
          </div>
        </div>
      </section>

      {/* Timeline des créneaux */}
      <section className="px-4 mt-2 flex flex-col gap-2">
        <div className="flex items-center justify-between px-1 text-xs">
          <h2 className="font-bold text-on-surface">
            {language === 'fr' ? 'Planning de la journée' : 'جدول مواعيد اليوم'}
          </h2>
          <span className="text-[10px] text-on-surface-variant uppercase font-bold tracking-wider">
            {language === 'fr' ? 'FUSEAU GMT (NOUAKCHOTT)' : 'توقيت نواكشوط (GMT)'}
          </span>
        </div>

        {slots.map((item, idx) => {
          if (item.isLunchPrayerBreak) {
            return (
              <div
                key={idx}
                className="p-3 rounded-2xl bg-tertiary-fixed flex items-center justify-between text-on-tertiary-fixed gap-2 border border-tertiary-fixed-dim"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-[20px] text-tertiary">wb_sunny</span>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold leading-tight flex items-center gap-1.5 flex-wrap">
                      <span dir="ltr" className="inline-block tabular-nums font-mono">11:30 - 14:30</span>
                      <span>•</span>
                      <span>{language === 'fr' ? 'PAUSE DÉJEUNER & PRIÈRE' : 'استراحة الغداء والصلاة'}</span>
                    </span>
                    <span className="text-[10px] opacity-90">{item.subText}</span>
                  </div>
                </div>
                <span className="material-symbols-outlined text-[18px] text-tertiary">lock</span>
              </div>
            );
          }

          if (item.isActivePatient) {
            return (
              <div
                key={idx}
                className="p-3 rounded-2xl bg-primary text-on-primary shadow-md flex items-start gap-3"
              >
                <div className="w-14 shrink-0 flex flex-col items-center justify-center py-0.5">
                  <span dir="ltr" className="font-bold text-xs text-white tabular-nums font-mono">{item.timeStart}</span>
                  <span dir="ltr" className="text-[10px] text-white/80 tabular-nums font-mono">{item.timeEnd}</span>
                </div>
                <div className="w-8 h-8 rounded-xl bg-white text-primary flex items-center justify-center font-bold text-xs shrink-0">
                  {item.initials}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-bold text-xs text-white truncate">{item.name}</span>
                    <span className="px-2 py-0.2 rounded-full bg-secondary-container text-on-secondary-container text-[10px] font-bold flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-primary animate-ping"></span>
                      <span>{item.status}</span>
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded text-white font-mono">
                      {language === 'fr' ? 'Dossier:' : 'الملف:'} {item.fileNumber}
                    </span>
                    <span className="text-xs text-white/90 truncate">{item.reason}</span>
                  </div>
                </div>
              </div>
            );
          }

          if (item.isFreeSlot) {
            const isBlocked = practitionerSlotsBlocked.includes(item.timeStart);
            return (
              <div
                key={idx}
                className={`p-3 rounded-2xl flex items-center justify-between gap-3 border transition-colors ${
                  isBlocked
                    ? 'bg-surface-container-low border-surface-container opacity-60'
                    : 'bg-secondary-container/20 border-secondary-container'
                }`}
              >
                <div className="w-14 shrink-0 flex flex-col items-center justify-center">
                  <span dir="ltr" className="font-bold text-xs text-primary tabular-nums font-mono">{item.timeStart}</span>
                  <span dir="ltr" className="text-[10px] text-on-surface-variant tabular-nums font-mono">{item.timeEnd}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-[16px] text-primary">public</span>
                    <span className="font-bold text-xs text-primary truncate">
                      {isBlocked
                        ? (language === 'fr' ? 'Créneau Verrouillé' : 'موعد مغلق')
                        : item.name}
                    </span>
                  </div>
                  <p className="text-[11px] text-on-surface-variant truncate">
                    {isBlocked
                      ? (language === 'fr' ? 'Réservation fermée par le praticien' : 'تم إغلاق الحجز من قبل الطبيب')
                      : item.reason}
                  </p>
                </div>
                <button
                  onClick={() => toggleBlockSlot(item.timeStart)}
                  className="px-3 py-1.5 rounded-xl bg-white text-on-surface text-xs font-bold shadow-xs active:scale-95 transition-transform shrink-0 border border-surface-container"
                  type="button"
                >
                  {isBlocked
                    ? (language === 'fr' ? 'Débloquer' : 'إلغاء القفل')
                    : (language === 'fr' ? 'Bloquer' : 'قفل')}
                </button>
              </div>
            );
          }

          return (
            <div
              key={idx}
              className={`p-3 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex items-start gap-3 ${
                item.opacity || ''
              }`}
            >
              <div className="w-14 shrink-0 flex flex-col items-center justify-center py-0.5">
                <span dir="ltr" className="font-bold text-xs text-on-surface tabular-nums font-mono">{item.timeStart}</span>
                <span dir="ltr" className="text-[10px] text-on-surface-variant tabular-nums font-mono">{item.timeEnd}</span>
              </div>
              <div className="w-8 h-8 rounded-xl bg-surface-container-high flex items-center justify-center font-bold text-xs text-on-surface shrink-0">
                {item.initials || 'EM'}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <span className="font-bold text-xs text-on-surface truncate">{item.name}</span>
                  <span className={`px-2 py-0.2 rounded-full text-[10px] ${item.statusClass}`}>
                    {item.status}
                  </span>
                </div>
                <p className="text-[11px] text-on-surface-variant truncate mt-0.5">{item.reason}</p>
              </div>
            </div>
          );
        })}
      </section>

      {/* Rappels SMS & Pro Sync Box */}
      <section className="px-4 mt-3">
        <div className="p-4 bg-surface-container-lowest rounded-2xl shadow-xs border border-surface-container flex flex-col gap-2">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-start gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-secondary-container flex items-center justify-center text-on-secondary-container shrink-0 mt-0.5">
                <span className="material-symbols-outlined text-[20px]">sms</span>
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-xs text-on-surface">
                  {language === 'fr' ? 'Rappels SMS automatiques' : 'التذكير التلقائي عبر SMS'}
                </span>
                <span className="text-[11px] text-on-surface-variant mt-0.5">
                  {language === 'fr'
                    ? 'Notification 24h avant aux opérateurs (Mauritel, Mattel, Chinguitel)'
                    : 'إشعار قبل ٢٤ ساعة عبر مشغلي الهاتف (موريتل، ماتال، شنقيتل)'}
                </span>
              </div>
            </div>

            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={smsActive}
                onChange={() => {
                  setSmsActive(!smsActive);
                  showToast(
                    language === 'fr' ? 'Passerelle SMS' : 'بوابة رسائل SMS',
                    !smsActive
                      ? (language === 'fr' ? 'Synchronisation active' : 'المزامنة نشطة')
                      : (language === 'fr' ? 'Suspendu' : 'معلق')
                  );
                }}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-surface-container rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary shadow-xs"></div>
            </label>
          </div>

          <div className="pt-2 border-t border-surface-container flex items-center justify-between text-xs text-on-surface-variant">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px] text-primary">verified</span>
              <span className="text-[11px] font-semibold">
                {language === 'fr' ? 'Synchronisation RIMEDIC Pro active' : 'مزامنة ريميديك الاحترافية نشطة'}
              </span>
            </div>
            <span className="text-[10px] text-outline">
              {language === 'fr' ? 'Donnée de démonstration' : 'بيانات تجريبية'}
            </span>
          </div>
        </div>
      </section>
    </div>
  );
};
