import React from 'react';
import { useApp } from '../../context/AppContext';
import { translateNeighborhood, translateEstablishmentName } from '../../translations';

export const PractitionerDashboard: React.FC = () => {
  const {
    language,
    navigateTo,
    practitionerOnline,
    setPractitionerOnline,
    practitionerProfile,
    lockPractitionerSession,
    patient,
    showToast
  } = useApp();

  const activePatientName = patient.firstName
    ? `${patient.firstName} ${patient.lastName}`.trim()
    : (language === 'fr' ? 'Fatimetou Mint Mohamed' : 'فاطمة منت محمد');
  const activeInitials = patient.firstName
    ? `${patient.firstName.charAt(0)}${patient.lastName ? patient.lastName.charAt(0) : ''}`
    : 'FM';
  const activeNni = patient.nni
    ? `${patient.nni.slice(0, 4)}••••${patient.nni.slice(-2)}`
    : '8941••••12';

  const handleStartConsultation = () => {
    showToast(
      language === 'fr' ? 'Consultation démarrée' : 'بدأت الاستشارة',
      language === 'fr' ? `Patient ${activePatientName} appelé en Cabinet 204` : `تم استدعاء المريض ${activePatientName}`
    );
  };

  const handleOpenDossier = () => {
    showToast(
      language === 'fr' ? 'Dossier Patient ouvert' : 'فتح الملف الطبي',
      'Dossier #SCAN-RIM-89412 • Historique orthodontique'
    );
  };

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Professional Security Status Bar */}
      <section className="px-4 pt-2">
        <div className="bg-emerald-950 text-white px-3 py-1.5 rounded-2xl flex items-center justify-between text-xs border border-emerald-500/30 shadow-xs">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="material-symbols-outlined text-emerald-300 text-[16px] shrink-0">encrypted</span>
            <span className="text-[11px] font-bold text-emerald-100 truncate">
              {language === 'fr' ? 'Session Médecin Sécurisée • Secret Médical' : 'جلسة مؤمنة • السر الطبي'}
            </span>
          </div>
          <button
            onClick={lockPractitionerSession}
            type="button"
            className="px-2.5 py-1 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer shrink-0"
            title={language === 'fr' ? "Verrouiller et fermer la session praticien" : "قفل وإغلاق جلسة الطبيب"}
          >
            <span className="material-symbols-outlined text-[13px]">lock</span>
            <span>{language === 'fr' ? 'Verrouiller' : 'قفل'}</span>
          </button>
        </div>
      </section>

      {/* Header Card: Profil Praticien & Statut */}
      <section className="px-4 pt-3 pb-2">
        <div className="bg-surface-container-lowest p-4 rounded-2xl shadow-sm border border-surface-container flex flex-col gap-3">
          <div className="flex items-start justify-between gap-2">
            <div
              onClick={() => navigateTo('practitioner-profile')}
              className="flex items-center gap-3 min-w-0 cursor-pointer group"
            >
              <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center text-on-primary font-bold text-sm shadow-md shrink-0 group-hover:scale-105 transition-transform">
                {practitionerProfile.firstName.charAt(0)}{practitionerProfile.lastName.charAt(0)}
              </div>
              <div className="min-w-0">
                <h1 className="font-bold text-sm text-on-surface truncate group-hover:text-primary transition-colors">
                  {language === 'fr' ? practitionerProfile.title : practitionerProfile.titleAr}
                </h1>
                <p className="text-xs text-on-surface-variant flex items-center gap-1 mt-0.5 truncate">
                  <span className="material-symbols-outlined text-[14px] text-primary">location_on</span>
                  <span className="truncate">
                    {translateEstablishmentName(practitionerProfile.establishmentName, language)} • {translateNeighborhood(practitionerProfile.neighborhood, language)}
                  </span>
                </p>
              </div>
            </div>

            {/* Status Switcher Tactile from Stitch */}
            <button
              onClick={() => {
                setPractitionerOnline(!practitionerOnline);
                showToast(
                  language === 'fr' ? 'Statut mis à jour' : 'تم تحديث الحالة',
                  !practitionerOnline
                    ? (language === 'fr' ? 'En consultation' : 'في المعاينة')
                    : (language === 'fr' ? 'En pause' : 'في استراحة')
                );
              }}
              className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-xs cursor-pointer ${
                practitionerOnline
                  ? 'bg-secondary-container text-on-secondary-container'
                  : 'bg-surface-container-high text-on-surface'
              }`}
              type="button"
            >
              <span className={`w-2 h-2 rounded-full ${practitionerOnline ? 'bg-primary animate-pulse' : 'bg-outline'}`}></span>
              <span>
                {practitionerOnline
                  ? (language === 'fr' ? 'En consultation' : 'في المعاينة')
                  : (language === 'fr' ? 'En pause' : 'في استراحة')}
              </span>
              <span className="material-symbols-outlined text-[14px]">expand_more</span>
            </button>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-surface-container text-xs text-on-surface-variant">
            <div className="flex items-center gap-1.5 font-semibold text-on-surface">
              <span className="material-symbols-outlined text-[16px] text-primary">today</span>
              <span>{language === 'fr' ? 'Planning actif' : 'الجدول نشط'}</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-surface-container text-[11px] font-bold text-primary">
              {language === 'fr' ? practitionerProfile.specialtyName : practitionerProfile.specialtyNameAr}
            </span>
          </div>

          {/* Direct CTA to Manage Schedule & Appointments */}
          <button
            onClick={() => navigateTo('practitioner-profile')}
            className="w-full py-2.5 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100/80 text-[#006948] border border-emerald-200 font-bold text-xs flex items-center justify-between transition-colors shadow-2xs cursor-pointer"
            type="button"
          >
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px]">badge</span>
              <span>{language === 'fr' ? 'Gérer mon profil, horaires & rendez-vous' : 'إدارة ملفي وأوقاتي ومواعيدي'}</span>
            </div>
            <span className={`material-symbols-outlined text-[18px] ${language === 'ar' ? 'rotate-180' : ''}`}>arrow_forward</span>
          </button>
        </div>
      </section>

      {/* 4 KPI Cards Grid from Stitch */}
      <section className="px-4 my-1">
        <div className="grid grid-cols-2 gap-2">
          {/* Card 1: RDV prévus */}
          <div className="bg-surface-container-lowest p-3 rounded-2xl shadow-xs border border-surface-container flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">
                {language === 'fr' ? 'RDV prévus' : 'المواعيد المقررة'}
              </span>
              <div className="w-6 h-6 rounded-lg bg-surface-container flex items-center justify-center text-primary">
                <span className="material-symbols-outlined text-[14px]">calendar_month</span>
              </div>
            </div>
            <div className="mt-2">
              <div className="text-xl font-bold text-on-surface leading-none">8</div>
              <div className="flex items-center gap-1 mt-1 text-[11px] text-error font-semibold">
                <span className="w-1.5 h-1.5 rounded-full bg-error"></span>
                <span>{language === 'fr' ? '2 urgences' : 'حالتان طارئتان'}</span>
              </div>
            </div>
          </div>

          {/* Card 2: Salle d'attente */}
          <div className="bg-surface-container-lowest p-3 rounded-2xl shadow-xs border border-surface-container flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">
                {language === 'fr' ? "Salle d'attente" : 'قاعة الانتظار'}
              </span>
              <div className="w-6 h-6 rounded-lg bg-secondary-container flex items-center justify-center text-on-secondary-container">
                <span className="material-symbols-outlined text-[14px]">chair</span>
              </div>
            </div>
            <div className="mt-2">
              <div className="text-xl font-bold text-primary leading-none">3</div>
              <span className="text-[11px] text-on-surface-variant mt-1 block">
                {language === 'fr' ? 'Patients arrivés' : 'مرضى وصلوا'}
              </span>
            </div>
          </div>

          {/* Card 3: Consultations honorées */}
          <div className="bg-surface-container-lowest p-3 rounded-2xl shadow-xs border border-surface-container flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">
                {language === 'fr' ? 'Consultations' : 'المعاينات'}
              </span>
              <div className="w-6 h-6 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-800">
                <span className="material-symbols-outlined text-[14px]">task_alt</span>
              </div>
            </div>
            <div className="mt-2">
              <div className="text-xl font-bold text-on-surface leading-none">
                8 <span className="text-[11px] text-on-surface-variant font-normal">/ 12</span>
              </div>
              <span className="text-[11px] text-on-surface-variant mt-1 block">
                {language === 'fr' ? 'Honorées ce jour' : 'مكتملة اليوم'}
              </span>
            </div>
          </div>

          {/* Card 4: Ponctualité */}
          <div className="bg-surface-container-lowest p-3 rounded-2xl shadow-xs border border-surface-container flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-on-surface-variant">
                {language === 'fr' ? 'Ponctualité' : 'الانضباط بالوقت'}
              </span>
              <div className="w-6 h-6 rounded-lg bg-surface-container flex items-center justify-center text-primary">
                <span className="material-symbols-outlined text-[14px]">schedule</span>
              </div>
            </div>
            <div className="mt-2">
              <div className="text-xl font-bold text-primary leading-none">94%</div>
              <span className="text-[11px] text-on-surface-variant mt-1 block">
                {language === 'fr' ? '+3% vs sem. passée' : '+3% مقارنة بالأسبوع الماضي'}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Action Buttons */}
      <section className="px-4 my-2 flex items-center gap-2">
        <button
          onClick={() => navigateTo('establishment-desk')}
          className="flex-1 h-11 px-4 bg-primary hover:bg-primary-container text-on-primary rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm active:scale-98 transition-all cursor-pointer"
          type="button"
        >
          <span className="material-symbols-outlined text-[18px]">qr_code_scanner</span>
          <span>{language === 'fr' ? 'Scanner Pass Patient' : 'مسح بطاقة المريض'}</span>
        </button>
        <button
          onClick={() => navigateTo('practitioner-agenda')}
          className="h-11 px-4 bg-surface-container text-on-surface rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-surface-container-high transition-colors cursor-pointer"
          type="button"
        >
          <span className="material-symbols-outlined text-[18px]">calendar_month</span>
          <span>{language === 'fr' ? 'Agenda' : 'جدول المواعيد'}</span>
        </button>
      </section>

      {/* Prochain Patient en File Active (Highlighted Card from Stitch) */}
      <section className="px-4 my-2">
        <div className="flex items-center justify-between px-1 mb-1.5 text-xs">
          <span className="font-bold text-on-surface flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-primary animate-ping"></span>
            <span>{language === 'fr' ? 'Prochain patient en file active' : 'المريض القادم في قائمة الانتظار'}</span>
          </span>
          <span className="font-bold text-primary">
            {language === 'fr' ? (
              '15:30 (Dans 10 min)'
            ) : (
              <>
                <span dir="ltr" className="inline-block tabular-nums font-mono font-bold">15:30</span> (خلال 10 دقائق)
              </>
            )}
          </span>
        </div>

        <div className="bg-surface-container-lowest p-4 rounded-2xl shadow-sm border border-surface-container relative overflow-hidden">
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-primary"></div>

          <div className="flex flex-col gap-3 pl-1">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-surface-container flex items-center justify-center text-primary font-bold text-sm">
                  {activeInitials}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-on-surface">{activePatientName}</h3>
                  <p className="text-[11px] text-on-surface-variant">NNI : {activeNni} • {language === 'fr' ? 'Dossier vérifié' : 'ملف معتمد'}</p>
                </div>
              </div>
              <span className="px-2.5 py-0.5 bg-secondary-container text-on-secondary-container rounded-full text-[10px] font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
                <span>{language === 'fr' ? 'Arrivé accueil' : 'وصل للاستقبال'}</span>
              </span>
            </div>

            <div className="bg-surface-container-low p-2.5 rounded-xl flex flex-col gap-1 text-xs border border-surface-container">
              <div className="flex items-center justify-between">
                <span className="text-on-surface-variant">{language === 'fr' ? 'Motif' : 'سبب الاستشارة'}</span>
                <span className="font-bold text-on-surface">
                  {language === 'fr' ? '1ère consultation orthodontie' : 'أول استشارة لتقويم الأسنان'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-on-surface-variant">{language === 'fr' ? 'Assurance' : 'التأمين'}</span>
                <span className="font-bold text-primary">
                  {language === 'fr' ? 'CNAM (Prise en charge 80%)' : 'كنام (نسبة تغطية 80%)'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 p-2 bg-primary-fixed-dim/20 rounded-xl">
              <span className="material-symbols-outlined text-[18px] text-primary">verified</span>
              <div className="flex flex-col">
                <span className="text-[11px] font-bold text-primary">
                  {language === 'fr' ? "QR Validé à l'accueil de la clinique" : 'تم اعتماد رمز الدخول في استقبال العيادة'}
                </span>
                <span className="text-[10px] text-on-surface-variant font-mono">SCAN-RIM-89412</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleStartConsultation}
                className="flex-1 h-10 bg-primary hover:bg-primary-container text-on-primary rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm active:scale-98 transition-all cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">play_arrow</span>
                <span>{language === 'fr' ? 'Démarrer consultation' : 'بدء المعاينة'}</span>
              </button>
              <button
                onClick={handleOpenDossier}
                className="h-10 px-3 bg-surface-container text-on-surface rounded-xl font-bold text-xs flex items-center justify-center gap-1 shadow-xs hover:bg-surface-container-high transition-colors cursor-pointer"
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">folder_open</span>
                <span>{language === 'fr' ? 'Dossier' : 'الملف'}</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Planning Après-midi List */}
      <section className="px-4 my-2">
        <div className="flex items-center justify-between px-1 mb-2">
          <h2 className="font-bold text-sm text-on-surface">
            {language === 'fr' ? 'Planning après-midi' : 'جدول بعد الظهر'}
          </h2>
          <button
            onClick={() => navigateTo('practitioner-agenda')}
            className="text-xs font-bold text-primary flex items-center gap-0.5 hover:underline cursor-pointer"
          >
            <span>{language === 'fr' ? "Voir l'agenda" : "عرض الأجندة"}</span>
            <span className={`material-symbols-outlined text-[14px] ${language === 'ar' ? 'rotate-180' : ''}`}>arrow_forward</span>
          </button>
        </div>

        <div className="bg-surface-container-lowest rounded-2xl shadow-xs border border-surface-container divide-y divide-surface-container overflow-hidden">
          <div className="p-3 flex items-center justify-between gap-2 hover:bg-surface-container-low transition-colors">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="flex flex-col items-center justify-center w-11 py-1 px-1 bg-surface-container rounded-lg shrink-0">
                <span dir="ltr" className="font-bold text-xs text-primary tabular-nums font-mono">16:00</span>
                <span className="text-[10px] text-on-surface-variant">20m</span>
              </div>
              <div className="min-w-0">
                <span className="font-bold text-xs text-on-surface truncate block">
                  {language === 'fr' ? 'Mohamed Bilal' : 'محمد بلال'}
                </span>
                <span className="text-[11px] text-on-surface-variant truncate block">
                  {language === 'fr' ? 'Contrôle bague • CNAM' : 'فحص التقويم • كنام'}
                </span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-surface-container text-on-surface-variant">
              {language === 'fr' ? 'Confirmé' : 'مؤكد'}
            </span>
          </div>

          <div className="p-3 flex items-center justify-between gap-2 hover:bg-surface-container-low transition-colors">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="flex flex-col items-center justify-center w-11 py-1 px-1 bg-surface-container rounded-lg shrink-0">
                <span dir="ltr" className="font-bold text-xs text-primary tabular-nums font-mono">16:30</span>
                <span className="text-[10px] text-on-surface-variant">30m</span>
              </div>
              <div className="min-w-0">
                <span className="font-bold text-xs text-on-surface truncate block">
                  {language === 'fr' ? 'Aïssata Sow' : 'عيستة صو'}
                </span>
                <span className="text-[11px] text-on-surface-variant truncate block">
                  {language === 'fr' ? 'Détartrage & suivi • CNASS' : 'تنظيف الأسنان والمتابعة • كناص'}
                </span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-secondary-container text-on-secondary-container flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-ping"></span>
              <span>{language === 'fr' ? 'En route' : 'في الطريق'}</span>
            </span>
          </div>

          <div className="p-3 flex items-center justify-between gap-2 hover:bg-surface-container-low transition-colors">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="flex flex-col items-center justify-center w-11 py-1 px-1 bg-error-container rounded-lg text-on-error-container shrink-0">
                <span dir="ltr" className="font-bold text-xs tabular-nums font-mono">17:00</span>
                <span className="text-[10px]">{language === 'fr' ? 'Urg.' : 'طوارئ'}</span>
              </div>
              <div className="min-w-0">
                <span className="font-bold text-xs text-on-surface truncate block">
                  {language === 'fr' ? 'Ahmed Vall' : 'أحمد فال'}
                </span>
                <span className="text-[11px] text-error font-semibold truncate block">
                  {language === 'fr' ? 'Douleur aiguë • Sans assurance' : 'ألم حاد • بدون تأمين'}
                </span>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-error-container text-on-error-container">
              {language === 'fr' ? 'Urgence directe' : 'طوارئ مباشرة'}
            </span>
          </div>
        </div>
      </section>

      {/* Demandes en attente */}
      <section className="px-4 my-2">
        <div className="flex items-center justify-between px-1 mb-2">
          <div className="flex items-center gap-1.5">
            <h2 className="font-bold text-xs text-on-surface">
              {language === 'fr' ? 'Demandes en attente' : 'الطلبات المعلقة'}
            </h2>
            <span className="w-4 h-4 rounded-full bg-tertiary-container text-on-tertiary-container text-[10px] flex items-center justify-center font-bold">
              1
            </span>
          </div>
          <span className="text-[11px] text-on-surface-variant">
            {language === 'fr' ? 'À valider' : 'في انتظار التأكيد'}
          </span>
        </div>

        <div className="bg-surface-container-lowest p-3.5 rounded-2xl shadow-xs border border-surface-container flex flex-col gap-2.5">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-surface-container flex items-center justify-center text-primary font-bold text-xs">
                MK
              </div>
              <div>
                <span className="font-bold text-xs text-on-surface block">
                  {language === 'fr' ? 'Mariem Kane' : 'مريم كان'}
                </span>
                <span className="text-[11px] text-on-surface-variant block">
                  {language === 'fr' ? "Consultation de pose d'appareil" : 'استشارة تركيب جهاز التقويم'}
                </span>
              </div>
            </div>
            <span className="text-[10px] bg-tertiary-fixed text-on-tertiary-fixed px-2 py-0.5 rounded-full font-bold">
              {language === 'fr' ? (
                'Mer. 30 Sept • 10:00'
              ) : (
                <>
                  الأربعاء 30 سبتمبر • <span dir="ltr" className="inline-block tabular-nums font-mono font-bold">10:00</span>
                </>
              )}
            </span>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() => showToast(
                language === 'fr' ? 'Rendez-vous accepté' : 'تم قبول الموعد',
                language === 'fr' ? 'Notification SMS envoyée à Mariem Kane' : 'تم إرسال إشعار SMS إلى مريم كان'
              )}
              className="flex-1 h-8 bg-primary hover:bg-primary-container text-on-primary rounded-lg text-xs font-bold flex items-center justify-center gap-1 active:scale-98 transition-all cursor-pointer"
              type="button"
            >
              <span className="material-symbols-outlined text-[15px]">check</span>
              <span>{language === 'fr' ? 'Accepter' : 'قبول'}</span>
            </button>
            <button
              onClick={() => showToast(
                language === 'fr' ? 'Proposition envoyée' : 'تم إرسال الاقتراح',
                language === 'fr' ? 'Autre créneau proposé pour le 01 Octobre' : 'تم اقتراح موعد بديل في 01 أكتوبر'
              )}
              className="flex-1 h-8 bg-surface-container text-on-surface rounded-lg text-xs font-bold flex items-center justify-center gap-1 hover:bg-surface-container-high transition-colors cursor-pointer"
              type="button"
            >
              <span className="material-symbols-outlined text-[15px]">schedule</span>
              <span>{language === 'fr' ? 'Autre créneau' : 'موعد آخر'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Footer Credentials */}
      <div className="mt-4 text-center text-[10px] text-outline px-4">
        <p>
          {language === 'fr'
            ? 'Espace certifié MSSS & Ordre National des Médecins'
            : 'فضاء معتمد من وزارة الصحة وسلك الأطباء الموريتاني'}
        </p>
        <p className="mt-0.5">
          {language === 'fr'
            ? 'Données de démonstration professionnelle RIMEDIC Mauritanie'
            : 'بيانات تجريبية احترافية • منصة ريميديك موريتانيا'}
        </p>
      </div>
    </div>
  );
};
