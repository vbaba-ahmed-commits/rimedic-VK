import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PractitionerScheduleDay, Appointment, AppointmentStatus } from '../../types';
import { translateDateFormatted } from '../../translations';

export const PractitionerProfileScreen: React.FC = () => {
  const {
    language,
    navigateTo,
    practitionerProfile,
    updatePractitionerProfile,
    updatePractitionerSchedule,
    practitionerAppointments,
    updateAppointmentStatus,
    rescheduleAppointment,
    practitionerOnline,
    setPractitionerOnline,
    lockPractitionerSession,
    showToast,
    isRtl
  } = useApp();

  const [activeTab, setActiveTab] = useState<'schedule' | 'appointments' | 'details'>('schedule');

  // Local schedule state for fine editing
  const [schedule, setSchedule] = useState<PractitionerScheduleDay[]>(practitionerProfile.schedule);
  const [slotDuration, setSlotDuration] = useState<number>(practitionerProfile.slotDurationMinutes || 30);
  const [autoAccept, setAutoAccept] = useState<boolean>(practitionerProfile.autoAcceptAppointments ?? true);
  const [allowEmergency, setAllowEmergency] = useState<boolean>(practitionerProfile.allowEmergencyWalkins ?? true);
  const [smsReminders, setSmsReminders] = useState<boolean>(practitionerProfile.smsRemindersEnabled ?? true);

  // Local profile details state
  const [fee, setFee] = useState<number>(practitionerProfile.fee);
  const [phone, setPhone] = useState<string>(practitionerProfile.phone);
  const [email, setEmail] = useState<string>(practitionerProfile.email || '');
  const [bio, setBio] = useState<string>(practitionerProfile.bio);
  const [education, setEducation] = useState<string>(practitionerProfile.education);
  const [experienceYears, setExperienceYears] = useState<number>(practitionerProfile.experienceYears);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>(practitionerProfile.languages);

  // Appointment filters & search
  const [appointmentFilter, setAppointmentFilter] = useState<'all' | 'today' | 'upcoming' | 'pending' | 'completed' | 'cancelled'>('all');
  const [searchPatient, setSearchPatient] = useState<string>('');

  // Reschedule Modal State
  const [reschedulingApt, setReschedulingApt] = useState<Appointment | null>(null);
  const [newDate, setNewDate] = useState<string>('');
  const [newTime, setNewTime] = useState<string>('10:00');

  // Handle schedule changes for a single day
  const handleDayChange = (dayIndex: number, field: keyof PractitionerScheduleDay, value: any) => {
    setSchedule(prev => {
      const updated = [...prev];
      updated[dayIndex] = { ...updated[dayIndex], [field]: value };
      return updated;
    });
  };

  // Quick apply Monday's hours to all weekdays (Tuesday - Friday)
  const handleApplyMondayToWeekdays = () => {
    const monday = schedule.find(s => s.dayOfWeek === 1) || schedule[0];
    setSchedule(prev =>
      prev.map(day => {
        if (day.dayOfWeek >= 2 && day.dayOfWeek <= 4) {
          return {
            ...day,
            active: monday.active,
            morningStart: monday.morningStart,
            morningEnd: monday.morningEnd,
            hasLunchBreak: monday.hasLunchBreak,
            lunchStart: monday.lunchStart,
            lunchEnd: monday.lunchEnd,
            afternoonStart: monday.afternoonStart,
            afternoonEnd: monday.afternoonEnd
          };
        }
        return day;
      })
    );
    showToast(
      language === 'fr' ? 'Horaires dupliqués' : 'تم تكرار الأوقات',
      language === 'fr'
        ? 'Les horaires du lundi ont été appliqués du mardi au jeudi.'
        : 'تم تطبيق أوقات الإثنين على باقي أيام الأسبوع.'
    );
  };

  // Save Schedule Tab
  const handleSaveSchedule = () => {
    updatePractitionerSchedule(schedule);
    updatePractitionerProfile({
      slotDurationMinutes: slotDuration,
      autoAcceptAppointments: autoAccept,
      allowEmergencyWalkins: allowEmergency,
      smsRemindersEnabled: smsReminders
    });
  };

  // Save Profile Details Tab
  const handleSaveDetails = () => {
    updatePractitionerProfile({
      fee,
      phone,
      email,
      bio,
      education,
      experienceYears,
      languages: selectedLanguages
    });
  };

  // Toggle Language
  const toggleLanguageOption = (lang: string) => {
    setSelectedLanguages(prev =>
      prev.includes(lang) ? prev.filter(l => l !== lang) : [...prev, lang]
    );
  };

  // Confirm Rescheduling
  const handleConfirmReschedule = () => {
    if (!reschedulingApt || !newDate || !newTime) return;
    rescheduleAppointment(reschedulingApt.id, newDate, newTime);
    setReschedulingApt(null);
  };

  // Filtered Appointments
  const todayStr = new Date().toISOString().split('T')[0];
  const filteredAppointments = practitionerAppointments.filter(apt => {
    // Filter by status / date
    if (appointmentFilter === 'today' && apt.date !== todayStr) return false;
    if (appointmentFilter === 'upcoming' && (apt.status === 'completed' || apt.status === 'cancelled' || apt.date < todayStr)) return false;
    if (appointmentFilter === 'pending' && apt.status !== 'pending') return false;
    if (appointmentFilter === 'completed' && apt.status !== 'completed') return false;
    if (appointmentFilter === 'cancelled' && apt.status !== 'cancelled') return false;

    // Search query
    if (searchPatient.trim()) {
      const q = searchPatient.toLowerCase().trim();
      const matchName = apt.patientName.toLowerCase().includes(q);
      const matchPhone = apt.patientPhone.includes(q);
      const matchRef = apt.referenceNumber.toLowerCase().includes(q);
      const matchReason = apt.reason.toLowerCase().includes(q);
      return matchName || matchPhone || matchRef || matchReason;
    }

    return true;
  });

  const pendingCount = practitionerAppointments.filter(a => a.status === 'pending').length;
  const todayCount = practitionerAppointments.filter(a => a.date === todayStr && a.status !== 'cancelled').length;
  const completedCount = practitionerAppointments.filter(a => a.status === 'completed').length;

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Professional Security Status Bar */}
      <section className="px-4 pt-2">
        <div className="bg-emerald-900/90 text-white px-3 py-1.5 rounded-2xl flex items-center justify-between text-xs border border-emerald-500/30 shadow-xs">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="material-symbols-outlined text-emerald-300 text-[16px] shrink-0">encrypted</span>
            <span className="text-[11px] font-bold text-emerald-100 truncate">
              {language === 'fr' ? 'Session Sécurisée • Secret Médical Actif' : 'جلسة مؤمنة • السر الطبي'}
            </span>
          </div>
          <button
            onClick={lockPractitionerSession}
            type="button"
            className="px-2.5 py-1 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer shrink-0"
            title="Verrouiller et fermer la session praticien"
          >
            <span className="material-symbols-outlined text-[13px]">lock</span>
            <span>{language === 'fr' ? 'Verrouiller' : 'قفل'}</span>
          </button>
        </div>
      </section>

      {/* Header Profile Identity Card */}
      <section className="px-4 pt-3 pb-2">
        <div className="bg-gradient-to-br from-[#006948] to-[#014832] text-white p-4 rounded-3xl shadow-md border border-emerald-400/20 flex flex-col gap-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-md border border-white/25 flex items-center justify-center text-white font-extrabold text-lg shadow-sm shrink-0">
                {practitionerProfile.firstName.charAt(0)}
                {practitionerProfile.lastName.charAt(0)}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h1 className="font-extrabold text-base text-white truncate">
                    {language === 'fr' ? practitionerProfile.title : practitionerProfile.titleAr}
                  </h1>
                  <span className="inline-flex items-center gap-0.5 px-2 py-0.2 rounded-full bg-emerald-400/20 text-emerald-200 border border-emerald-300/30 text-[10px] font-bold">
                    <span className="material-symbols-outlined text-[12px]">verified</span>
                    <span>Agrément ONMM</span>
                  </span>
                </div>
                <p className="text-xs text-emerald-100 font-medium truncate mt-0.5">
                  {language === 'fr' ? practitionerProfile.specialtyName : practitionerProfile.specialtyNameAr} • {practitionerProfile.establishmentName}
                </p>
                <div className="flex items-center gap-2 text-[11px] text-emerald-200/90 mt-1">
                  <span className="flex items-center gap-0.5">
                    <span className="material-symbols-outlined text-[14px]">location_on</span>
                    <span>{practitionerProfile.neighborhood}, Nouakchott</span>
                  </span>
                  <span>•</span>
                  <span className="font-semibold">{language === 'fr' ? 'Secteur conventionné' : 'قطاع معتمد'}</span>
                </div>
              </div>
            </div>

            {/* Quick Consultation Status Switcher */}
            <button
              onClick={() => {
                setPractitionerOnline(!practitionerOnline);
                showToast(
                  language === 'fr' ? 'Statut mis à jour' : 'تم تحديث الحالة',
                  !practitionerOnline
                    ? (language === 'fr' ? 'Disponible en consultation' : 'متاح للاستشارة الآن')
                    : (language === 'fr' ? 'Cabinet en pause' : 'في استراحة مؤقتة')
                );
              }}
              className={`shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-xs cursor-pointer ${
                practitionerOnline
                  ? 'bg-emerald-400 text-emerald-950 ring-2 ring-emerald-300'
                  : 'bg-white/20 text-white'
              }`}
              type="button"
            >
              <span className={`w-2 h-2 rounded-full ${practitionerOnline ? 'bg-emerald-950 animate-pulse' : 'bg-slate-300'}`}></span>
              <span>{practitionerOnline ? (language === 'fr' ? 'En ligne' : 'متاح') : (language === 'fr' ? 'En pause' : 'استراحة')}</span>
            </button>
          </div>

          {/* Quick Badges Row */}
          <div className="flex items-center justify-between pt-2.5 border-t border-white/15 text-xs text-emerald-100">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-lg bg-white/10 text-[10px] font-bold">
                N° Ordre : {practitionerProfile.orderNumber}
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-white/10 text-[10px] font-bold">
                {practitionerProfile.experienceYears} ans d'expérience
              </span>
            </div>

            <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-200">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span>Conventionné CNAM & CNASS</span>
            </div>
          </div>
        </div>
      </section>

      {/* Navigation Tabs Bar */}
      <section className="px-4 my-1">
        <div className="flex items-center bg-surface-container-low p-1 rounded-2xl border border-surface-container gap-1 shadow-2xs">
          <button
            onClick={() => setActiveTab('schedule')}
            type="button"
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'schedule'
                ? 'bg-primary text-white shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">schedule</span>
            <span>{language === 'fr' ? 'Horaires & Planning' : 'الأوقات والجدول'}</span>
          </button>

          <button
            onClick={() => setActiveTab('appointments')}
            type="button"
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer relative ${
              activeTab === 'appointments'
                ? 'bg-primary text-white shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">calendar_month</span>
            <span>{language === 'fr' ? 'Mes Rendez-vous' : 'المواعيد'}</span>
            {pendingCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-error text-on-error text-[10px] font-bold flex items-center justify-center">
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('details')}
            type="button"
            className={`flex-1 py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'details'
                ? 'bg-primary text-white shadow-xs'
                : 'text-on-surface-variant hover:text-on-surface'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">manage_accounts</span>
            <span>{language === 'fr' ? 'Coordonnées & Profil' : 'الملف والمعلومات'}</span>
          </button>
        </div>
      </section>

      {/* ========================================================= */}
      {/* TAB 1: GESTION DES HORAIRES ET DISPONIBILITÉS DU PRATICIEN */}
      {/* ========================================================= */}
      {activeTab === 'schedule' && (
        <div className="px-4 mt-2 space-y-4 animate-fadeIn">
          {/* General Consultation Settings Card */}
          <div className="bg-surface-container-lowest p-4 rounded-2xl border border-surface-container shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-surface-container pb-2">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-[20px]">tune</span>
                <h3 className="font-bold text-xs text-on-surface uppercase tracking-wider">
                  {language === 'fr' ? 'Paramètres des Consultations' : 'إعدادات الاستشارات'}
                </h3>
              </div>
              <span className="text-[10px] text-outline font-semibold">Configurable en temps réel</span>
            </div>

            {/* Durée par créneau */}
            <div>
              <label className="block text-xs font-bold text-on-surface mb-1">
                {language === 'fr' ? 'Durée moyenne d\'une consultation :' : 'مدة الاستشارة المعتادة:'}
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[20, 30, 45, 60].map(mins => (
                  <button
                    key={mins}
                    type="button"
                    onClick={() => setSlotDuration(mins)}
                    className={`py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                      slotDuration === mins
                        ? 'bg-primary text-white border-primary shadow-xs'
                        : 'bg-surface-container-low text-on-surface border-surface-container hover:bg-surface-container'
                    }`}
                  >
                    {mins} min
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles des options */}
            <div className="space-y-2 pt-1 text-xs">
              {/* Acceptation auto */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-surface-container-low border border-surface-container cursor-pointer">
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-primary text-[18px]">verified</span>
                  <div>
                    <span className="font-bold text-on-surface block">
                      {language === 'fr' ? 'Acceptation automatique des RDV' : 'قبول المواعيد تلقائياً'}
                    </span>
                    <span className="text-[11px] text-on-surface-variant">
                      {language === 'fr' ? 'Les créneaux disponibles sont validés sans confirmation manuelle' : 'تأكيد الحجز فورياً في الأوقات الشاغرة'}
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={autoAccept}
                  onChange={e => setAutoAccept(e.target.checked)}
                  className="w-4 h-4 accent-primary cursor-pointer"
                />
              </label>

              {/* Créneaux urgences */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-surface-container-low border border-surface-container cursor-pointer">
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-red-600 text-[18px]">emergency</span>
                  <div>
                    <span className="font-bold text-on-surface block">
                      {language === 'fr' ? 'Créneaux d\'urgence réservés' : 'حجز أوقات للطوارئ'}
                    </span>
                    <span className="text-[11px] text-on-surface-variant">
                      {language === 'fr' ? 'Bloquer 1 créneau par demi-journée pour les patients non programmés' : 'تخصيص موعد لكل فترة للحالات المستعجلة'}
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={allowEmergency}
                  onChange={e => setAllowEmergency(e.target.checked)}
                  className="w-4 h-4 accent-red-600 cursor-pointer"
                />
              </label>

              {/* Rappels SMS */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-surface-container-low border border-surface-container cursor-pointer">
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-secondary text-[18px]">sms</span>
                  <div>
                    <span className="font-bold text-on-surface block">
                      {language === 'fr' ? 'Rappels SMS automatiques' : 'تنبيهات الرسائل النصية SMS'}
                    </span>
                    <span className="text-[11px] text-on-surface-variant">
                      {language === 'fr' ? 'Envoyer un SMS de rappel à J-1 et 2h avant le rendez-vous' : 'تذكير المريض قبل الموعد بـ ٢٤ ساعة وساعتين'}
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={smsReminders}
                  onChange={e => setSmsReminders(e.target.checked)}
                  className="w-4 h-4 accent-primary cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* Weekly Schedule Planner */}
          <div className="bg-surface-container-lowest p-4 rounded-2xl border border-surface-container shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-primary text-[20px]">date_range</span>
                <h3 className="font-bold text-xs text-on-surface uppercase tracking-wider">
                  {language === 'fr' ? 'Planning Hebdomadaire & Horaires' : 'الجدول الأسبوعي وساعات العمل'}
                </h3>
              </div>
              <button
                type="button"
                onClick={handleApplyMondayToWeekdays}
                className="text-[11px] font-bold text-primary hover:underline cursor-pointer flex items-center gap-0.5"
              >
                <span className="material-symbols-outlined text-[14px]">content_copy</span>
                <span>{language === 'fr' ? 'Dupliquer Lundi' : 'تكرار الإثنين'}</span>
              </button>
            </div>

            <p className="text-[11px] text-on-surface-variant leading-relaxed">
              {language === 'fr'
                ? 'Activez les jours travaillés et ajustez vos heures de matinée, pause déjeuner/prière et après-midi.'
                : 'حدد أيام العمل وساعات الصباح واستراحة الغداء/الصلاة وفترة المساء.'}
            </p>

            <div className="space-y-2.5">
              {schedule.map((day, idx) => (
                <div
                  key={day.dayOfWeek}
                  className={`p-3 rounded-2xl border transition-all ${
                    day.active
                      ? 'bg-white border-surface-container shadow-2xs'
                      : 'bg-surface-container-low/70 border-surface-container/60 opacity-65'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={day.active}
                        onChange={e => handleDayChange(idx, 'active', e.target.checked)}
                        className="w-4 h-4 accent-primary cursor-pointer"
                        id={`day-toggle-${day.dayOfWeek}`}
                      />
                      <label
                        htmlFor={`day-toggle-${day.dayOfWeek}`}
                        className="font-bold text-xs text-on-surface cursor-pointer select-none"
                      >
                        {language === 'fr' ? day.dayName : day.dayNameAr}
                      </label>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        day.active
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-surface-container text-on-surface-variant'
                      }`}
                    >
                      {day.active
                        ? (language === 'fr' ? 'Cabinet Ouvert' : 'مفتوح')
                        : (language === 'fr' ? 'Fermé / Repos' : 'مغلق')}
                    </span>
                  </div>

                  {day.active && (
                    <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-surface-container">
                      {/* Plage Matinée */}
                      <div className="p-2 rounded-xl bg-surface-container-low/80 border border-surface-container">
                        <span className="text-[10px] font-bold text-tertiary flex items-center gap-1 mb-1">
                          <span className="material-symbols-outlined text-[13px]">wb_sunny</span>
                          <span>{language === 'fr' ? 'Matinée' : 'الصباح'}</span>
                        </span>
                        <div className="flex items-center gap-1 text-xs">
                          <input
                            type="time"
                            dir="ltr"
                            value={day.morningStart}
                            onChange={e => handleDayChange(idx, 'morningStart', e.target.value)}
                            className="w-full bg-white px-1.5 py-1 rounded-lg border border-surface-container text-center font-semibold text-xs tabular-nums font-mono"
                          />
                          <span className="text-outline text-[11px] shrink-0">{language === 'fr' ? 'à' : 'إلى'}</span>
                          <input
                            type="time"
                            dir="ltr"
                            value={day.morningEnd}
                            onChange={e => handleDayChange(idx, 'morningEnd', e.target.value)}
                            className="w-full bg-white px-1.5 py-1 rounded-lg border border-surface-container text-center font-semibold text-xs tabular-nums font-mono"
                          />
                        </div>
                      </div>

                      {/* Plage Après-midi */}
                      <div className="p-2 rounded-xl bg-surface-container-low/80 border border-surface-container">
                        <span className="text-[10px] font-bold text-primary flex items-center gap-1 mb-1">
                          <span className="material-symbols-outlined text-[13px]">wb_twilight</span>
                          <span>{language === 'fr' ? 'Après-midi' : 'المساء'}</span>
                        </span>
                        <div className="flex items-center gap-1 text-xs">
                          <input
                            type="time"
                            dir="ltr"
                            value={day.afternoonStart}
                            onChange={e => handleDayChange(idx, 'afternoonStart', e.target.value)}
                            className="w-full bg-white px-1.5 py-1 rounded-lg border border-surface-container text-center font-semibold text-xs tabular-nums font-mono"
                          />
                          <span className="text-outline text-[11px] shrink-0">{language === 'fr' ? 'à' : 'إلى'}</span>
                          <input
                            type="time"
                            dir="ltr"
                            value={day.afternoonEnd}
                            onChange={e => handleDayChange(idx, 'afternoonEnd', e.target.value)}
                            className="w-full bg-white px-1.5 py-1 rounded-lg border border-surface-container text-center font-semibold text-xs tabular-nums font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Bouton d'enregistrement du planning */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleSaveSchedule}
                className="w-full py-3 bg-primary hover:bg-primary-container text-on-primary font-bold text-xs rounded-xl shadow-md transition-transform active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">save</span>
                <span>{language === 'fr' ? 'Enregistrer mon planning & horaires' : 'حفظ الجدول وساعات العمل'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 2: GESTION DES RENDEZ-VOUS DU MÉDECIN */}
      {/* ========================================================= */}
      {activeTab === 'appointments' && (
        <div className="px-4 mt-2 space-y-3 animate-fadeIn">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-surface-container-lowest p-2.5 rounded-2xl border border-surface-container text-center shadow-2xs">
              <span className="text-[10px] font-bold uppercase text-on-surface-variant block">Aujourd'hui</span>
              <span className="text-lg font-black text-primary leading-tight">{todayCount}</span>
            </div>
            <div className="bg-surface-container-lowest p-2.5 rounded-2xl border border-surface-container text-center shadow-2xs">
              <span className="text-[10px] font-bold uppercase text-amber-700 block">En attente</span>
              <span className="text-lg font-black text-amber-600 leading-tight">{pendingCount}</span>
            </div>
            <div className="bg-surface-container-lowest p-2.5 rounded-2xl border border-surface-container text-center shadow-2xs">
              <span className="text-[10px] font-bold uppercase text-emerald-700 block">Honorés</span>
              <span className="text-lg font-black text-emerald-600 leading-tight">{completedCount}</span>
            </div>
          </div>

          {/* Search Bar for Appointments */}
          <div className="relative flex items-center bg-surface-container-lowest rounded-xl border border-surface-container px-3 py-2 shadow-2xs">
            <span className="material-symbols-outlined text-outline text-[18px] mr-2">search</span>
            <input
              type="text"
              value={searchPatient}
              onChange={e => setSearchPatient(e.target.value)}
              placeholder={language === 'fr' ? 'Rechercher patient, N° dossier, téléphone...' : 'ابحث عن مريض، رقم الملف، الهاتف...'}
              className="w-full bg-transparent text-xs text-on-surface focus:outline-none placeholder:text-outline"
            />
            {searchPatient && (
              <button type="button" onClick={() => setSearchPatient('')} className="text-outline hover:text-on-surface">
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            )}
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {[
              { id: 'all', label: language === 'fr' ? 'Tous' : 'الكل' },
              { id: 'today', label: language === 'fr' ? 'Aujourd\'hui' : 'اليوم' },
              { id: 'upcoming', label: language === 'fr' ? 'À venir' : 'القادمة' },
              { id: 'pending', label: language === 'fr' ? 'En attente' : 'قيد الانتظار' },
              { id: 'completed', label: language === 'fr' ? 'Terminés' : 'تمت' },
              { id: 'cancelled', label: language === 'fr' ? 'Annulés' : 'ملغاة' },
            ].map(f => (
              <button
                key={f.id}
                type="button"
                onClick={() => setAppointmentFilter(f.id as any)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all cursor-pointer ${
                  appointmentFilter === f.id
                    ? 'bg-primary text-white shadow-xs'
                    : 'bg-surface-container-low text-on-surface-variant hover:bg-surface-container border border-surface-container'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Appointment Cards List */}
          {filteredAppointments.length === 0 ? (
            <div className="p-8 bg-surface-container-lowest rounded-2xl border border-surface-container text-center space-y-2">
              <span className="material-symbols-outlined text-outline text-[36px]">event_busy</span>
              <p className="font-bold text-xs text-on-surface">
                {language === 'fr' ? 'Aucun rendez-vous trouvé' : 'لم يتم العثور على أي موعد'}
              </p>
              <p className="text-[11px] text-on-surface-variant">
                {language === 'fr' ? 'Modifiez vos filtres ou effectuez une autre recherche.' : 'يرجى تغيير خيارات البحث.'}
              </p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {filteredAppointments.map(apt => {
                const isConfirmed = apt.status === 'confirmed';
                const isPending = apt.status === 'pending';
                const isCompleted = apt.status === 'completed';
                const isCancelled = apt.status === 'cancelled';

                return (
                  <div
                    key={apt.id}
                    className={`bg-white rounded-2xl p-3.5 border shadow-2xs space-y-2.5 transition-all ${
                      isCancelled
                        ? 'opacity-65 border-surface-container'
                        : isPending
                        ? 'border-amber-300 ring-1 ring-amber-200'
                        : 'border-surface-container hover:shadow-xs'
                    }`}
                  >
                    {/* Top Row: Date, Time & Status */}
                    <div className="flex items-center justify-between gap-2 border-b border-surface-container pb-2">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-on-surface">
                        <span className="material-symbols-outlined text-primary text-[18px]">event</span>
                        <span>
                          {translateDateFormatted(apt.dateFormatted || apt.date, language)} •{' '}
                          <span dir="ltr" className="inline-block tabular-nums font-mono font-semibold">
                            {apt.time}
                          </span>
                        </span>
                      </div>

                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                          isConfirmed
                            ? 'bg-emerald-100 text-emerald-800'
                            : isPending
                            ? 'bg-amber-100 text-amber-800'
                            : isCompleted
                            ? 'bg-surface-container-high text-on-surface'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                        <span>
                          {isConfirmed
                            ? (language === 'fr' ? 'Confirmé' : 'مؤكد')
                            : isPending
                            ? (language === 'fr' ? 'En attente' : 'قيد الانتظار')
                            : isCompleted
                            ? (language === 'fr' ? 'Honoré' : 'تمت الاستشارة')
                            : (language === 'fr' ? 'Annulé' : 'ملغى')}
                        </span>
                      </span>
                    </div>

                    {/* Patient & Consultation Details */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h4 className="font-bold text-xs text-on-surface truncate">
                          {apt.patientName}
                        </h4>
                        <p className="text-[11px] text-on-surface-variant mt-0.5 truncate">
                          {language === 'fr' ? 'Motif :' : 'السبب :'} <span className="text-on-surface font-medium">{language === 'fr' ? apt.reason : (apt.reasonAr || apt.reason)}</span>
                        </p>
                        <div className="flex items-center gap-2 mt-1 text-[10px] text-outline">
                          <span>{language === 'fr' ? 'Dossier :' : 'الملف :'} {apt.referenceNumber}</span>
                          <span>•</span>
                          <span>NNI : {apt.patientNni}</span>
                        </div>
                      </div>

                      <div className="text-end shrink-0">
                        <span className="px-1.5 py-0.5 rounded-md bg-secondary-container text-on-secondary-container text-[10px] font-bold block mb-0.5">
                          {apt.insuranceType === 'CNAM' ? 'CNAM' : apt.insuranceType === 'CNASS' ? 'CNASS' : (language === 'fr' ? 'Standard' : 'عادي')}
                        </span>
                        <span className="text-[11px] font-bold text-outline block">{language === 'fr' ? '30 min' : '٣٠ د'}</span>
                      </div>
                    </div>

                    {/* Action Buttons for Doctor */}
                    {!isCancelled && (
                      <div className="flex items-center gap-1.5 pt-2 border-t border-surface-container flex-wrap text-xs">
                        {/* Call to Office */}
                        {isConfirmed && (
                          <button
                            type="button"
                            onClick={() => {
                              showToast(
                                language === 'fr' ? 'Patient appelé' : 'تم استدعاء المريض',
                                language === 'fr'
                                  ? `${apt.patientName} est invité à se présenter au Cabinet 204.`
                                  : `تمت دعوة ${apt.patientName} للدخول إلى العيادة.`
                              );
                            }}
                            className="flex-1 py-1.5 px-2 bg-emerald-50 hover:bg-emerald-100 text-[#006948] rounded-xl font-bold text-[11px] flex items-center justify-center gap-1 transition-colors cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-[15px]">campaign</span>
                            <span>{language === 'fr' ? 'Appeler au cabinet' : 'استدعاء للعيادة'}</span>
                          </button>
                        )}

                        {/* Confirm if pending */}
                        {isPending && (
                          <button
                            type="button"
                            onClick={() => updateAppointmentStatus(apt.id, 'confirmed')}
                            className="flex-1 py-1.5 px-2 bg-primary text-white rounded-xl font-bold text-[11px] flex items-center justify-center gap-1 transition-colors cursor-pointer shadow-2xs"
                          >
                            <span className="material-symbols-outlined text-[15px]">check_circle</span>
                            <span>{language === 'fr' ? 'Valider le RDV' : 'تأكيد الموعد'}</span>
                          </button>
                        )}

                        {/* Mark completed */}
                        {isConfirmed && (
                          <button
                            type="button"
                            onClick={() => updateAppointmentStatus(apt.id, 'completed')}
                            className="py-1.5 px-2.5 bg-surface-container hover:bg-surface-container-high text-on-surface rounded-xl font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-[15px] text-emerald-700">task_alt</span>
                            <span>{language === 'fr' ? 'Terminé' : 'مكتمل'}</span>
                          </button>
                        )}

                        {/* Reschedule Button */}
                        <button
                          type="button"
                          onClick={() => {
                            setReschedulingApt(apt);
                            setNewDate(apt.date);
                            setNewTime(apt.time);
                          }}
                          className="py-1.5 px-2.5 bg-surface-container hover:bg-surface-container-high text-on-surface rounded-xl font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[15px] text-primary">edit_calendar</span>
                          <span>{language === 'fr' ? 'Reporter' : 'تأجيل'}</span>
                        </button>

                        {/* Cancel Button */}
                        <button
                          type="button"
                          onClick={() => updateAppointmentStatus(apt.id, 'cancelled')}
                          className="py-1.5 px-2.5 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl font-bold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <span className="material-symbols-outlined text-[15px]">cancel</span>
                          <span>{language === 'fr' ? 'Annuler' : 'إلغاء'}</span>
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 3: INFORMATIONS PROFESSIONNELLES & BIO */}
      {/* ========================================================= */}
      {activeTab === 'details' && (
        <div className="px-4 mt-2 space-y-4 animate-fadeIn">
          <div className="bg-surface-container-lowest p-4 rounded-2xl border border-surface-container shadow-xs space-y-3">
            <div className="flex items-center gap-2 border-b border-surface-container pb-2">
              <span className="material-symbols-outlined text-primary text-[20px]">verified</span>
              <h3 className="font-bold text-xs text-on-surface uppercase tracking-wider">
                {language === 'fr' ? 'Conventionnement & Agrément' : 'الاعتماد والترخيص'}
              </h3>
            </div>

            <div>
              <label className="block font-bold text-on-surface mb-1 text-xs">
                {language === 'fr' ? 'Années de Pratique :' : 'سنوات الخبرة:'}
              </label>
              <input
                type="number"
                value={experienceYears}
                onChange={e => setExperienceYears(Number(e.target.value))}
                className="w-full px-3 py-2 bg-surface-container-low rounded-xl border border-surface-container font-bold text-sm text-on-surface"
              />
            </div>

            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 flex items-start gap-2">
              <span className="material-symbols-outlined text-[18px] text-emerald-700 mt-0.5">verified_user</span>
              <div>
                <span className="font-bold block">Conventionné CNAM & CNASS Mauritanie</span>
                <span className="text-[11px] text-emerald-800">
                  Prise en charge du tiers-payant automatique pour les assurés sociaux. Télétransmission directe des feuilles de soins.
                </span>
              </div>
            </div>
          </div>

          {/* Contact & Bio Card */}
          <div className="bg-surface-container-lowest p-4 rounded-2xl border border-surface-container shadow-xs space-y-3">
            <div className="flex items-center gap-2 border-b border-surface-container pb-2">
              <span className="material-symbols-outlined text-primary text-[20px]">person</span>
              <h3 className="font-bold text-xs text-on-surface uppercase tracking-wider">
                {language === 'fr' ? 'Coordonnées & Présentation' : 'معلومات الاتصال والنبذة'}
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-bold text-on-surface mb-1">
                  {language === 'fr' ? 'Téléphone Professionnel :' : 'الهاتف المهني :'}
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-surface-container-low rounded-xl border border-surface-container text-xs text-on-surface font-medium"
                />
              </div>

              <div>
                <label className="block font-bold text-on-surface mb-1">
                  {language === 'fr' ? 'Email Professionnel :' : 'البريد الإلكتروني المهني :'}
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-surface-container-low rounded-xl border border-surface-container text-xs text-on-surface font-medium"
                />
              </div>
            </div>

            {/* Langues parlées */}
            <div className="text-xs">
              <label className="block font-bold text-on-surface mb-1.5">
                {language === 'fr' ? 'Langues parlées en consultation :' : 'لغات التواصل في العيادة :'}
              </label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: 'Arabe (Hassaniya)', labelFr: 'Arabe (Hassaniya)', labelAr: 'العربية (الحسانية)' },
                  { id: 'Français', labelFr: 'Français', labelAr: 'الفرنسية' },
                  { id: 'Poular', labelFr: 'Poular', labelAr: 'البولارية' },
                  { id: 'Soninké', labelFr: 'Soninké', labelAr: 'السوننكية' },
                  { id: 'Wolof', labelFr: 'Wolof', labelAr: 'الولوفية' },
                  { id: 'Anglais', labelFr: 'Anglais', labelAr: 'الإنجليزية' },
                ].map(item => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => toggleLanguageOption(item.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all border cursor-pointer ${
                      selectedLanguages.includes(item.id)
                        ? 'bg-[#006948] text-white border-[#006948]'
                        : 'bg-surface-container-low text-on-surface border-surface-container'
                    }`}
                  >
                    {language === 'fr' ? item.labelFr : item.labelAr}
                  </button>
                ))}
              </div>
            </div>

            {/* Diplômes & Formations */}
            <div className="text-xs">
              <label className="block font-bold text-on-surface mb-1">
                {language === 'fr' ? 'Diplômes & Spécialisations :' : 'الشهادات والتخصصات :'}
              </label>
              <textarea
                rows={2}
                value={education}
                onChange={e => setEducation(e.target.value)}
                className="w-full px-3 py-2 bg-surface-container-low rounded-xl border border-surface-container text-xs text-on-surface font-medium"
              />
            </div>

            {/* Bio */}
            <div className="text-xs">
              <label className="block font-bold text-on-surface mb-1">
                {language === 'fr' ? 'Biographie & Présentation du Cabinet :' : 'السيرة المهنية والتعريف بالعيادة :'}
              </label>
              <textarea
                rows={3}
                value={bio}
                onChange={e => setBio(e.target.value)}
                className="w-full px-3 py-2 bg-surface-container-low rounded-xl border border-surface-container text-xs text-on-surface font-medium"
              />
            </div>

            <button
              type="button"
              onClick={handleSaveDetails}
              className="w-full py-3 bg-primary hover:bg-primary-container text-on-primary font-bold text-xs rounded-xl shadow-md transition-transform active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">save</span>
              <span>{language === 'fr' ? 'Enregistrer les informations' : 'حفظ البيانات'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Reschedule Modal */}
      {reschedulingApt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-surface-container text-start space-y-4">
            <div className="flex items-center justify-between border-b border-surface-container pb-2">
              <h3 className="font-bold text-sm text-on-surface">
                {language === 'fr' ? 'Reporter le rendez-vous' : 'تأجيل الموعد'}
              </h3>
              <button
                type="button"
                onClick={() => setReschedulingApt(null)}
                className="text-outline hover:text-on-surface"
              >
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <div className="p-2.5 rounded-xl bg-surface-container-low text-xs">
              <span className="text-outline block text-[10px]">
                {language === 'fr' ? 'Patient concerné :' : 'المريض :'}
              </span>
              <span className="font-bold text-on-surface text-xs block">{reschedulingApt.patientName}</span>
              <span className="text-[11px] text-on-surface-variant">
                {language === 'fr' ? `Motif : ${reschedulingApt.reason}` : `السبب : ${reschedulingApt.reasonAr || reschedulingApt.reason}`}
              </span>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-on-surface mb-1">
                  {language === 'fr' ? 'Nouvelle Date :' : 'التاريخ الجديد :'}
                </label>
                <input
                  type="date"
                  value={newDate}
                  onChange={e => setNewDate(e.target.value)}
                  className="w-full px-3 py-2 bg-surface-container-low rounded-xl border border-surface-container font-semibold text-xs text-on-surface"
                />
              </div>

              <div>
                <label className="block font-bold text-on-surface mb-1">
                  {language === 'fr' ? 'Nouvel Horaire :' : 'التوقيت الجديد :'}
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {['09:00', '09:30', '10:00', '10:30', '11:00', '15:00', '15:30', '16:00'].map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setNewTime(t)}
                      className={`py-1.5 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                        newTime === t
                          ? 'bg-primary text-white border-primary'
                          : 'bg-surface-container-low text-on-surface border-surface-container'
                      }`}
                    >
                      <span dir="ltr" className="inline-block tabular-nums font-mono font-bold">
                        {t}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-surface-container">
              <button
                type="button"
                onClick={() => setReschedulingApt(null)}
                className="px-3 py-2 text-xs font-bold text-on-surface-variant hover:bg-surface-container rounded-xl"
              >
                {language === 'fr' ? 'Annuler' : 'إلغاء'}
              </button>
              <button
                type="button"
                onClick={handleConfirmReschedule}
                className="px-4 py-2 bg-primary text-white text-xs font-bold rounded-xl shadow-xs"
              >
                {language === 'fr' ? 'Confirmer le report' : 'تأكيد التأجيل'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
