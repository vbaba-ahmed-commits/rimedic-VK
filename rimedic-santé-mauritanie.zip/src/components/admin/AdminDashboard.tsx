import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ESTABLISHMENTS_DATA, SPECIALTIES_DATA } from '../../data/mockData';

export const AdminDashboard: React.FC = () => {
  const {
    language,
    pendingFacilities,
    validateFacility,
    rejectFacility,
    showToast,
    setIsCityModalOpen,
    navigateTo
  } = useApp();

  const [activeWilayaTab, setActiveWilayaTab] = useState<'all' | 'nouakchott' | 'nouadhibou' | 'trarza'>('all');
  const [showNewCenterModal, setShowNewCenterModal] = useState(false);
  const [newCenterName, setNewCenterName] = useState('');
  const [newCenterType, setNewCenterType] = useState('clinique');

  const handleAddNewCenter = (e: React.FormEvent) => {
    e.preventDefault();
    if (newCenterName.trim()) {
      setShowNewCenterModal(false);
      setNewCenterName('');
      showToast(
        language === 'fr' ? 'Établissement enregistré !' : 'تم قيد المؤسسة الصحية !',
        language === 'fr'
          ? `${newCenterName} ajouté à la file de validation ministérielle`
          : `تمت إضافة ${newCenterName} إلى قائمة الاعتماد الوزاري`
      );
    }
  };

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Top National Supervision Banner from Stitch */}
      <section className="px-4 pt-3 pb-2">
        <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-primary-container text-on-primary">
                <span className="material-symbols-outlined text-[18px]">verified_user</span>
              </span>
              <div>
                <span className="text-[10px] text-primary uppercase font-bold tracking-wide">
                  {language === 'fr' ? 'Ministère de la Santé / RIMEDIC' : 'وزارة الصحة / ريميديك'}
                </span>
                <p className="font-bold text-sm text-on-surface">
                  {language === 'fr' ? 'Supervision Nationale' : 'الإشراف الوطني المباشر'}
                </p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-secondary-container text-on-secondary-container text-[11px] font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"></span>
              <span>{language === 'fr' ? 'Direct' : 'مباشر'}</span>
            </span>
          </div>

          <div className="flex items-center justify-between pt-1 border-t border-surface-container text-xs text-on-surface-variant">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-primary text-[16px]">account_circle</span>
              <span className="font-semibold text-on-surface">
                {language === 'fr' ? 'Admin Principal (Nouakchott)' : 'المسؤول المركزي (نواكشوط)'}
              </span>
            </div>
            <span className="text-[10px] text-tertiary font-bold tracking-wider font-mono">
              MR-ADM-01
            </span>
          </div>

          {/* Telecom Relay Nodes */}
          <div className="mt-2.5 p-2 rounded-xl bg-surface-container-low flex items-center justify-between text-xs border border-surface-container">
            <div className="flex items-center gap-1.5 min-w-0">
              <span className="w-2 h-2 rounded-full bg-primary shrink-0"></span>
              <span className="text-on-surface font-semibold truncate text-[11px]">
                {language === 'fr'
                  ? 'Nœuds Opérateurs: Mauritel • Mattel • Chinguitel'
                  : 'ربط الاتصالات: موريتل • ماتال • شنقيتل'}
              </span>
            </div>
            <span className="px-2 py-0.5 rounded font-bold text-[10px] bg-primary text-on-primary shrink-0">
              {language === 'fr' ? 'Opérationnel' : 'مشتغل'}
            </span>
          </div>
        </div>
      </section>

      {/* Wilaya Filter Strip */}
      <section className="px-4 my-1 flex flex-col gap-1.5">
        <div className="flex items-center justify-between px-1 text-xs">
          <span className="font-bold text-on-surface-variant uppercase tracking-wider text-[11px]">
            {language === 'fr' ? 'Territoires sous écoute' : 'المناطق الخاضعة للإشراف'}
          </span>
          <span className="text-[11px] font-bold text-primary">
            {language === 'fr' ? '11 Wilayas actives' : '١١ ولاية نشطة'}
          </span>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
          <button
            onClick={() => setActiveWilayaTab('all')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 flex items-center gap-1 transition-all ${
              activeWilayaTab === 'all'
                ? 'bg-primary text-on-primary shadow-xs'
                : 'bg-surface-container-lowest text-on-surface-variant border border-surface-container'
            }`}
          >
            <span className="material-symbols-outlined text-[14px]">public</span>
            <span>{language === 'fr' ? 'Toute la Mauritanie' : 'عموم موريتانيا'}</span>
          </button>
          <button
            onClick={() => setActiveWilayaTab('nouakchott')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
              activeWilayaTab === 'nouakchott'
                ? 'bg-primary text-on-primary shadow-xs'
                : 'bg-surface-container-lowest text-on-surface-variant border border-surface-container'
            }`}
          >
            {language === 'fr' ? 'Nouakchott (Ouest/Nord/Sud)' : 'نواكشوط (الغربية/الشمالية/الجنوبية)'}
          </button>
          <button
            onClick={() => setActiveWilayaTab('nouadhibou')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
              activeWilayaTab === 'nouadhibou'
                ? 'bg-primary text-on-primary shadow-xs'
                : 'bg-surface-container-lowest text-on-surface-variant border border-surface-container'
            }`}
          >
            {language === 'fr' ? 'Dakhlet Nouadhibou' : 'داخلة نواذيبو'}
          </button>
          <button
            onClick={() => setActiveWilayaTab('trarza')}
            className={`px-3 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all ${
              activeWilayaTab === 'trarza'
                ? 'bg-primary text-on-primary shadow-xs'
                : 'bg-surface-container-lowest text-on-surface-variant border border-surface-container'
            }`}
          >
            {language === 'fr' ? 'Trarza (Rosso)' : 'الترارزة (روصو)'}
          </button>
        </div>
      </section>

      {/* Global KPI Metrics 2x2 Grid from Stitch */}
      <section className="px-4 my-2">
        <div className="grid grid-cols-2 gap-2">
          {/* KPI 1 */}
          <div className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col justify-between">
            <div className="flex items-center justify-between mb-1">
              <span className="w-7 h-7 rounded-lg bg-surface-container-low text-primary flex items-center justify-center">
                <span className="material-symbols-outlined text-[16px]">local_hospital</span>
              </span>
              <span className="text-[10px] text-primary font-bold">
                {language === 'fr' ? '28 val. / 6 en attente' : '٢٨ معتمد / ٦ معلق'}
              </span>
            </div>
            <div>
              <p className="text-2xl font-bold text-on-surface leading-none mb-0.5">34</p>
              <p className="text-xs text-on-surface-variant">
                {language === 'fr' ? 'Centres de Santé' : 'المراكز الصحية'}
              </p>
              <div className="w-full bg-surface-container rounded-full h-1.5 mt-2 overflow-hidden flex">
                <div className="bg-primary h-full" style={{ width: '82%' }}></div>
                <div className="bg-tertiary-fixed-dim h-full" style={{ width: '18%' }}></div>
              </div>
            </div>
          </div>

          {/* KPI 2 */}
          <div className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col justify-between">
            <div className="flex items-center justify-between mb-1">
              <span className="w-7 h-7 rounded-lg bg-surface-container-low text-primary flex items-center justify-center">
                <span className="material-symbols-outlined text-[16px]">stethoscope</span>
              </span>
              <span className="px-1.5 py-0.2 rounded font-bold text-[10px] bg-secondary-fixed text-on-secondary-fixed">
                {language === 'fr' ? '11 Wilayas' : '١١ ولاية'}
              </span>
            </div>
            <div>
              <p className="text-2xl font-bold text-on-surface leading-none mb-0.5">142</p>
              <p className="text-xs text-on-surface-variant">
                {language === 'fr' ? 'Médecins Inscrits' : 'الأطباء المسجلون'}
              </p>
              <span className="inline-block mt-2 text-[10px] text-primary font-bold">
                {language === 'fr' ? "Taux d'activité 96%" : 'نسبة النشاط ٩٦٪'}
              </span>
            </div>
          </div>

          {/* KPI 3 */}
          <div className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col justify-between">
            <div className="flex items-center justify-between mb-1">
              <span className="w-7 h-7 rounded-lg bg-surface-container-low text-primary flex items-center justify-center">
                <span className="material-symbols-outlined text-[16px]">event_available</span>
              </span>
              <span className="text-[10px] text-primary font-bold flex items-center">
                <span className="material-symbols-outlined text-[13px]">trending_up</span> +18%
              </span>
            </div>
            <div>
              <p className="text-2xl font-bold text-on-surface leading-none mb-0.5">1 840</p>
              <p className="text-xs text-on-surface-variant">
                {language === 'fr' ? 'Consultations Mois' : 'معاينات الشهر'}
              </p>
              <p className="text-[10px] text-on-surface-variant mt-1.5 truncate">
                {language === 'fr' ? 'Flux: 61 RDV/jour' : 'المعدل: ٦١ موعد/يوم'}
              </p>
            </div>
          </div>

          {/* KPI 4 */}
          <div className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col justify-between">
            <div className="flex items-center justify-between mb-1">
              <span className="w-7 h-7 rounded-lg bg-surface-container-low text-tertiary flex items-center justify-center">
                <span className="material-symbols-outlined text-[16px]">credit_card</span>
              </span>
              <span className="text-[10px] text-tertiary font-bold">CNAM • CNASS</span>
            </div>
            <div>
              <p className="text-2xl font-bold text-tertiary leading-none mb-0.5">89%</p>
              <p className="text-xs text-on-surface-variant">
                {language === 'fr' ? 'Tiers-payant Assuré' : 'التأمين والدفع الجزئي'}
              </p>
              <span className="inline-block mt-2 text-[10px] text-primary font-bold">
                {language === 'fr' ? 'Télétransmission OK' : 'الإرسال الرقمي مؤكد'}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Validation des Établissements Section */}
      <section className="px-4 my-2 flex flex-col gap-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-primary text-[20px]">domain_verification</span>
            <h2 className="font-bold text-sm text-on-surface">
              {language === 'fr' ? 'Validation des Établissements' : 'اعتماد المؤسسات الصحية'}
            </h2>
          </div>
          <span className="px-2 py-0.5 rounded-full bg-surface-container text-on-surface-variant text-[10px] font-bold">
            {language === 'fr' ? `${pendingFacilities.length} en attente` : `${pendingFacilities.length} في الانتظار`}
          </span>
        </div>

        {/* Existing Verified: Clinique Ibn Sina */}
        <div className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col gap-1.5">
          <div className="flex items-start justify-between">
            <div className="min-w-0 pr-2">
              <h3 className="font-bold text-xs text-on-surface truncate">
                {language === 'fr' ? 'Clinique Ibn Sina' : 'عيادة ابن سينا'}
              </h3>
              <p className="text-[11px] text-on-surface-variant flex items-center gap-1 mt-0.5">
                <span className="material-symbols-outlined text-[13px]">pin_drop</span>
                <span>{language === 'fr' ? 'Tevragh Zeina, Nouakchott Ouest' : 'تفرغ زينة، نواكشوط الغربية'}</span>
              </p>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-secondary-fixed text-on-secondary-fixed text-[10px] font-bold flex items-center gap-1 shrink-0">
              <span className="material-symbols-outlined text-[13px]">verified</span>
              <span>{language === 'fr' ? 'Conventionné CNAM' : 'معتمد كنام'}</span>
            </span>
          </div>
          <div className="flex items-center justify-between pt-1 border-t border-surface-container text-xs text-on-surface-variant">
            <span className="text-[11px]">{language === 'fr' ? 'Licence N° MS-2023/881' : 'ترخيص رقم MS-2023/881'}</span>
            <span className="text-primary font-bold text-[11px]">
              {language === 'fr' ? '14 Praticiens rattachés' : '١٤ طبيباً مسجلاً'}
            </span>
          </div>
        </div>

        {/* Pending Centers with Live Interactive Validation */}
        {pendingFacilities.map(center => (
          <div
            key={center.id}
            className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-tertiary-fixed flex flex-col gap-2 relative overflow-hidden"
          >
            <div className="flex items-start justify-between">
              <div className="min-w-0 pr-2">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-bold text-xs text-on-surface truncate">{center.name}</h3>
                  <span className="w-2 h-2 rounded-full bg-tertiary animate-ping"></span>
                </div>
                <p className="text-[11px] text-on-surface-variant flex items-center gap-1 mt-0.5">
                  <span className="material-symbols-outlined text-[13px]">pin_drop</span>
                  <span>{center.neighborhood}, {language === 'fr' ? 'Nouakchott' : 'نواكشوط'}</span>
                </p>
              </div>
              <span className="px-2 py-0.5 rounded-lg bg-tertiary-fixed text-on-tertiary-fixed text-[10px] font-bold flex items-center gap-1 shrink-0">
                <span className="material-symbols-outlined text-[13px]">pending_actions</span>
                <span>{language === 'fr' ? 'Agrément en attente' : 'الاعتماد قيد المراجعة'}</span>
              </span>
            </div>

            <div className="p-2 rounded-xl bg-surface-container-low text-xs text-on-surface-variant space-y-0.5 border border-surface-container">
              <p className="flex items-center justify-between">
                <span>{language === 'fr' ? 'Dossier:' : 'الملف:'} <strong className="text-on-surface">{center.licenseNumber || 'DRS-NKC-0492'}</strong></span>
                <span className="text-tertiary font-bold text-[10px]">
                  {language === 'fr' ? 'Reçu il y a 4h' : 'وصل قبل ٤ ساعات'}
                </span>
              </p>
              <p className="text-[10px] text-outline leading-tight">
                {language === 'fr'
                  ? "Pièces jointes: Registre de commerce, agrément ministériel provisoire, police d'assurance civile."
                  : 'المرفقات: السجل التجاري، الاعتماد الوزاري المؤقت، وثيقة التأمين المهني.'}
              </p>
            </div>

            <div className="flex items-center gap-2 pt-0.5">
              <button
                onClick={() => validateFacility(center.id)}
                className="flex-1 py-2 rounded-xl bg-primary hover:bg-primary-container text-on-primary font-bold text-xs shadow-xs active:scale-95 transition-all flex items-center justify-center gap-1"
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">check_circle</span>
                <span>{language === 'fr' ? 'Valider le centre' : 'اعتماد المركز'}</span>
              </button>
              <button
                onClick={() => rejectFacility(center.id)}
                aria-label={language === 'fr' ? "Rejeter" : "رفض"}
                className="px-3 py-2 rounded-xl bg-error-container text-on-error-container text-xs font-bold active:scale-95 transition-all flex items-center justify-center hover:opacity-90"
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">block</span>
              </button>
            </div>
          </div>
        ))}

        {/* Register New Facility Button */}
        <button
          onClick={() => setShowNewCenterModal(true)}
          className="w-full py-3 px-4 rounded-2xl bg-primary-container text-on-primary font-bold text-xs shadow-sm flex items-center justify-center gap-2 active:scale-98 transition-all"
          type="button"
        >
          <span className="material-symbols-outlined text-[18px]">add_business</span>
          <span>{language === 'fr' ? '+ Répertorier un nouvel établissement' : '+ تسجيل مؤسسة صحية جديدة'}</span>
        </button>
      </section>

      {/* Modal to Register a new facility */}
      {showNewCenterModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleAddNewCenter}
            className="w-full max-w-sm bg-white rounded-2xl p-4 shadow-xl border border-surface-container flex flex-col gap-3"
          >
            <div className="flex items-center justify-between pb-1 border-b border-surface-container">
              <h3 className="font-bold text-sm text-on-surface">
                {language === 'fr' ? 'Ajouter un établissement' : 'إضافة مؤسسة صحية'}
              </h3>
              <button type="button" onClick={() => setShowNewCenterModal(false)}>
                <span className="material-symbols-outlined text-[18px]">close</span>
              </button>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-on-surface">
                {language === 'fr' ? "Nom de l'établissement" : 'اسم المؤسسة'}
              </label>
              <input
                type="text"
                value={newCenterName}
                onChange={e => setNewCenterName(e.target.value)}
                placeholder={language === 'fr' ? "Ex : Clinique Nouakchott Santé" : "مثال : عيادة نواكشوط الصحية"}
                required
                className="px-3 py-2 rounded-xl bg-surface-container-low text-xs border border-surface-container outline-none"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-xs font-bold text-on-surface">
                {language === 'fr' ? 'Type de structure' : 'نوع المنشأة'}
              </label>
              <select
                value={newCenterType}
                onChange={e => setNewCenterType(e.target.value)}
                className="px-3 py-2 rounded-xl bg-surface-container-low text-xs border border-surface-container outline-none"
              >
                <option value="clinique">{language === 'fr' ? 'Clinique privée' : 'عيادة خاصة'}</option>
                <option value="hopital">{language === 'fr' ? 'Hôpital public' : 'مستشفى وطني'}</option>
                <option value="dentaire">{language === 'fr' ? 'Cabinet dentaire' : 'عيادة أسنان'}</option>
                <option value="laboratoire">{language === 'fr' ? "Laboratoire d'analyses" : 'مختبر تحاليل'}</option>
                <option value="imagerie">{language === 'fr' ? "Centre d'imagerie" : 'مركز أشعة'}</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowNewCenterModal(false)}
                className="py-2 rounded-xl bg-surface-container text-xs font-bold"
              >
                {language === 'fr' ? 'Annuler' : 'إلغاء'}
              </button>
              <button type="submit" className="py-2 rounded-xl bg-primary text-white text-xs font-bold shadow-xs">
                {language === 'fr' ? 'Enregistrer' : 'حفظ'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Operational & Governance Modules Bento from Stitch */}
      <section className="px-4 my-2 flex flex-col gap-2">
        <div className="flex items-center justify-between px-1 text-xs">
          <span className="font-bold text-on-surface">
            {language === 'fr' ? 'Gouvernance & Paramètres' : 'الحكامة والإعدادات'}
          </span>
          <span className="text-[10px] text-on-surface-variant uppercase font-bold">
            {language === 'fr' ? 'Niveau Réseau' : 'مستوى الشبكة'}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {/* Spécialités */}
          <div
            onClick={() => navigateTo('specialties')}
            className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col justify-between hover:bg-surface-container-low transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-surface-container-low text-primary flex items-center justify-center mb-2">
              <span className="material-symbols-outlined text-[20px]">medical_services</span>
            </div>
            <div>
              <h4 className="font-bold text-xs text-on-surface">
                {language === 'fr' ? 'Spécialités' : 'التخصصات'}
              </h4>
              <p className="text-[11px] text-on-surface-variant">
                {language === 'fr' ? `${SPECIALTIES_DATA.length} spécialités` : `${SPECIALTIES_DATA.length} تخصصاً`}
              </p>
              <span className="text-[10px] text-primary font-bold">
                {language === 'fr' ? '68 sous-branches' : '٦٨ فرعاً'}
              </span>
            </div>
          </div>

          {/* Wilayas & Villes */}
          <div
            onClick={() => setIsCityModalOpen(true)}
            className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col justify-between hover:bg-surface-container-low transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-surface-container-low text-primary flex items-center justify-center mb-2">
              <span className="material-symbols-outlined text-[20px]">map</span>
            </div>
            <div>
              <h4 className="font-bold text-xs text-on-surface">
                {language === 'fr' ? 'Wilayas & Villes' : 'الولايات والمدن'}
              </h4>
              <p className="text-[11px] text-on-surface-variant">
                {language === 'fr' ? '11 Villes actives' : '١١ مدينة نشطة'}
              </p>
              <span className="text-[10px] text-primary font-bold">
                {language === 'fr' ? '36 Moughataas' : '٣٦ مقاطعة'}
              </span>
            </div>
          </div>

          {/* Passerelle OTP */}
          <div
            onClick={() => showToast(
              language === 'fr' ? 'Passerelle SMS & OTP' : 'بوابة الرسائل وOTP',
              language === 'fr' ? 'Statut Mauritel 99.8% • Mattel 99.1% • Chinguitel 99.4%' : 'حالة موريتل ٩٩.٨٪ • ماتال ٩٩.١٪ • شنقيتل ٩٩.٤٪'
            )}
            className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col justify-between hover:bg-surface-container-low transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-surface-container-low text-secondary flex items-center justify-center mb-2">
              <span className="material-symbols-outlined text-[20px]">sms</span>
            </div>
            <div>
              <h4 className="font-bold text-xs text-on-surface">
                {language === 'fr' ? 'Passerelle OTP' : 'بوابة OTP والرسائل'}
              </h4>
              <p className="text-[11px] text-on-surface-variant">
                {language === 'fr' ? 'SMS & WhatsApp' : 'الرسائل القصيرة وواتساب'}
              </p>
              <span className="text-[10px] text-primary font-bold">
                {language === 'fr' ? 'Quota 99.4% dispo' : 'نسبة التوفر ٩٩.٤٪'}
              </span>
            </div>
          </div>

          {/* Audit Sécurité */}
          <div
            onClick={() => showToast(
              language === 'fr' ? 'Audit de Sécurité' : 'تدقيق الأمان والخصوصية',
              language === 'fr' ? 'Conformité CNAM & Hébergement National certifié' : 'مطابقة معايير كنام والاستضافة الوطنية المعتمدة'
            )}
            className="p-3.5 rounded-2xl bg-surface-container-lowest shadow-xs border border-surface-container flex flex-col justify-between hover:bg-surface-container-low transition-colors cursor-pointer"
          >
            <div className="w-8 h-8 rounded-lg bg-surface-container-low text-on-surface flex items-center justify-center mb-2">
              <span className="material-symbols-outlined text-[20px]">security</span>
            </div>
            <div>
              <h4 className="font-bold text-xs text-on-surface">
                {language === 'fr' ? 'Audit Sécurité' : 'تدقيق الأمان'}
              </h4>
              <p className="text-[11px] text-on-surface-variant">
                {language === 'fr' ? 'Logs cryptés 256b' : 'سجلات مشفرة ٢٥٦ بت'}
              </p>
              <span className="text-[10px] text-primary font-bold">
                {language === 'fr' ? 'Zéro brèche' : 'صفر اختراق'}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* System Version & Footer */}
      <div className="mt-4 text-center text-xs text-on-surface-variant space-y-1">
        <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-surface-container text-on-surface-variant text-[10px] font-bold">
          <span className="material-symbols-outlined text-[14px] text-tertiary">lock</span>
          <span>
            {language === 'fr'
              ? 'Système Central RIMEDIC Mauritanie • v1.0.4'
              : 'النظام المركزي ريميديك موريتانيا • v1.0.4'}
          </span>
        </div>
        <p className="text-[10px] text-outline">
          {language === 'fr'
            ? 'Accès Restreint • Ministère de la Santé • Nouakchott'
            : 'وصول مقيد • وزارة الصحة • نواكشوط'}
        </p>
      </div>
    </div>
  );
};
