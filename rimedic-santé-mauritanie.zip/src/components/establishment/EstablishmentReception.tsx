import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export const EstablishmentReception: React.FC = () => {
  const {
    language,
    selectedEstablishment,
    lastScannedAppointment,
    lockEstablishmentSession,
    patient,
    showToast,
    isRtl
  } = useApp();

  const [flashlightOn, setFlashlightOn] = useState(false);
  const [manualCodeOpen, setManualCodeOpen] = useState(false);
  const [manualCodeInput, setManualCodeInput] = useState('');
  const [isEntryValidated, setIsEntryValidated] = useState(false);
  const [waitQueueCount, setWaitQueueCount] = useState(3);

  const apt = lastScannedAppointment;

  const activePatientName = apt?.patientName || (patient.firstName ? `${patient.firstName} ${patient.lastName}`.trim() : (language === 'fr' ? 'Fatimetou Mint Mohamed' : 'فاطمة منت محمد'));
  const activeInitials = apt?.patientName
    ? apt.patientName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
    : (patient.firstName ? `${patient.firstName.charAt(0)}${patient.lastName ? patient.lastName.charAt(0) : ''}` : 'FM');
  const activeNni = apt?.patientNni || (patient.nni ? `${patient.nni.slice(0, 4)} •••• ${patient.nni.slice(-2)}` : '8941 •••• 12');

  const handleValidateEntry = () => {
    setIsEntryValidated(true);
    setWaitQueueCount(prev => prev + 1);
    showToast(
      language === 'fr' ? 'Entrée validée !' : 'تم تأكيد الدخول !',
      language === 'fr'
        ? `Praticien prévenu. ${activePatientName} orienté(e) vers la salle de consultation.`
        : `تم إشعار الطبيب المعالج وتوجيه ${activePatientName} إلى قاعة الاستشارة.`
    );
  };

  const handlePrintTicket = () => {
    showToast(
      language === 'fr' ? 'Impression ticket #42' : 'طباعة التذكرة #٤٢',
      language === 'fr' ? 'Ticket d\'attente édité sur l\'imprimante thermique' : 'تم إصدار التذكرة للطابعة'
    );
  };

  const handleReportDelay = () => {
    showToast(
      language === 'fr' ? 'Retard consigné' : 'تسجيل تأخر',
      language === 'fr' ? 'Praticien informé d\'un délai d\'attente estimé à 10 min' : 'تم إشعار الطبيب بتأخر ١٠ دقائق',
      'warning'
    );
  };

  const handleManualCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualCodeInput.trim()) {
      setManualCodeOpen(false);
      showToast(
        language === 'fr' ? 'Code validé' : 'رمز مطابق',
        `Pass ${manualCodeInput.toUpperCase()} trouvé dans la base nationale`
      );
    }
  };

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Clinic Reception Security Status Bar */}
      <section className="px-4 pt-2">
        <div className="bg-sky-950 text-white px-3 py-1.5 rounded-2xl flex items-center justify-between text-xs border border-sky-500/30 shadow-xs">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="material-symbols-outlined text-sky-300 text-[16px] shrink-0">verified_user</span>
            <span className="text-[11px] font-bold text-sky-100 truncate">
              {language === 'fr' ? 'Session Guichet Active • Admission CNAM' : 'جلسة الشباك نشطة • التأمين الصحي'}
            </span>
          </div>
          <button
            onClick={lockEstablishmentSession}
            type="button"
            className="px-2.5 py-1 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer shrink-0"
            title={language === 'fr' ? "Verrouiller et fermer le guichet clinique" : "قفل وإغلاق شباك العيادة"}
          >
            <span className="material-symbols-outlined text-[13px]">lock</span>
            <span>{language === 'fr' ? 'Verrouiller' : 'قفل'}</span>
          </button>
        </div>
      </section>

      {/* Station Header / Guichet Context from Stitch */}
      <section className="px-4 pt-3 pb-2">
        <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-secondary-container flex items-center justify-center text-on-secondary-container shrink-0">
                <span className="material-symbols-outlined text-[22px]">local_hospital</span>
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                  <span className="text-[10px] text-primary uppercase font-bold tracking-wider">
                    {language === 'fr' ? 'Guichet Tiers-Payant Connecté' : 'شباك التأمين الصحي متصل'}
                  </span>
                </div>
                <h2 className="font-bold text-sm text-on-surface truncate">
                  {language === 'fr' ? (selectedEstablishment?.name || 'Clinique Ibn Sina') : (selectedEstablishment?.nameAr || 'عيادة ابن سينا')}
                </h2>
              </div>
            </div>
            <span className="px-2.5 py-1 bg-surface-container-high rounded-full text-xs font-bold text-on-surface-variant">
              {language === 'fr' ? 'Poste 04' : 'المكتب ٠٤'}
            </span>
          </div>

          <div className="mt-3 pt-2.5 border-t border-surface-container flex items-center justify-between text-xs text-on-surface-variant bg-surface-container-low rounded-xl p-2.5">
            <div className="flex items-center gap-2 min-w-0">
              <span className="material-symbols-outlined text-primary text-[18px]">badge</span>
              <span className="truncate">
                {language === 'fr' ? 'Opérateur : Mariem Cheikh (Secrétariat)' : 'الموظف : مريم الشيخ (أمانة الاستقبال)'}
              </span>
            </div>
            <span className="font-bold text-primary shrink-0">
              {language === 'fr' ? `File : ${waitQueueCount} en attente` : `قائمة الانتظار : ${waitQueueCount} في الانتظار`}
            </span>
          </div>
        </div>
      </section>

      {/* Interactive QR Scanner Viewport from Stitch */}
      <section className="px-4 my-1">
        <div className="relative bg-slate-950 text-white rounded-2xl overflow-hidden shadow-md flex flex-col items-center justify-center p-4 border border-slate-800">
          <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/40 to-black/90 pointer-events-none z-0"></div>
          <div className="absolute -top-12 -left-12 w-48 h-48 bg-primary/20 rounded-full blur-2xl pointer-events-none"></div>

          {/* Camera Feed Indicators */}
          <div className="relative z-10 w-full flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-white text-[11px] font-bold">
              <span className="w-2 h-2 rounded-full bg-error animate-ping"></span>
              <span>{language === 'fr' ? 'CAMÉRA HD 01 • ACTIVE' : 'كاميرا عالية الدقة ٠١ • نشطة'}</span>
            </div>

            <button
              onClick={() => {
                setFlashlightOn(!flashlightOn);
                showToast(
                  language === 'fr' ? 'Torche caméra' : 'إضاءة الكاميرا',
                  !flashlightOn ? (language === 'fr' ? 'Allumée' : 'مفعلة') : (language === 'fr' ? 'Éteinte' : 'معطلة')
                );
              }}
              className={`w-8 h-8 rounded-full backdrop-blur-md flex items-center justify-center transition-all ${
                flashlightOn ? 'bg-primary text-white' : 'bg-white/20 text-white hover:bg-white/30'
              }`}
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">
                {flashlightOn ? 'flashlight_off' : 'flashlight_on'}
              </span>
            </button>
          </div>

          {/* QR Reticle Viewfinder with Neon Corners & Laser */}
          <div className="relative z-10 w-52 h-52 flex items-center justify-center my-2">
            <div className="absolute top-0 left-0 w-7 h-7 border-t-4 border-l-4 border-primary-fixed rounded-tl-xl"></div>
            <div className="absolute top-0 right-0 w-7 h-7 border-t-4 border-r-4 border-primary-fixed rounded-tr-xl"></div>
            <div className="absolute bottom-0 left-0 w-7 h-7 border-b-4 border-l-4 border-primary-fixed rounded-bl-xl"></div>
            <div className="absolute bottom-0 right-0 w-7 h-7 border-b-4 border-r-4 border-primary-fixed rounded-br-xl"></div>

            {/* Laser Line */}
            <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-[#85f8c4] to-transparent shadow-[0_0_12px_#85f8c4] animate-pulse"></div>

            {/* Ghost QR Code Graphic */}
            <div className="opacity-25 flex flex-col items-center">
              <span className="material-symbols-outlined text-[90px] text-primary-fixed">qr_code_2</span>
            </div>
          </div>

          <p className="relative z-10 text-[11px] text-center text-slate-300 max-w-[280px]">
            {language === 'fr'
              ? "Pointez l'objectif vers le QR Pass RIMEDIC présenté sur l'application patient ou imprimé."
              : "وجه الكاميرا نحو رمز QR لتصريح ريميديك في تطبيق المريض أو التذكرة المطبوعة."}
          </p>

          {/* Scan Mode Buttons */}
          <div className="relative z-10 w-full grid grid-cols-2 gap-2 mt-3">
            <button
              onClick={() => setManualCodeOpen(true)}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-xs font-bold transition-all"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">keyboard</span>
              <span>{language === 'fr' ? 'Code Manuel' : 'إدخال يدوي'}</span>
            </button>
            <button
              onClick={() => {
                setIsEntryValidated(false);
                showToast(
                  language === 'fr' ? 'Scanner réinitialisé' : 'إعادة ضبط الماسح',
                  language === 'fr' ? 'Prêt pour le prochain patient' : 'جاهز للمريض التالي'
                );
              }}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 backdrop-blur-md text-white text-xs font-bold transition-all"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">cached</span>
              <span>{language === 'fr' ? 'Réinitialiser' : 'إعادة ضبط'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* Manual Code Modal */}
      {manualCodeOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleManualCodeSubmit}
            className="w-full max-w-sm bg-white rounded-2xl p-4 shadow-xl border border-surface-container flex flex-col gap-3"
          >
            <h3 className="font-bold text-sm text-on-surface">
              {language === 'fr' ? 'Saisir la référence Pass RIMEDIC' : 'أدخل رقم تصريح ريميديك'}
            </h3>
            <input
              type="text"
              value={manualCodeInput}
              onChange={e => setManualCodeInput(e.target.value)}
              placeholder={language === 'fr' ? 'Ex : SCAN-RIM-89412' : 'مثال : SCAN-RIM-89412'}
              className="w-full px-3 py-2.5 rounded-xl bg-surface-container-low font-mono font-bold text-sm border border-surface-container uppercase outline-none"
            />
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setManualCodeOpen(false)}
                className="py-2 bg-surface-container rounded-xl text-xs font-bold"
              >
                {language === 'fr' ? 'Annuler' : 'إلغاء'}
              </button>
              <button type="submit" className="py-2 bg-primary text-white rounded-xl text-xs font-bold">
                {language === 'fr' ? 'Valider' : 'تأكيد'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Live Scan Detection Result Card from Stitch */}
      <section className="px-4 my-2">
        <div className="bg-surface-container-lowest rounded-2xl p-4 shadow-sm border border-surface-container space-y-3">
          {/* Validation Header Badge */}
          <div className="flex items-center justify-between p-3 bg-secondary-container rounded-xl">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-on-primary">
                <span className="material-symbols-outlined text-[18px]">check_circle</span>
              </div>
              <div>
                <h3 className="font-bold text-xs text-on-secondary-container leading-tight">
                  {language === 'fr' ? 'Pass Valide • Rendez-vous Confirmé' : 'تصريح معتمد • الموعد مؤكد'}
                </h3>
                <p className="text-[10px] text-on-secondary-variant">
                  {language === 'fr' ? (
                    "Numérisé à l'instant (15:28)"
                  ) : (
                    <>
                      تم المسح الآن (<span dir="ltr" className="inline-block tabular-nums font-mono font-bold">15:28</span>)
                    </>
                  )}
                </p>
              </div>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-primary text-on-primary font-bold font-mono">
              {apt?.referenceNumber || 'SCAN-RIM-89412'}
            </span>
          </div>

          {/* Patient Identity */}
          <div className="flex items-start gap-3">
            <div className="w-14 h-14 rounded-2xl bg-secondary-container text-on-secondary-container flex items-center justify-center font-bold text-base shrink-0">
              {activeInitials}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h4 className="font-bold text-sm text-on-surface truncate">
                  {activePatientName}
                </h4>
                <span className="material-symbols-outlined text-primary text-[16px]">verified</span>
              </div>
              <p className="text-xs text-on-surface-variant flex items-center gap-1 mt-0.5">
                <span className="text-[10px] uppercase font-bold text-outline">NNI:</span>
                <span className="font-semibold text-on-surface">{activeNni}</span>
              </p>
              <p className="text-xs text-on-surface-variant flex items-center gap-1">
                <span className="material-symbols-outlined text-[14px]">call</span>
                <span>+222 45 25 •• 89 ({language === 'fr' ? 'Tevragh-Zeina' : 'تفرغ زينة'})</span>
              </p>
            </div>
          </div>

          {/* Appointment & Doctor Details */}
          <div className="p-3 bg-surface-container-low rounded-xl space-y-2 border border-surface-container">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-surface-container-highest flex items-center justify-center text-primary">
                  <span className="material-symbols-outlined text-[18px]">stethoscope</span>
                </div>
                <div>
                  <p className="font-bold text-xs text-on-surface">
                    {language === 'fr' ? (apt?.practitionerName || 'Dr Mohamed Ould Ahmed') : 'د. محمد ولد أحمد'}
                  </p>
                  <p className="text-[10px] text-on-surface-variant">
                    {language === 'fr' ? 'Spécialiste Orthodontie & Soins' : 'أخصائي تقويم الأسنان وجراحتها'}
                  </p>
                </div>
              </div>
              <span dir="ltr" className="px-2 py-0.5 rounded bg-secondary-fixed text-on-secondary-fixed text-[11px] font-bold tabular-nums font-mono">
                15:30
              </span>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-surface-container/60 text-xs text-on-surface-variant">
              <div className="flex items-center gap-1">
                <span className="material-symbols-outlined text-primary text-[15px]">meeting_room</span>
                <span>{language === 'fr' ? 'Cabinet 204 • 2ème étage' : 'العيادة ٢٠٤ • الطابق الثاني'}</span>
              </div>
              <span className="text-[11px] text-primary font-bold">
                {language === 'fr' ? 'Praticien disponible' : 'الطبيب متاح الآن'}
              </span>
            </div>
          </div>

          {/* Tiers-Payant & Insurance Coverage Breakdown from Stitch */}
          <div className="bg-surface-container rounded-xl p-3 space-y-2.5 border border-surface-container">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="material-symbols-outlined text-primary text-[18px]">health_and_safety</span>
                <span className="font-bold text-xs text-on-surface">
                  {language === 'fr' ? 'Couverture Tiers-Payant' : 'تغطية التأمين والدفع الجزئي'}
                </span>
              </div>
              <span className="px-2 py-0.2 rounded-full bg-primary-fixed text-on-primary-fixed text-[10px] font-bold">
                {language === 'fr' ? 'CNAM - 80% Validé' : 'كنام - ٨٠٪ معتمد'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-center pt-0.5">
              <div className="bg-white p-2 rounded-lg shadow-2xs">
                <p className="text-[10px] text-on-surface-variant">
                  {language === 'fr' ? 'Statut des droits' : 'حالة الحقوق'}
                </p>
                <p className="font-bold text-xs text-primary">
                  {language === 'fr' ? 'Droits Ouverts' : 'حقوق سارية'}
                </p>
              </div>
              <div className="bg-white p-2 rounded-lg shadow-2xs">
                <p className="text-[10px] text-on-surface-variant">
                  {language === 'fr' ? "Numéro d'immatriculation" : 'رقم التسجيل'}
                </p>
                <p className="font-bold text-xs text-on-surface">CNAM-2026-9901</p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 pt-0.5 text-on-surface-variant text-[11px]">
              <span className="material-symbols-outlined text-primary text-[15px]">check_box</span>
              <span>
                {language === 'fr' ? 'Carte vitale / CNAM physique vérifiée au guichet' : 'تم التحقق من بطاقة التأمين الأصلية عند الشباك'}
              </span>
            </div>
          </div>

          {/* Reception Staff Action Console */}
          <div className="space-y-2 pt-1">
            <button
              onClick={handleValidateEntry}
              className={`w-full h-12 rounded-xl text-white font-bold text-xs shadow-md flex items-center justify-center gap-2 transition-all active:scale-[0.99] ${
                isEntryValidated ? 'bg-secondary' : 'bg-primary hover:bg-primary-container'
              }`}
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">
                {isEntryValidated ? 'task_alt' : 'login'}
              </span>
              <span>
                {isEntryValidated
                  ? (language === 'fr' ? 'Entrée Validée • Praticien Notifié' : 'تم تسجيل الدخول • تم إشعار الطبيب')
                  : (language === 'fr' ? "Valider l'entrée & Notifier le praticien" : 'تأكيد الدخول وإشعار الطبيب')}
              </span>
            </button>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handlePrintTicket}
                className="py-2.5 px-3 rounded-xl bg-surface-container text-on-surface font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-surface-container-high transition-colors active:scale-95"
                type="button"
              >
                <span className="material-symbols-outlined text-primary text-[16px]">print</span>
                <span>{language === 'fr' ? "Ticket d'attente #42" : 'تذكرة الانتظار #٤٢'}</span>
              </button>
              <button
                onClick={handleReportDelay}
                className="py-2.5 px-3 rounded-xl bg-surface-container text-on-surface font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-surface-container-high transition-colors active:scale-95"
                type="button"
              >
                <span className="material-symbols-outlined text-tertiary text-[16px]">schedule</span>
                <span>{language === 'fr' ? 'Signaler retard' : 'إبلاغ عن تأخر'}</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
