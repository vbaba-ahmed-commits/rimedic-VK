import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { CityModal } from './components/common/CityModal';
import { Toast } from './components/common/Toast';

import { HomeScreen } from './components/patient/HomeScreen';
import { SpecialtiesScreen } from './components/patient/SpecialtiesScreen';
import { DoctorListScreen } from './components/patient/DoctorListScreen';
import { DoctorProfileScreen } from './components/patient/DoctorProfileScreen';
import { EstablishmentScreen } from './components/patient/EstablishmentScreen';
import { BookingConfirmationScreen } from './components/patient/BookingConfirmationScreen';
import { AppointmentsScreen } from './components/patient/AppointmentsScreen';
import { MapScreen } from './components/patient/MapScreen';
import { PatientProfileScreen } from './components/patient/PatientProfileScreen';

import { AuthLoginScreen } from './components/auth/AuthLoginScreen';
import { AuthOtpScreen } from './components/auth/AuthOtpScreen';
import { AuthRegisterScreen } from './components/auth/AuthRegisterScreen';

import { PractitionerDashboard } from './components/practitioner/PractitionerDashboard';
import { PractitionerAgenda } from './components/practitioner/PractitionerAgenda';
import { PractitionerProfileScreen } from './components/practitioner/PractitionerProfileScreen';
import { EstablishmentReception } from './components/establishment/EstablishmentReception';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { PractitionerSecurityGate } from './components/auth/PractitionerSecurityGate';
import { EstablishmentSecurityGate } from './components/auth/EstablishmentSecurityGate';

const AppContent: React.FC = () => {
  const { currentScreen, isRtl, practitionerUnlocked, establishmentUnlocked, navigateTo } = useApp();

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return <HomeScreen />;
      case 'specialties':
        return <SpecialtiesScreen />;
      case 'doctor-list':
        return <DoctorListScreen />;
      case 'doctor-profile':
        return <DoctorProfileScreen />;
      case 'establishment-detail':
        return <EstablishmentScreen />;
      case 'booking-confirm':
        return <BookingConfirmationScreen />;
      case 'appointments':
        return <AppointmentsScreen />;
      case 'map':
        return <MapScreen />;
      case 'profile':
        return <PatientProfileScreen />;
      case 'auth-login':
        return <AuthLoginScreen />;
      case 'auth-otp':
        return <AuthOtpScreen />;
      case 'auth-register':
        return <AuthRegisterScreen />;
      case 'practitioner-dashboard':
        return practitionerUnlocked ? (
          <PractitionerDashboard />
        ) : (
          <PractitionerSecurityGate onSuccess={() => navigateTo('practitioner-dashboard')} />
        );
      case 'practitioner-agenda':
        return practitionerUnlocked ? (
          <PractitionerAgenda />
        ) : (
          <PractitionerSecurityGate onSuccess={() => navigateTo('practitioner-agenda')} />
        );
      case 'practitioner-profile':
        return practitionerUnlocked ? (
          <PractitionerProfileScreen />
        ) : (
          <PractitionerSecurityGate onSuccess={() => navigateTo('practitioner-profile')} />
        );
      case 'establishment-desk':
        return establishmentUnlocked ? (
          <EstablishmentReception />
        ) : (
          <EstablishmentSecurityGate onSuccess={() => navigateTo('establishment-desk')} />
        );
      case 'admin-dashboard':
        return <HomeScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div
      className={`min-h-screen bg-[#faf8ff] text-[#131b2e] flex flex-col font-sans transition-colors ${
        isRtl ? 'font-arabic' : ''
      }`}
    >
      {/* Top Fixed Header */}
      <Header />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-md mx-auto pt-16 bg-[#faf8ff] flex flex-col relative shadow-[0_0_50px_rgba(0,105,72,0.03)]">
        {renderScreen()}
      </main>

      {/* Persistent Bottom Navigation */}
      <BottomNav />

      {/* Modals & Overlays */}
      <CityModal />
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
