/**
 * Complete French & Arabic Dictionary for RIMEDIC Mauritanie
 */

export const translations = {
  fr: {
    appName: 'RIMEDIC',
    appSubtitle: 'Santé Mauritanie',
    demoDisclaimer: 'Données de démonstration',
    demoNotice: 'Données de démonstration officielle — Simulation de prototype',
    switchLanguage: 'عربي',
    
    // Nav
    navHome: 'Accueil',
    navSpecialties: 'Spécialités',
    navMap: 'Carte',
    navAppointments: 'Rendez-vous',
    navProfile: 'Profil',
    
    // Roles
    rolePatient: 'Patient',
    rolePractitioner: 'Praticien',
    roleEstablishment: 'Établissement',
    roleAdmin: 'Supervision',
    switchRole: 'Changer d\'espace',

    // Home
    greeting: 'Bonjour',
    greetingSubtitle: 'Prenez soin de votre santé aujourd\'hui',
    searchPlaceholder: 'Praticien, spécialité, établissement...',
    filtersBtn: 'Filtres',
    quickSpecialties: 'Spécialités',
    quickSpecialtiesSub: '25 spécialités',
    quickEstablishments: 'Établissements',
    quickEstablishmentsSub: '142 structures',
    quickMap: 'Carte santé',
    quickMapSub: 'À proximité',
    popularSpecialties: 'Spécialités populaires',
    popularSubtitle: 'Praticiens disponibles cette semaine',
    viewAll: 'Toutes (25)',
    myNextAppointment: 'Mes prochains rendez-vous',
    noAppointmentTitle: 'Vous n\'avez aucun rendez-vous à venir',
    noAppointmentDesc: 'Consultez un praticien ou planifiez dès maintenant votre contrôle de santé de routine.',
    bookAppointmentBtn: 'Prendre un rendez-vous',
    partnerCnamTitle: 'Guide & Informations CNAM & CNASS',
    officialBadge: 'Guide Santé',
    partnerCnamDesc: 'Consultez les informations de prise en charge et le tiers-payant conventionné dans les cliniques et hôpitaux de Mauritanie.',
    emergencyTitle: 'Urgence Santé Mauritanie',
    emergencySubtitle: 'SAMU & Premiers secours 24h/7',
    footerTrust: 'Plateforme médicale de confiance • République Islamique de Mauritanie',

    // Specialties
    allSpecialtiesTitle: 'Toutes les spécialités',
    allSpecialtiesDesc: 'Trouvez le médecin spécialiste adapté à vos besoins partout en Mauritanie.',
    searchSpecialtyPlaceholder: 'Rechercher une spécialité (ex: Cardiologie, Dentiste...)',
    categoryAll: 'Toutes',
    categoryDental: 'Soins dentaires',
    categoryMotherChild: 'Pédiatrie & Mère',
    categoryConsultation: 'Consultation',
    categorySurgery: 'Chirurgie',
    certifiedDoctorsBanner: 'Praticiens agréés & conventions CNAM',
    certifiedDoctorsSub: 'Nouakchott, Nouadhibou, Rosso, Kiffa',
    subspecialtiesAvailable: 'Sous-spécialités disponibles :',
    exploreAllDentists: 'Explorer tous les dentistes',
    needMedicalGuidance: 'Besoin d\'orientation médicale ?',
    medicalGuidanceDesc: 'Nos conseillers santé RIMEDIC vous guident',
    callBtn: 'Appeler',

    // Doctor list
    orthodontistsNouakchott: 'Orthodontistes à Nouakchott',
    practitionersListed: 'praticiens répertoriés',
    searchDoctorPlaceholder: 'Nom du praticien, clinique ou quartier...',
    conventionedCnam: 'Conventionné CNAM & CNASS',
    availableToday: 'Dispo aujourd\'hui',
    availableTomorrow: 'Dispo demain',
    consultationFee: 'Consultation',
    nextSlotLabel: 'Prochain créneau :',
    viewProfileAndTariffs: 'Profil & Infos',
    takeAppointment: 'Prendre RDV',

    // Doctor Profile
    consultationReasonTitle: 'Motif de consultation',
    mandatory: 'Obligatoire',
    reason1: 'Première consultation orthodontie',
    reason1Desc: 'Bilan initial, prise d\'empreintes • 45 min',
    reason2: 'Contrôle appareil dentaire',
    reason2Desc: 'Activation bague & suivi • 30 min',
    reason3: 'Urgence bague ou arc détaché',
    reason3Desc: 'Réajustement rapide sans douleur • 20 min',
    morning: 'Matinée',
    afternoon: 'Après-midi',
    aboutCabinetAndInsurance: 'À propos du cabinet & Prise en charge',
    consultationLanguages: 'Langues de consultation',
    accessAndParking: 'Accès & Localisation',
    requiredDocuments: 'Pièces à présenter au secrétariat',
    continueToConfirmation: 'Continuer vers la confirmation',

    // Confirmation
    appointmentConfirmedTitle: 'Rendez-vous confirmé !',
    appointmentConfirmedDesc: 'Votre consultation a été enregistrée auprès de l\'établissement.',
    dossierNumber: 'Dossier N°',
    passConsultation: 'Pass Consultation',
    qrScanInstructions: 'Présentez ce QR code à l\'accueil de la clinique',
    practitionerLabel: 'Praticien',
    establishmentLabel: 'Établissement & Lieu',
    dateTimeLabel: 'Date & Heure',
    patientLabel: 'Patient',
    consultationAmount: 'Montant consultation',
    verifiedFile: 'Dossier vérifié',
    arrivalInstructionsTitle: 'Consignes d\'arrivée',
    punctualityTitle: 'Ponctualité',
    punctualityDesc: 'Arrivez 10 minutes avant l\'heure pour formaliser votre accueil au guichet.',
    requiredDocsDesc: 'Présentez votre pièce d\'identité officielle et votre carte CNAM / CNASS valide.',
    addToCalendar: 'Ajouter au calendrier',
    sharePass: 'Partager le pass',
    viewInMyAppointments: 'Voir dans Mes Rendez-vous',
    freeCancellationNotice: 'Modifier ou annuler le rendez-vous sans frais jusqu\'à 4h avant',

    // My Appointments
    myAppointmentsTitle: 'Mes Rendez-vous',
    myAppointmentsSubtitle: 'Gérez vos consultations et votre historique médical',
    newBtn: '+ Nouveau',
    tabUpcoming: 'À venir',
    tabPast: 'Passés',
    tabCancelled: 'Annulés',
    in3Days: 'Confirmé · Dans 3 jours',
    showQrCode: 'Afficher le QR code d\'accès',
    hideQrCode: 'Masquer le QR code',
    directionsBtn: 'Itinéraire',
    rescheduleBtn: 'Gérer / Déplacer',
    recentHistory: 'Historique récent',
    honoredStatus: 'Honoré',
    retakeAppointment: 'Reprendre RDV',
    needHelpWithAppointment: 'Besoin d\'aide avec un rendez-vous ?',
    needHelpDesc: 'Contactez notre assistance dédiée ou consultez le guide des démarches CNAM / CNASS.',
    supportBtn: 'Support RIMEDIC',
    guideCnamBtn: 'Guide CNAM',

    // Map
    healthTerritory: 'Territoire sanitaire',
    filterAllFacilities: 'Tous',
    filterHospitals: 'Hôpitaux',
    filterClinics: 'Cliniques privées',
    filterDental: 'Cabinets dentaires',
    filterLabs: 'Laboratoires',
    filterImaging: 'Centres d\'imagerie',
    specialistsOnDuty: 'Spécialistes en service',
    itineraryAndInfo: 'Itinéraire & Infos',

    // Profile
    activeDossier: 'Dossier Médical RIMEDIC actif',
    editInfo: 'Modifier les infos',
    compulsoryRegime: 'Régime Obligatoire & Prise en charge',
    cnamMauritanie: 'CNAM Mauritanie',
    matriculationNo: 'N° IMMATRICULATION',
    activeTiersPayant: 'Tiers-payant actif : Consultations & Radiologie',
    updateCard: 'Mettre à jour / Carte CNASS',
    passReception: 'Pass Accueil',
    digitalBadge: 'Badge numérique QR',
    documentsTitle: 'Documents',
    documentsSubtitle: 'Analyses & ordonnances',
    personalInfo: 'Informations personnelles',
    personalInfoDesc: 'État civil, contact d\'urgence, ville',
    insuranceAndTiersPayant: 'Assurance & Tiers-payant',
    appointmentHistoryMenu: 'Historique des rendez-vous',
    smsReminders: 'Rappels de RDV & SMS',
    displayLanguage: 'Langue d\'affichage',
    securityAndPrivacy: 'Sécurité & Confidentialité',
    rimedicSupport: 'Aide & Assistance RIMEDIC',
    logoutBtn: 'Se déconnecter du compte',

    // Auth & OTP
    welcomeTitle: 'Bienvenue sur RIMEDIC',
    welcomeSubtitle: 'Connectez-vous avec votre numéro de téléphone mauritanien pour accéder à vos rendez-vous et vos dossiers médicaux.',
    espacePatient: 'Espace Patient',
    espacePro: 'Professionnel',
    phoneNumberLabel: 'Numéro de téléphone',
    keepSessionActive: 'Garder ma session active sur cet appareil',
    receiveVerificationCode: 'Recevoir le code de vérification',
    noAccountYet: 'Vous n\'avez pas encore de compte RIMEDIC ?',
    createPatientAccount: 'Créer un compte patient',
    immediateHelp: 'Urgences médicales ?',
    greenNumber: 'SAMU National Mauritanie (101)',
    securityVerificationTitle: 'Vérification de sécurité',
    securityVerificationSubtitle: 'Saisissez le code à 6 chiffres envoyé par SMS au numéro :',
    resendCodeIn: 'Renvoyer un nouveau code dans',
    resendSms: 'Renvoyer par SMS',
    validateAndContinue: 'Valider et continuer',

    // Registration
    stepPhone: 'Téléphone',
    stepIdentity: 'Identité',
    stepFinal: 'Finalisation',
    firstNameLabel: 'Prénom',
    lastNameLabel: 'Nom de famille',
    birthDateLabel: 'Date de naissance',
    genderLabel: 'Sexe',
    man: 'Homme',
    woman: 'Femme',
    nniLabel: 'Numéro National d\'Identification (NNI)',
    cityAndResidence: 'Wilaya & Ville de résidence',
    insuranceRegimeTitle: 'Régime d\'assurance & Tiers-payant',
    insuranceOptionCnam: 'CNAM Mauritanie',
    insuranceOptionCnass: 'CNASS',
    insuranceOptionPrivate: 'Assurance privée / Mutuelle',
    insuranceOptionNone: 'Aucune assurance',
    cnamMatriculationLabel: 'Numéro d\'immatriculation CNAM',
    instantCoverage80: 'Prise en charge à 80% instantanée',
    termsAcceptance: 'J\'accepte les conditions d\'utilisation de la plateforme RIMEDIC et certifie l\'exactitude de mes informations médicales et d\'assurance.',
    createAccountSubmit: 'Créer mon compte patient',

    // Establishment Desk
    receptionDeskTitle: 'Détail Rendez Vous',
    connectedGuichet: 'Guichet Tiers-Payant Connecté',
    cameraFeedActive: 'Caméra HD 01 • Active',
    qrReticleHelp: 'Pointez l\'objectif vers le QR Pass RIMEDIC présenté sur l\'application patient ou imprimé.',
    manualCode: 'Code Manuel',
    resetScanner: 'Réinitialiser',
    passValidTitle: 'Pass Valide • Rendez-vous Confirmé',
    scannedJustNow: 'Numérisé à l\'instant (15:28)',
    tiersPayantCoverageTitle: 'Couverture Tiers-Payant',
    cnamValidated80: 'CNAM - 80% Validé',
    cnamCoverPart: 'Prise en charge CNAM',
    patientTicketPart: 'Ticket modérateur patient',
    vitalCardPhysicalVerified: 'Carte vitale / CNAM physique vérifiée au guichet',
    validateEntryAndNotify: 'Valider l\'entrée & Notifier le praticien',
    queueTicket42: 'Ticket d\'attente #42',
    reportDelay: 'Signaler retard',

    // Practitioner Space
    consultationStatus: 'En consultation',
    onPauseStatus: 'En pause',
    rdvPlanned: 'RDV prévus',
    waitingRoomCount: 'Salle d\'attente',
    patientsArrived: 'Patients arrivés',
    estimatedFees: 'Consultations',
    punctualityRate: 'Ponctualité',
    scannerPassBtn: 'Scanner Pass',
    pauseBtn: 'Pause',
    nextPatientInQueue: 'Prochain patient en file active',
    startConsultationBtn: 'Démarrer consultation',
    dossierBtn: 'Dossier',
    afternoonPlanning: 'Planning après-midi',
    pendingRequests: 'Demandes en attente',
    acceptBtn: 'Accepter',
    otherSlotBtn: 'Autre créneau',
    consultationLoad: 'Charge de la consultation',
    slotsOpenForBooking: 'créneaux encore ouverts à la réservation en ligne',
    daySchedule: 'Planning de la journée',
    gmtTimezone: 'FUSEAU GMT (NOUAKCHOTT)',
    lunchAndPrayerBreak: 'PAUSE DÉJEUNER & PRIÈRE',
    lunchBreakDesc: 'Non réservable • Fermeture temporaire du cabinet',
    smsRemindersAutomatic: 'Rappels SMS automatiques',
    smsRemindersOperators: 'Notification 24h avant aux opérateurs (Mauritel, Mattel, Chinguitel)',
    proSyncActive: 'Synchronisation RIMEDIC Pro active',

    // Admin Space
    nationalSupervision: 'Supervision Nationale',
    ministryHeader: 'Ministère de la Santé / RIMEDIC',
    principalAdmin: 'Admin Principal (Nouakchott)',
    telecomNodes: 'Nœuds Opérateurs: Mauritel • Mattel • Chinguitel',
    operationalStatus: 'Opérationnel',
    monitoredTerritories: 'Territoires sous écoute',
    allMauritania: 'Toute la Mauritanie',
    healthCentersKpi: 'Centres de Santé',
    registeredDoctorsKpi: 'Médecins Inscrits',
    consultationsMonthKpi: 'Consultations Mois',
    tiersPayantRateKpi: 'Tiers-payant Assuré',
    establishmentValidationTitle: 'Validation des Établissements',
    approvalPending: 'Agrément en attente',
    validateCenterBtn: 'Valider le centre',
    rejectBtn: 'Rejeter',
    registerNewCenterBtn: '+ Répertorier un nouvel établissement',
    governanceAndSettings: 'Gouvernance & Paramètres',
    networkLevel: 'Niveau Réseau',
    wilayasAndCities: 'Wilayas & Villes',
    otpGateway: 'Passerelle OTP',
    securityAudit: 'Audit Sécurité',
  },
  ar: {
    appName: 'ريميديك',
    appSubtitle: 'صحة موريتانيا',
    demoDisclaimer: 'بيانات تجريبية توضيحية',
    demoNotice: 'بيانات تجريبية توضيحية رسمية — نموذج أولي قيد التطوير',
    switchLanguage: 'FR',

    // Nav
    navHome: 'الرئيسية',
    navSpecialties: 'التخصصات',
    navMap: 'الخريطة',
    navAppointments: 'المواعيد',
    navProfile: 'حسابي',

    // Roles
    rolePatient: 'المريض',
    rolePractitioner: 'الطبيب',
    roleEstablishment: 'المركز الصحي',
    roleAdmin: 'الإشراف الوطني',
    switchRole: 'تبديل الواجهة',

    // Home
    greeting: 'مرحباً',
    greetingSubtitle: 'اعتنِ بصحتك وصحة أسرتك اليوم',
    searchPlaceholder: 'ابحث عن طبيب، تخصص، أو منشأة صحية...',
    filtersBtn: 'تصفية',
    quickSpecialties: 'التخصصات',
    quickSpecialtiesSub: '٢٥ تخصصاً طبياً',
    quickEstablishments: 'المنشآت',
    quickEstablishmentsSub: '١٤٢ منشأة صحية',
    quickMap: 'خريطة الصحة',
    quickMapSub: 'الأقرب إليك',
    popularSpecialties: 'التخصصات الأكثر طلباً',
    popularSubtitle: 'أطباء متاحون للحجز هذا الأسبوع',
    viewAll: 'عرض الكل (٢٥)',
    myNextAppointment: 'مواعيدي القادمة',
    noAppointmentTitle: 'ليس لديك أي مواعيد قادمة',
    noAppointmentDesc: 'استشر طبيباً معتمداً أو احجز فحصاً صحياً دورياً الآن بكل سهولة.',
    bookAppointmentBtn: 'حجز موعد طبي',
    partnerCnamTitle: 'دليل ومعلومات التأمين الصحي CNAM و CNASS',
    officialBadge: 'دليل التأمين',
    partnerCnamDesc: 'اطلع على نسب التغطية والتأمين الصحي والتسديد الجزئي في المنشآت الطبية المعتمدة في موريتانيا.',
    emergencyTitle: 'طوارئ الصحة الموريتانية',
    emergencySubtitle: 'الإسعاف والنجدة الطبية ٢٤/٧',
    footerTrust: 'منصة طبية موثوقة • الجمهورية الإسلامية الموريتانية',

    // Specialties
    allSpecialtiesTitle: 'كافة التخصصات الطبية',
    allSpecialtiesDesc: 'اعثر على الطبيب الأخصائي المناسب لاحتياجاتك في جميع ولايات موريتانيا.',
    searchSpecialtyPlaceholder: 'ابحث عن تخصص (مثل: قلب، أسنان، أطفال...)',
    categoryAll: 'الكل',
    categoryDental: 'طب الأسنان',
    categoryMotherChild: 'الأطفال والأمومة',
    categoryConsultation: 'استشارات عامة',
    categorySurgery: 'الجراحة',
    certifiedDoctorsBanner: 'أطباء معتمدون ومغطون بتأمين كنام',
    certifiedDoctorsSub: 'نواكشوط، نواذيبو، روصو، كيفة',
    subspecialtiesAvailable: 'التخصصات الدقيقة المتوفرة:',
    exploreAllDentists: 'استعراض جميع أطباء الأسنان',
    needMedicalGuidance: 'هل تحتاج إلى توجيه طبي؟',
    medicalGuidanceDesc: 'مرشدو ريميديك الصحيون في خدمتك',
    callBtn: 'اتصال',

    // Doctor list
    orthodontistsNouakchott: 'أخصائيو تقويم الأسنان في نواكشوط',
    practitionersListed: 'أطباء مسجلون',
    searchDoctorPlaceholder: 'اسم الطبيب، المصحة أو الحي...',
    conventionedCnam: 'معتمد لدى CNAM و CNASS',
    availableToday: 'متاح اليوم',
    availableTomorrow: 'متاح غداً',
    consultationFee: 'استشارة طبية',
    nextSlotLabel: 'الموعد المتاح التالي:',
    viewProfileAndTariffs: 'الملف والمعلومات',
    takeAppointment: 'حجز موعد',

    // Doctor Profile
    consultationReasonTitle: 'سبب الاستشارة',
    mandatory: 'إجباري',
    reason1: 'أول كشف تقويم أسنان',
    reason1Desc: 'فحص أولي، أخذ قياسات وطبعات • ٤٥ دقيقة',
    reason2: 'متابعة وضبط جهاز التقويم',
    reason2Desc: 'تفعيل وتعديل أسلاك التقويم • ٣٠ دقيقة',
    reason3: 'حالة مستعجلة لسلك أو حاصرة مفكوكة',
    reason3Desc: 'تعديل سريع دون ألم • ٢٠ دقيقة',
    morning: 'الفترة الصباحية',
    afternoon: 'فترة ما بعد الظهر',
    aboutCabinetAndInsurance: 'عن العيادة والتغطية التأمينية',
    consultationLanguages: 'لغات الاستشارة',
    accessAndParking: 'الموقع والمواقف',
    requiredDocuments: 'الوثائق المطلوبة عند الوصول',
    continueToConfirmation: 'المتابعة لتأكيد الحجز',

    // Confirmation
    appointmentConfirmedTitle: 'تم تأكيد موعدك بنجاح!',
    appointmentConfirmedDesc: 'تم تسجيل استشارتك رسمياً لدى المؤسسة الصحية.',
    dossierNumber: 'رقم الملف',
    passConsultation: 'تصريح الاستشارة الطبي',
    qrScanInstructions: 'أظهر رمز الاستجابة السريعة (QR) عند مكتب استقبال العيادة',
    practitionerLabel: 'الطبيب المعالج',
    establishmentLabel: 'المنشأة والمكان',
    dateTimeLabel: 'التاريخ والتوقيت',
    patientLabel: 'المريض',
    consultationAmount: 'رسوم الاستشارة',
    verifiedFile: 'ملف معتمد ومتحقق منه',
    arrivalInstructionsTitle: 'تعليمات الحضور',
    punctualityTitle: 'الالتزام بالموعد',
    punctualityDesc: 'يرجى الحضور قبل الموعد بـ ١٠ دقائق لإنهاء إجراءات التسجيل في شباك الاستقبال.',
    requiredDocsDesc: 'أحضر بطاقة التعريف الوطنية وبطاقة التأمين كنام أو كناص سارية المفعول.',
    addToCalendar: 'إضافة إلى التقويم',
    sharePass: 'مشاركة التصريح',
    viewInMyAppointments: 'عرض في مواعيدي',
    freeCancellationNotice: 'يمكنك تعديل أو إلغاء الموعد مجاناً حتى ٤ ساعات قبل توقيته',

    // My Appointments
    myAppointmentsTitle: 'مواعيدي الطبية',
    myAppointmentsSubtitle: 'إدارة استشاراتك وسجلك الطبي',
    newBtn: '+ موعد جديد',
    tabUpcoming: 'القادمة',
    tabPast: 'السابقة',
    tabCancelled: 'الملغاة',
    in3Days: 'مؤكد · بعد ٣ أيام',
    showQrCode: 'عرض رمز الدخول (QR)',
    hideQrCode: 'إخفاء رمز الدخول (QR)',
    directionsBtn: 'المسار',
    rescheduleBtn: 'إدارة / تغيير الموعد',
    recentHistory: 'السجل الحديث',
    honoredStatus: 'تمت الزيارة',
    retakeAppointment: 'إعادة الحجز',
    needHelpWithAppointment: 'هل تحتاج مساعدة بخصوص موعدك؟',
    needHelpDesc: 'تواصل مع فريق الدعم المخصص أو اطلع على دليل استرجاع مصاريف التأمين CNAM / CNASS.',
    supportBtn: 'دعم ريميديك',
    guideCnamBtn: 'دليل كنام',

    // Map
    healthTerritory: 'النطاق الصحي',
    filterAllFacilities: 'الكل',
    filterHospitals: 'مستشفيات حكومية',
    filterClinics: 'عيادات ومصحات خاصة',
    filterDental: 'عيادات أسنان',
    filterLabs: 'مختبرات تحاليل',
    filterImaging: 'مراكز أشعة وسكانير',
    specialistsOnDuty: 'أخصائياً في الخدمة',
    itineraryAndInfo: 'المسار والمعلومات',

    // Profile
    activeDossier: 'الملف الطبي في ريميديك نشط',
    editInfo: 'تعديل البيانات',
    compulsoryRegime: 'نظام التأمين الإجباري والتغطية',
    cnamMauritanie: 'الصندوق الوطني للتأمين الصحي (CNAM)',
    matriculationNo: 'رقم التسجيل',
    activeTiersPayant: 'دفع جزئي نشط : الاستشارات والأشعة',
    updateCard: 'تحديث / بطاقة كناص',
    passReception: 'بطاقة الدخول',
    digitalBadge: 'بطاقة رقمية مشفرة',
    documentsTitle: 'الوثائق الطبية',
    documentsSubtitle: 'تحاليل ووصفات سابقة',
    personalInfo: 'المعلومات الشخصية',
    personalInfoDesc: 'الحالة المدنية، جهة الاتصال، المدينة',
    insuranceAndTiersPayant: 'التأمين والدفع الجزئي',
    appointmentHistoryMenu: 'سجل المواعيد الطبية',
    smsReminders: 'تذكير المواعيد عبر الرسائل',
    displayLanguage: 'لغة العرض',
    securityAndPrivacy: 'الأمان والخصوصية',
    rimedicSupport: 'المساعدة ودعم ريميديك',
    logoutBtn: 'تسجيل الخروج من الحساب',

    // Auth & OTP
    welcomeTitle: 'مرحباً بك في ريميديك',
    welcomeSubtitle: 'سجّل دخولك برقم هاتفك الموريتاني للوصول إلى مواعيدك وسجلاتك الصحية بأمان.',
    espacePatient: 'فضاء المريض',
    espacePro: 'فضاء المهنيين',
    phoneNumberLabel: 'رقم الهاتف',
    keepSessionActive: 'إبقاء الجلسة نشطة على هذا الجهاز',
    receiveVerificationCode: 'استلام رمز التحقق',
    noAccountYet: 'ليس لديك حساب على ريميديك بعد؟',
    createPatientAccount: 'إنشاء حساب مريض جديد',
    immediateHelp: 'طوارئ طبية؟',
    greenNumber: 'الإسعاف الوطني الموريتاني (101)',
    securityVerificationTitle: 'التحقق الأمني',
    securityVerificationSubtitle: 'أدخل الرمز المكون من 6 أرقام المرسل عبر رسالة قصيرة إلى:',
    resendCodeIn: 'إعادة إرسال الرمز خلال',
    resendSms: 'إعادة الإرسال عبر SMS',
    validateAndContinue: 'تأكيد ومتابعة',

    // Registration
    stepPhone: 'الهاتف',
    stepIdentity: 'الهوية',
    stepFinal: 'التأكيد',
    firstNameLabel: 'الاسم الشخصي',
    lastNameLabel: 'الاسم العائلي',
    birthDateLabel: 'تاريخ الميلاد',
    genderLabel: 'الجنس',
    man: 'ذكر',
    woman: 'أنثى',
    nniLabel: 'الرقم الوطني للتعريف (NNI)',
    cityAndResidence: 'الولاية ومدينة الإقامة',
    insuranceRegimeTitle: 'نظام التأمين الصحي',
    insuranceOptionCnam: 'الصندوق الوطني للتأمين الصحي (CNAM)',
    insuranceOptionCnass: 'الصندوق الوطني للتضامن الصحي (CNASS)',
    insuranceOptionPrivate: 'تأمين خاص / تعاضدية',
    insuranceOptionNone: 'بدون تأمين (دفع مباشر)',
    cnamMatriculationLabel: 'رقم التسجيل في كنام',
    instantCoverage80: 'تغطية فورية حتى 80%',
    termsAcceptance: 'أوافق على شروط استخدام منصة ريميديك وأشهد على صحة معلوماتي الطبية والتأمينية.',
    createAccountSubmit: 'إنشاء حساب المريض',

    // Establishment Desk
    receptionDeskTitle: 'تفاصيل الموعد وشباك الاستقبال',
    connectedGuichet: 'شباك التأمين الصحي المتصل',
    cameraFeedActive: 'كاميرا المراقبة HD 01 • نشطة',
    qrReticleHelp: 'وجّه عدسة الكاميرا نحو رمز QR لتصريح ريميديك المعروض على هاتف المريض.',
    manualCode: 'إدخال الرمز يدوياً',
    resetScanner: 'إعادة ضبط الماسح',
    passValidTitle: 'تصريح صالح • الموعد مؤكد',
    scannedJustNow: 'تم المسح الضوئي للتو (\u200E15:28\u200E)',
    tiersPayantCoverageTitle: 'تغطية الدفع الجزئي',
    cnamValidated80: 'كنام - تم التحقق بنسبة 80%',
    cnamCoverPart: 'مساهمة التأمين CNAM',
    patientTicketPart: 'المبلغ المتبقي على المريض',
    vitalCardPhysicalVerified: 'تمت مطابقة بطاقة التأمين الأصلية عند الشباك',
    validateEntryAndNotify: 'تأكيد الدخول وإشعار الطبيب المعالج',
    queueTicket42: 'تذكرة الانتظار #٤٢',
    reportDelay: 'تسجيل تأخر',

    // Practitioner Space
    consultationStatus: 'في جلسة كشف',
    onPauseStatus: 'في استراحة',
    rdvPlanned: 'المواعيد المقررة',
    waitingRoomCount: 'قاعة الانتظار',
    patientsArrived: 'مرضى وصلوا',
    estimatedFees: 'الاستشارات',
    punctualityRate: 'دقة المواعيد',
    scannerPassBtn: 'مسح تصريح مريض',
    pauseBtn: 'استراحة',
    nextPatientInQueue: 'المريض التالي في قائمة الانتظار',
    startConsultationBtn: 'بدء الاستشارة الطبية',
    dossierBtn: 'الملف الطبي',
    afternoonPlanning: 'جدول ما بعد الظهر',
    pendingRequests: 'طلبات قيد المراجعة',
    acceptBtn: 'قبول',
    otherSlotBtn: 'موعد بديل',
    consultationLoad: 'نسبة إشغال العيادة',
    slotsOpenForBooking: 'مواعيد شاغرة ومتاحة للحجز الإلكتروني',
    daySchedule: 'جدول مواعيد اليوم',
    gmtTimezone: 'توقيت غرينتش (نواكشوط)',
    lunchAndPrayerBreak: 'استراحة الغداء والصلاة',
    lunchBreakDesc: 'غير قابل للحجز • إغلاق مؤقت للعيادة',
    smsRemindersAutomatic: 'رسائل التذكير التلقائية (SMS)',
    smsRemindersOperators: 'إشعار قبل ٢٤ ساعة لشبكات (موريتل، ماتال، شنقيتل)',
    proSyncActive: 'مزامنة ريميديك برو نشطة ومحدثة',

    // Admin Space
    nationalSupervision: 'الإشراف الصحي الوطني',
    ministryHeader: 'وزارة الصحة / ريميديك',
    principalAdmin: 'المشرف العام (نواكشوط)',
    telecomNodes: 'عقد الاتصال: موريتل • ماتال • شنقيتل',
    operationalStatus: 'يعمل بكفاءة',
    monitoredTerritories: 'الولايات المشمولة بالتغطية',
    allMauritania: 'كافة التراب الموريتاني',
    healthCentersKpi: 'المراكز الصحية',
    registeredDoctorsKpi: 'الأطباء المسجلون',
    consultationsMonthKpi: 'استشارات الشهر',
    tiersPayantRateKpi: 'نسبة الدفع المباشر والتأمين',
    establishmentValidationTitle: 'اعتماد المنشآت الصحية',
    approvalPending: 'اعتماد قيد المراجعة',
    validateCenterBtn: 'اعتماد المركز',
    rejectBtn: 'رفض',
    registerNewCenterBtn: '+ تسجيل منشأة صحية جديدة',
    governanceAndSettings: 'الحوكمة والإعدادات',
    networkLevel: 'مستوى الشبكة',
    wilayasAndCities: 'الولايات والمدن',
    otpGateway: 'بوابة رسائل التحقق (OTP)',
    securityAudit: 'سجلات الأمان والرقابة',
  }
};

export const NEIGHBORHOOD_TRANSLATIONS: Record<string, string> = {
  'Tevragh Zeina': 'تفرغ زينة',
  'Tevragh-Zeina': 'تفرغ زينة',
  'Ksar': 'لكصر',
  'Arafat': 'عرفات',
  'Dar Naïm': 'دار النعيم',
  'Dar Naim': 'دار النعيم',
  'Sebkha': 'السبخة',
  'Toujounine': 'توجنين',
  'El Mina': 'الميناء',
  'Teyarett': 'تيارت',
  'Riyadh': 'الرياض',
  'Nouakchott': 'نواكشوط',
  'Nouadhibou': 'نواذيبو',
  'Rosso': 'روصو',
  'Kiffa': 'كيفة',
  'Atar': 'أطار',
  'Kaédi': 'كيهيدي',
};

export const translateNeighborhood = (name: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (lang !== 'ar') return name;
  return NEIGHBORHOOD_TRANSLATIONS[name] || name;
};

export const SUBSPECIALTY_TRANSLATIONS: Record<string, string> = {
  'Chirurgiens-dentistes': 'جراحو الأسنان',
  'Orthodontistes': 'أخصائيو تقويم الأسنان',
  'Implantologues': 'أخصائيو زراعة الأسنان',
  'Pédodontistes': 'أطباء أسنان الأطفال',
  'Parodontistes': 'أخصائيو أمراض اللثة',
  'Dentistes généralistes': 'أطباء أسنان عامون',
  'Endodontistes': 'أخصائيو علاج الجذور والأعصاب',
  'Prosthodontistes': 'أخصائيو تركيبات الأسنان',
  'Chirurgie orale': 'جراحة الفم والفكين',
  'Cardiologie clinique': 'أمراض القلب السريرية',
  'Cardiologie interventionnelle': 'قسطرة الشرايين',
  'Rythmologie': 'كهرباء ونبض القلب',
  'Hypertension artérielle': 'علاج ضغط الدم',
  'Pédiatrie générale': 'طب الأطفال العام',
  'Néonatalogie': 'حديثو الولادة والخُدّج',
  'Urgences pédiatriques': 'طوارئ الأطفال',
  'Obstétrique & Suivi de grossesse': 'التوليد ومتابعة الحمل',
  'Échographie obstétricale': 'فحص الجنين بالسونار',
  'Chirurgie gynécologique': 'جراحة النساء',
  'Chirurgie cataracte & Réfractive': 'جراحة الماء الأبيض وتصحيح النظر',
  'Rétine & Glaucome': 'الشبكية وضغط العين',
  'Audiologie & Bilans auditifs': 'قياس وفحص السمع',
  'Chirurgie cervico-faciale': 'جراحة الوجه والرقبة',
  'Médecine de famille': 'طب الأسرة',
  "Soins d'urgence ambulatoires": 'العلاجات الاستعجالية',
  'Chirurgie digestive & Viscérale': 'جراحة الجهاز الهضمي والأحشاء',
  'Chirurgie laparoscopique': 'الجراحة بالمنظار',
  'Chirurgie traumatologique': 'جراحة الكسور والإصابات',
  'Chirurgie prothétique': 'تركيب المفاصل الصناعية',
  'Dermatologie clinique': 'الأمراض الجلدية السريرية',
  'Dermatologie pédiatrique': 'جلدية الأطفال',
  'Vénérologie': 'الأمراض التناسلية',
  'Diabétologie clinique': 'علاج السكري السريري',
  'Maladies de la thyroïde': 'أمراض الغدة الدرقية',
  'Troubles métaboliques': 'اضطرابات التمثيل الغذائي',
  'Consultation générale': 'استشارة عامة',
  'Urgence & Consultation': 'طوارئ واستشارة',
  'Bilan de santé': 'فحص طبي شامل',
  'Consultation de suivi': 'استشارة متابعة',
  'Certificat médical': 'شهادة طبية',
  'Contrôle bague • CNAM': 'فحص التقويم • كنام',
  'Détartrage & suivi • CNASS': 'تنظيف الأسنان والمتابعة • كناص',
  'Douleur aiguë • Sans assurance': 'ألم حاد • بدون تأمين',
  '1ère consultation orthodontie': 'أول استشارة لتقويم الأسنان',
  "Consultation de pose d'appareil": 'استشارة تركيب جهاز التقويم',
};

export const SPECIALTY_NAMES_TRANSLATIONS: Record<string, string> = {
  'Odontologie': 'طب الأسنان وجراحة الفم',
  'Cardiologie': 'أمراض القلب والشرايين',
  'Pédiatrie': 'طب الأطفال وحديثي الولادة',
  'Gynécologie - Obstétrique': 'أمراض النساء والتوليد',
  'Gynécologie': 'أمراض النساء والتوليد',
  'Ophtalmologie': 'طب وجراحة العيون',
  'ORL & Chirurgie Cervico-faciale': 'الأنف والأذن والحنجرة',
  'ORL': 'الأنف والأذن والحنجرة',
  'Médecine Générale': 'الطب العام وطب الأسرة',
  'Chirurgie Générale & Viscérale': 'الجراحة العامة وجراحة البطن',
  'Chirurgie Générale': 'الجراحة العامة',
  'Traumatologie & Orthopédie': 'جراحة العظام والمفاصل والكسور',
  'Orthopédie': 'جراحة العظام والمفاصل',
  'Dermatologie & Vénérologie': 'الأمراض الجلدية والتناسلية',
  'Dermatologie': 'الأمراض الجلدية والتناسلية',
  'Endocrinologie & Métabolisme': 'الغدد الصماء والسكري',
  'Endocrinologie': 'الغدد الصماء والسكري',
  'Neurologie': 'أمراض المخ والأعصاب',
  'Gastro-entérologie': 'أمراض الجهاز الهضمي والكبد',
  'Pneumologie': 'أمراض الصدر والجهاز التنفسي',
  'Urologie': 'جراحة المسالك البولية والكلى',
  'Radiologie & Imagerie': 'الأشعة والتصوير الطبي',
  'Radiologie': 'الأشعة والتصوير الطبي',
  'Psychiatrie': 'الطب النفسي',
  'Rhumatologie': 'أمراض المفاصل والروماتيزم',
  'Néphrologie': 'أمراض الكلى وغسيل الكلى',
  'Hématologie': 'أمراض الدم',
  'Oncologie Médicale': 'علاج الأورام السرطانية',
  'Oncologie': 'علاج الأورام السرطانية',
  'Chirurgie Pédiatrique': 'جراحة الأطفال',
  'Médecine Interne': 'الطب الباطني',
  'Anesthésie-Réanimation': 'التخدير والعناية المركزة',
  'Biologie Médicale': 'التحاليل الطبية والبيولوجية',
  'Médecine Physique & Rééducation': 'الطب الطبيعي وإعادة التأهيل',
  'Médecine du Travail': 'طب الشغل والسلامة المهنية',
  'Stomatologie': 'طب الفم والأسنان',
  'Chirurgie Plastique': 'جراحة التجميل والترميم',
  'Chirurgie Vasculaire': 'جراحة الأوعية الدموية',
  'Urgences Médicales': 'طب الطوارئ والاستعجالات',
};

export const translateSubspecialty = (name: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (lang !== 'ar') return name;
  return SUBSPECIALTY_TRANSLATIONS[name] || SPECIALTY_NAMES_TRANSLATIONS[name] || name;
};

export const translateSpecialtyName = (name: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (lang !== 'ar') return name;
  return SPECIALTY_NAMES_TRANSLATIONS[name] || SUBSPECIALTY_TRANSLATIONS[name] || name;
};

export const translateDoctorTitle = (title: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (lang !== 'ar') return title;
  return title
    .replace(/^Dr\.\s*/i, 'د. ')
    .replace(/^Dr\s+/i, 'د. ')
    .replace(/^Pr\.\s*/i, 'أ.د. ')
    .replace(/^Pr\s+/i, 'أ.د. ');
};

export const ESTABLISHMENT_NAME_TRANSLATIONS: Record<string, string> = {
  'Clinique Ibn Sina': 'عيادة ابن سينا',
  'Clinique Avicenne Nouakchott': 'مصحة أفيسينا بنواكشوط',
  'Centre Hospitalier National (CHN)': 'مركز الاستطباب الوطني',
  'Centre Hospitalier National': 'مركز الاستطباب الوطني',
  'Hôpital Militaire de Nouakchott (HMN)': 'المستشفى العسكري بنواكشوط',
  'Hôpital Militaire': 'المستشفى العسكري',
  'Centre Hospitalier Mère et Enfant (Hôpital Sabah)': 'مركز الأمومة والطفولة (مستشفى صباح)',
  'Centre Hospitalier Mère et Enfant': 'مركز الأمومة والطفولة',
  'Hôpital Cheikh Zayed': 'مستشفى الشيخ زايد',
  'Cabinet Nejah & Orthodontie': 'عيادة النجاح لتقويم الأسنان',
  'Cabinet Dentaire Al-Afia': 'عيادة العافية لطب الأسنان',
  'Biomed 24 Laboratoire': 'مختبر بيوميد ٢٤ للتحاليل',
};

export const REASON_TRANSLATIONS: Record<string, string> = {
  'Consultation initiale orthodontie': 'استشارة أولى لتقويم الأسنان',
  'Contrôle trimestriel & détartrage': 'متابعة فصلية وتنظيف الأسنان',
  'Suivi mensuel appareil': 'متابعة شهرية لجهاز التقويم',
  'Urgence douleur vive': 'طوارئ ألم حاد',
  'Consultation générale': 'استشارة عامة',
  'Urgence & Consultation': 'طوارئ واستشارة',
  'Bilan de santé': 'فحص طبي شامل',
  'Consultation de suivi': 'استشارة متابعة',
  'Certificat médical': 'شهادة طبية',
  'Certificat médical d\'aptitude': 'شهادة اللياقة الطبية',
  'Contrôle bague • CNAM': 'فحص التقويم • كنام',
  'Détartrage & suivi • CNASS': 'تنظيف الأسنان والمتابعة • كناص',
  'Douleur aiguë • Sans assurance': 'ألم حاد • بدون تأمين',
  '1ère consultation orthodontie': 'أول استشارة لتقويم الأسنان',
  'Consultation de pose d\'appareil': 'استشارة تركيب جهاز التقويم',
  'Renouvellement ordonnance': 'تجديد الوصفة الطبية',
  'Contrôle tension artérielle': 'فحص ضغط الدم',
  'Échographie de contrôle': 'فحص السونار للمتابعة',
};

export const formatTimeLtr = (time: string): string => {
  if (!time) return '';
  const western = time
    .replace(/٠/g, '0').replace(/١/g, '1').replace(/٢/g, '2').replace(/٣/g, '3').replace(/٤/g, '4')
    .replace(/٥/g, '5').replace(/٦/g, '6').replace(/٧/g, '7').replace(/٨/g, '8').replace(/٩/g, '9');
  return `\u2066\u200E${western}\u200E\u2069`;
};

export interface SlotParts {
  prefix: string;
  time: string;
}

export const parseSlotParts = (slotStr: string, lang: 'fr' | 'ar' = 'fr'): SlotParts => {
  if (!slotStr) return { prefix: '', time: '' };
  const western = slotStr
    .replace(/٠/g, '0').replace(/١/g, '1').replace(/٢/g, '2').replace(/٣/g, '3').replace(/٤/g, '4')
    .replace(/٥/g, '5').replace(/٦/g, '6').replace(/٧/g, '7').replace(/٨/g, '8').replace(/٩/g, '9');

  const timeMatch = western.match(/(\d{1,2}:\d{2})/);
  const time = timeMatch ? timeMatch[1] : '';

  if (lang !== 'ar') {
    const rawPrefix = slotStr.replace(time, '').replace(/à\s*$/, '').trim();
    return { prefix: rawPrefix ? `${rawPrefix} à ` : '', time };
  }

  let p = western.replace(time, '').replace(/[\u200E\u2066\u2069]/g, '').trim();
  p = p
    .replace(/Aujourd'hui à?/i, 'اليوم')
    .replace(/Aujourd'hui/i, 'اليوم')
    .replace(/Demain à?/i, 'غداً')
    .replace(/Demain/i, 'غداً')
    .replace(/Lundi à?/i, 'الإثنين')
    .replace(/Mardi à?/i, 'الثلاثاء')
    .replace(/Mercredi à?/i, 'الأربعاء')
    .replace(/Jeudi à?/i, 'الخميس')
    .replace(/Vendredi à?/i, 'الجمعة')
    .replace(/Samedi à?/i, 'السبت')
    .replace(/Dimanche à?/i, 'الأحد')
    .replace(/الساعة/g, '')
    .replace(/عند/g, '')
    .replace(/à/g, '')
    .trim();

  return {
    prefix: p ? `${p} عند ` : 'اليوم عند ',
    time,
  };
};

export const translateSlotText = (slot: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (!slot) return '';
  if (lang !== 'ar') return slot;
  const { prefix, time } = parseSlotParts(slot, 'ar');
  if (!time) return prefix.trim();
  // Enforce left-to-right isolate on any time like 18:00 or 15:30 (never 00:18 or 30:15)
  return `${prefix}\u2066\u200E${time}\u200E\u2069`;
};

export const translateOpeningHours = (hours: string, hoursAr?: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (lang !== 'ar') return hours || '';
  if (hoursAr) {
    const western = hoursAr
      .replace(/٠/g, '0').replace(/١/g, '1').replace(/٢/g, '2').replace(/٣/g, '3').replace(/٤/g, '4')
      .replace(/٥/g, '5').replace(/٦/g, '6').replace(/٧/g, '7').replace(/٨/g, '8').replace(/٩/g, '9');
    return western.replace(/(\d{1,2}:\d{2})/g, '\u2066\u200E$1\u200E\u2069');
  }
  if (!hours) return 'مفتوح';
  if (hours.includes('24h') || hours.includes('24/24') || hours.includes('7j/7')) {
    return 'مفتوح 24/24 • 7/7 (طوارئ مستمرة)';
  }
  return hours
    .replace(/Lun\s*-\s*Sam/i, 'الإثنين - السبت')
    .replace(/Lun\s*-\s*Ven/i, 'الإثنين - الجمعة')
    .replace(/h/gi, ':')
    .replace(/(\d{1,2}:\d{2})/g, '\u2066\u200E$1\u200E\u2069');
};

export const translateEstablishmentName = (name: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (lang !== 'ar') return name;
  return ESTABLISHMENT_NAME_TRANSLATIONS[name] || name;
};

export const translateReason = (reason: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (lang !== 'ar') return reason;
  return REASON_TRANSLATIONS[reason] || SUBSPECIALTY_TRANSLATIONS[reason] || reason;
};

export const translateDateFormatted = (dateStr: string, lang: 'fr' | 'ar' = 'fr'): string => {
  if (lang !== 'ar') return dateStr;
  return dateStr
    .replace(/Lun\./i, 'الإثنين')
    .replace(/Lundi/i, 'الإثنين')
    .replace(/Mar\./i, 'الثلاثاء')
    .replace(/Mardi/i, 'الثلاثاء')
    .replace(/Mer\./i, 'الأربعاء')
    .replace(/Mercredi/i, 'الأربعاء')
    .replace(/Jeu\./i, 'الخميس')
    .replace(/Jeudi/i, 'الخميس')
    .replace(/Ven\./i, 'الجمعة')
    .replace(/Vendredi/i, 'الجمعة')
    .replace(/Sam\./i, 'السبت')
    .replace(/Samedi/i, 'السبت')
    .replace(/Dim\./i, 'الأحد')
    .replace(/Dimanche/i, 'الأحد')
    .replace(/Janvier/i, 'يناير')
    .replace(/Février/i, 'فبراير')
    .replace(/Mars/i, 'مارس')
    .replace(/Avril/i, 'أبريل')
    .replace(/Mai/i, 'مايو')
    .replace(/Juin/i, 'يونيو')
    .replace(/Juillet/i, 'يوليو')
    .replace(/Août/i, 'أغسطس')
    .replace(/Septembre/i, 'سبتمبر')
    .replace(/Octobre/i, 'أكتوبر')
    .replace(/Novembre/i, 'نوفمبر')
    .replace(/Décembre/i, 'ديسمبر')
    .replace(/\bà\b/g, 'عند');
};



