/**
 * Helper to extract clean first name and last name from email or displayName
 * e.g., "lalahabibbakar@gmail.com" -> firstName: "Lala", lastName: "Habib Bakar"
 * "sidi.ould.ahmed@gmail.com" -> firstName: "Sidi", lastName: "Ould Ahmed"
 * "v.baba-ahmed@mailistec.fr" -> firstName: "Baba Ahmed", lastName: "Mailistec"
 */
export function extractNamesFromUser(displayName?: string | null, email?: string | null): { firstName: string; lastName: string } {
  // 1. If explicit display name exists and doesn't look like an email
  if (displayName && displayName.trim().length > 0 && !displayName.includes('@')) {
    const cleanDisplay = displayName.trim();
    const parts = cleanDisplay.split(/\s+/);
    if (parts.length > 1) {
      return {
        firstName: capitalize(parts[0]),
        lastName: parts.slice(1).map(capitalize).join(' ')
      };
    }
    return {
      firstName: capitalize(cleanDisplay),
      lastName: ''
    };
  }

  // 2. If email exists, parse username part
  if (email && email.includes('@')) {
    const username = email.split('@')[0].trim();

    // Check for common separators (., _, -)
    if (username.includes('.') || username.includes('_') || username.includes('-')) {
      const parts = username.split(/[._-]+/).filter(Boolean);
      if (parts.length > 1) {
        // If first part is just a single initial like 'v' in 'v.baba-ahmed'
        if (parts[0].length === 1 && parts.length > 2) {
          return {
            firstName: capitalize(parts[1]),
            lastName: parts.slice(2).map(capitalize).join(' ')
          };
        }
        return {
          firstName: capitalize(parts[0]),
          lastName: parts.slice(1).map(capitalize).join(' ')
        };
      }
    }

    // Try detecting camelCase or known Mauritanian/Arabic prefixes like 'ould', 'mint', 'habib', 'bakar', 'ahmed', 'mohamed'
    // For 'lalahabibbakar', extract 'Lala'
    const lower = username.toLowerCase();
    const knownFirstNames = [
      'lala', 'leila', 'leyla', 'fatimetou', 'mariem', 'mariam', 'aminata', 'aicha', 'zeinabou', 'khadija',
      'sidi', 'mohamed', 'ahmed', 'cheikh', 'ibrahim', 'moustapha', 'abdallahi', 'ismail', 'ousmane', 'mamadou',
      'yahya', 'yacoub', 'kane', 'diallo', 'ba', 'traore', 'sy', 'diop', 'vivi'
    ];

    for (const fn of knownFirstNames) {
      if (lower.startsWith(fn) && lower.length > fn.length) {
        const remaining = lower.slice(fn.length);
        // Formulate readable last name
        let formattedLast = remaining;
        // Check if remaining contains recognizable tokens
        formattedLast = formattedLast
          .replace(/(habib)/gi, ' Habib ')
          .replace(/(bakar|bakr)/gi, ' Bakar ')
          .replace(/(ould)/gi, ' Ould ')
          .replace(/(mint)/gi, ' Mint ')
          .replace(/(ahmed)/gi, ' Ahmed ')
          .replace(/(mohamed)/gi, ' Mohamed ')
          .trim();

        return {
          firstName: capitalize(fn),
          lastName: formattedLast.split(/\s+/).map(capitalize).join(' ')
        };
      }
    }

    // Fallback: capitalize username
    return {
      firstName: capitalize(username),
      lastName: ''
    };
  }

  return {
    firstName: 'Patient',
    lastName: 'RIMEDIC'
  };
}

function capitalize(s: string): string {
  if (!s) return '';
  return s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
}
