/**
 * Demonstration Data for RIMEDIC Mauritanie
 * Clearly tagged: "Données de démonstration"
 */

import { City, Establishment, Practitioner, Specialty, Appointment, PatientProfile, PractitionerScheduleDay, PractitionerProfileData } from '../types';
import { ALL_142_ESTABLISHMENTS } from './establishmentsData';
import { ALL_PRACTITIONERS } from './practitionersData';

export const CITIES_DATA: City[] = [
  {
    id: 'nouakchott',
    name: 'Nouakchott',
    nameAr: 'نواكشوط',
    wilaya: 'Capitale (Ouest, Nord, Sud)',
    wilayaAr: 'العاصمة (الغربية، الشمالية، الجنوبية)',
    moughataas: ['Tevragh-Zeina', 'Ksar', 'Sebkha', 'Arafat', 'Dar Naïm', 'Toujounine', 'El Mina', 'Teyarett', 'Riyadh'],
    moughataasAr: ['تفرغ زينة', 'لكصر', 'السبخة', 'عرفات', 'دار النعيم', 'توجنين', 'الميناء', 'تيارت', 'الرياض'],
    centerCount: 34,
    practitionerCount: 142,
    isCapital: true,
  }
];

export const SPECIALTIES_DATA: Specialty[] = [
  {
    id: 'odontologie',
    name: 'Odontologie',
    nameAr: 'طب الأسنان وجراحة الفم',
    subtitle: 'Dentaire & Soins buccaux',
    subtitleAr: 'تقويم وزراعة وجراحة الأسنان',
    icon: 'dentistry',
    category: 'dentaire',
    isPopular: true,
    specialistCount: 64,
    availableDelay: 'Dispo sous 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'dentistes-chirurgiens', name: 'Chirurgiens-dentistes', nameAr: 'جراحو الأسنان', doctorCount: 26 },
      { id: 'orthodontistes', name: 'Orthodontistes', nameAr: 'أخصائيو تقويم الأسنان', doctorCount: 14 },
      { id: 'implantologues', name: 'Implantologues', nameAr: 'أخصائيو زراعة الأسنان', doctorCount: 9 },
      { id: 'pedodontistes', name: 'Pédodontistes', nameAr: 'أطباء أسنان الأطفال', doctorCount: 8 },
      { id: 'parodontistes', name: 'Parodontistes', nameAr: 'أخصائيو أمراض اللثة', doctorCount: 5 },
      { id: 'dentistes-generalistes', name: 'Dentistes généralistes', nameAr: 'أطباء أسنان عامون', doctorCount: 42 },
      { id: 'endodontistes', name: 'Endodontistes', nameAr: 'أخصائيو علاج الجذور والأعصاب', doctorCount: 6 },
      { id: 'prosthodontistes', name: 'Prosthodontistes', nameAr: 'أخصائيو تركيبات الأسنان', doctorCount: 7 },
      { id: 'chirurgie-orale', name: 'Chirurgie orale', nameAr: 'جراحة الفم والفكين', doctorCount: 5 },
    ]
  },
  {
    id: 'cardiologie',
    name: 'Cardiologie',
    nameAr: 'أمراض القلب والشرايين',
    subtitle: 'Cœur & Vaisseaux',
    subtitleAr: 'تخطيط، دوبلر وفحوصات القلب',
    icon: 'favorite',
    category: 'consultation',
    isPopular: true,
    specialistCount: 38,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'cardio-clinique', name: 'Cardiologie clinique', nameAr: 'أمراض القلب السريرية', doctorCount: 18 },
      { id: 'cardio-interventionnelle', name: 'Cardiologie interventionnelle', nameAr: 'قسطرة الشرايين', doctorCount: 8 },
      { id: 'rythmologie', name: 'Rythmologie', nameAr: 'كهرباء ونبض القلب', doctorCount: 5 },
      { id: 'hypertension', name: 'Hypertension artérielle', nameAr: 'علاج ضغط الدم', doctorCount: 7 }
    ]
  },
  {
    id: 'pediatrie',
    name: 'Pédiatrie & Néonatalogie',
    nameAr: 'طب الأطفال وحديثي الولادة',
    subtitle: 'Enfants & Bébés',
    subtitleAr: 'رعاية الرضع واللقاحات والمتابعة',
    icon: 'child_care',
    category: 'mere-enfant',
    isPopular: true,
    specialistCount: 45,
    availableDelay: "Aujourd'hui",
    availableDelayAr: 'متاح اليوم',
    subspecialties: [
      { id: 'pediatrie-generale', name: 'Pédiatrie générale', nameAr: 'طب الأطفال العام', doctorCount: 28 },
      { id: 'neonatologie', name: 'Néonatalogie', nameAr: 'حديثو الولادة والخُدّج', doctorCount: 9 },
      { id: 'urgences-pediatriques', name: 'Urgences pédiatriques', nameAr: 'طوارئ الأطفال', doctorCount: 8 }
    ]
  },
  {
    id: 'gynecologie',
    name: 'Gynécologie-obstétrique',
    nameAr: 'أمراض النساء والتوليد',
    subtitle: 'Obstétrique & Maternité',
    subtitleAr: 'متابعة الحمل والولادة والموجات فوق الصوتية',
    icon: 'pregnant_woman',
    category: 'mere-enfant',
    isPopular: true,
    specialistCount: 52,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'obstetrique', name: 'Obstétrique & Suivi de grossesse', nameAr: 'التوليد ومتابعة الحمل', doctorCount: 24 },
      { id: 'echographie-gyneco', name: 'Échographie obstétricale', nameAr: 'فحص الجنين بالسونار', doctorCount: 16 },
      { id: 'chirurgie-gyneco', name: 'Chirurgie gynécologique', nameAr: 'جراحة النساء', doctorCount: 12 }
    ]
  },
  {
    id: 'ophtalmologie',
    name: 'Ophtalmologie',
    nameAr: 'طب وجراحة العيون',
    subtitle: 'Vision & Soins oculaires',
    subtitleAr: 'فحص البصر وجراحة الليزر',
    icon: 'visibility',
    category: 'chirurgie',
    isPopular: true,
    specialistCount: 29,
    availableDelay: 'Sous 48h',
    availableDelayAr: 'خلال ٤٨ ساعة',
    subspecialties: [
      { id: 'chirurgie-cataracte', name: 'Chirurgie cataracte & Réfractive', nameAr: 'جراحة الماء الأبيض وتصحيح النظر', doctorCount: 14 },
      { id: 'retine-medicale', name: 'Rétine & Glaucome', nameAr: 'الشبكية وضغط العين', doctorCount: 15 }
    ]
  },
  {
    id: 'orl',
    name: 'ORL',
    nameAr: 'أمراض الأنف والأذن والحنجرة',
    subtitle: 'Gorge, Nez, Oreille',
    subtitleAr: 'السمع والتنفس والحبال الصوتية',
    icon: 'hearing',
    category: 'consultation',
    isPopular: true,
    specialistCount: 22,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'audiologie', name: 'Audiologie & Bilans auditifs', nameAr: 'قياس وفحص السمع', doctorCount: 10 },
      { id: 'chirurgie-cervico', name: 'Chirurgie cervico-faciale', nameAr: 'جراحة الوجه والرقبة', doctorCount: 12 }
    ]
  },
  {
    id: 'medecine-generale',
    name: 'Médecine générale & Urgence',
    nameAr: 'الطب العام والطوارئ',
    subtitle: 'Soins de premier recours',
    subtitleAr: 'الكشف الأولي والتشخيص السريع',
    icon: 'stethoscope',
    category: 'consultation',
    specialistCount: 112,
    availableDelay: 'Immédiat',
    availableDelayAr: 'فوري دون انتظار',
    subspecialties: [
      { id: 'med-generale', name: 'Médecine générale', nameAr: 'طبيب عام', doctorCount: 88 },
      { id: 'samu-urgence', name: 'Médecine d\'urgence', nameAr: 'طب الطوارئ والإنعاش', doctorCount: 24 }
    ]
  },
  {
    id: 'dermatologie',
    name: 'Dermatologie & Vénérologie',
    nameAr: 'أمراض الجلد والتناسلية',
    subtitle: 'Peau, Cheveux & Ongles',
    subtitleAr: 'علاج حب الشباب والحساسية الجلدية والليزر',
    icon: 'dermatology',
    category: 'consultation',
    specialistCount: 19,
    availableDelay: 'Sous 48h',
    availableDelayAr: 'خلال ٤٨ ساعة',
    subspecialties: [
      { id: 'dermato-clinique', name: 'Dermatologie clinique', nameAr: 'أمراض الجلد السريرية', doctorCount: 12 },
      { id: 'laser-esthetique', name: 'Laser dermatologique', nameAr: 'الليزر وعلاج الندبات', doctorCount: 7 }
    ]
  },
  {
    id: 'orthopedie',
    name: 'Orthopédie & Traumatologie',
    nameAr: 'جراحة العظام والمفاصل',
    subtitle: 'Os, Articulations & Fractures',
    subtitleAr: 'الجبائر والمفاصل الصناعية والإصابات الرياضية',
    icon: 'medical_services',
    category: 'chirurgie',
    specialistCount: 31,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'traumatologie', name: 'Traumatologie & Fractures', nameAr: 'علاج الكسور والرضوض', doctorCount: 18 },
      { id: 'chirurgie-articulaire', name: 'Chirurgie prothétique', nameAr: 'تبديل المفاصل', doctorCount: 13 }
    ]
  },
  {
    id: 'neurologie',
    name: 'Neurologie & Neurochirurgie',
    nameAr: 'أمراض وجراحة المخ والأعصاب',
    subtitle: 'Système nerveux & Céphalées',
    subtitleAr: 'الصداع النصفي والصرع والعمود الفقري',
    icon: 'psychology',
    category: 'chirurgie',
    specialistCount: 16,
    availableDelay: 'Sous 3j',
    availableDelayAr: 'خلال ٣ أيام',
    subspecialties: [
      { id: 'neurologie-clinique', name: 'Neurologie & EEG', nameAr: 'تخطيط الدماغ والأعصاب', doctorCount: 10 },
      { id: 'neurochirurgie', name: 'Neurochirurgie rachidienne', nameAr: 'جراحة العمود الفقري', doctorCount: 6 }
    ]
  },
  {
    id: 'pneumologie',
    name: 'Pneumologie & Allergologie',
    nameAr: 'أمراض الجهاز التنفسي والحساسية',
    subtitle: 'Poumons, Asthme & EFR',
    subtitleAr: 'الربو والالتهابات الرئوية ووظائف التنفس',
    icon: 'pulmonology',
    category: 'consultation',
    specialistCount: 21,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'asthme-allergie', name: 'Asthme & Allergologie', nameAr: 'حساسية الصدر', doctorCount: 12 },
      { id: 'efr-sommeil', name: 'Explorations fonctionnelles', nameAr: 'فحوصات التنفس', doctorCount: 9 }
    ]
  },
  {
    id: 'gastro-enterologie',
    name: 'Gastro-entérologie & Hépatologie',
    nameAr: 'الجهاز الهضمي والكبد والمناظير',
    subtitle: 'Estomac, Intestins & Foie',
    subtitleAr: 'قرحة المعدة والقولون والمناظير الهضمية',
    icon: 'health_and_safety',
    category: 'consultation',
    specialistCount: 25,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'endoscopie-digestive', name: 'Endoscopie digestive', nameAr: 'مناظير المعدة والقولون', doctorCount: 15 },
      { id: 'hepatologie', name: 'Hépatologie', nameAr: 'أمراض الكبد والفيروسات', doctorCount: 10 }
    ]
  },
  {
    id: 'urologie',
    name: 'Urologie',
    nameAr: 'جراحة المسالك البولية والتناسلية',
    subtitle: 'Reins, Vessie & Prostate',
    subtitleAr: 'حصوات الكلى وتضخم البروستاتا',
    icon: 'medical_information',
    category: 'chirurgie',
    specialistCount: 18,
    availableDelay: 'Sous 48h',
    availableDelayAr: 'خلال ٤٨ ساعة',
    subspecialties: [
      { id: 'calculs-lithotripsie', name: 'Calculs & Lithotripsie', nameAr: 'تفتيت حصى الكلى', doctorCount: 10 },
      { id: 'urologie-prostate', name: 'Prostate & Chirurgie endoscopique', nameAr: 'جراحة البروستاتا بالمنظار', doctorCount: 8 }
    ]
  },
  {
    id: 'nephrologie',
    name: 'Néphrologie & Dialyse',
    nameAr: 'أمراض الكلى والغسيل الكلوي',
    subtitle: 'Reins & Épuration sanguine',
    subtitleAr: 'متابعة القصور الكلوي والغسيل',
    icon: 'water_drop',
    category: 'consultation',
    specialistCount: 14,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'insuffisance-renale', name: 'Insuffisance rénale', nameAr: 'القصور الكلوي المزمن', doctorCount: 8 },
      { id: 'hemodialyse', name: 'Hémodialyse', nameAr: 'مراكز الغسيل الكلوي', doctorCount: 6 }
    ]
  },
  {
    id: 'diabetologie',
    name: 'Diabétologie & Endocrinologie',
    nameAr: 'علاج السكري والغدد الصماء',
    subtitle: 'Diabète (types 1 & 2) & Thyroïde',
    subtitleAr: 'مرض السكري والغدة والأنسولين',
    icon: 'bloodtype',
    category: 'consultation',
    isPopular: true,
    specialistCount: 28,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    keywords: [
      'diabete', 'diabètes', 'diabete', 'diabète', 'diabetes', 'diabétologie', 'diabetologie',
      'diabétologue', 'diabetologue', 'sucre', 'glycemie', 'glycémie', 'insuline', 'insulin',
      'pied diabetique', 'pied diabétique', 'endocrino', 'endocrinologue', 'endocrinologie',
      'thyroide', 'thyroïde', 'goitre', 'hba1c', 'pancreas', 'سكري', 'السكري', 'مرض السكري',
      'سكر', 'الأنسولين', 'غدد', 'الغدد الصماء'
    ],
    subspecialties: [
      { id: 'diabete-type1-type2', name: 'Diabète Type 1 & Type 2', nameAr: 'السكري من النوع 1 و2', doctorCount: 16 },
      { id: 'diabete-gestationnel', name: 'Diabète gestationnel (grossesse)', nameAr: 'سكري الحمل والمتابعة', doctorCount: 8 },
      { id: 'pied-diabetique', name: 'Pied diabétique & Complications', nameAr: 'علاج ومتابعة القدم السكرية', doctorCount: 7 },
      { id: 'nutrition-diabete', name: 'Nutrition & Diététique du diabétique', nameAr: 'الحمية والتغذية العلاجية للسكري', doctorCount: 12 },
      { id: 'diabete-enfant', name: 'Diabète de l\'enfant & adolescent', nameAr: 'سكري الأطفال واليافعين', doctorCount: 6 },
      { id: 'pathologies-thyroide', name: 'Thyroïde & Hormones métaboliques', nameAr: 'أمراض الغدة الدرقية واضطراب الهرمونات', doctorCount: 9 },
    ]
  },
  {
    id: 'endocrinologie',
    name: 'Endocrinologie (Maladies hormonales)',
    nameAr: 'أمراض الغدد الصماء والهرمونات',
    subtitle: 'Thyroïde, Surrénales & Métabolisme',
    subtitleAr: 'اضطرابات الغدة الدرقية، النمو والهرمونات',
    icon: 'monitor_heart',
    category: 'consultation',
    specialistCount: 18,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    keywords: ['endocrino', 'endocrinologie', 'hormones', 'thyroide', 'diabete', 'غدد', 'هرمونات'],
    subspecialties: [
      { id: 'pathologies-thyroide-endo', name: 'Thyroïde & Nodule thyroïdien', nameAr: 'أمراض وعقد الغدة الدرقية', doctorCount: 8 },
      { id: 'surrenales-hypophyse', name: 'Hypophyse & Surrénales', nameAr: 'الغدة النخامية والكظرية', doctorCount: 5 },
      { id: 'troubles-croissance', name: 'Troubles hormonaux & Métabolisme', nameAr: 'اضطرابات الهرمونات والتمثيل الغذائي', doctorCount: 5 }
    ]
  },
  {
    id: 'psychiatrie',
    name: 'Psychiatrie & Santé mentale',
    nameAr: 'الطب النفسي والعلاج السلوكي',
    subtitle: 'Soutien psychologique & Sommeil',
    subtitleAr: 'علاج القلق والاكتئاب واضطرابات النوم',
    icon: 'emoji_objects',
    category: 'consultation',
    specialistCount: 12,
    availableDelay: 'Sous 48h',
    availableDelayAr: 'خلال ٤٨ ساعة',
    subspecialties: [
      { id: 'psychiatrie-adulte', name: 'Psychiatrie adulte', nameAr: 'الطب النفسي للبالغين', doctorCount: 8 },
      { id: 'pedopsychiatrie', name: 'Pédopsychiatrie', nameAr: 'الطب النفسي للأطفال والمراهقين', doctorCount: 4 }
    ]
  },
  {
    id: 'kinesitherapie',
    name: 'Kinésithérapie & Rééducation',
    nameAr: 'العلاج الطبيعي والتأهيل الحركي',
    subtitle: 'Réadaptation & Massage médical',
    subtitleAr: 'العلاج الفيزيائي وإعادة التأهيل بعد الجراحة',
    icon: 'fitness_center',
    category: 'consultation',
    specialistCount: 27,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'reeducation-ortho', name: 'Rééducation orthopédique', nameAr: 'تأهيل العظام والإصابات', doctorCount: 16 },
      { id: 'kine-domicile', name: 'Soins à domicile', nameAr: 'جلسات منزلية', doctorCount: 11 }
    ]
  },
  {
    id: 'radiologie',
    name: 'Radiologie & Imagerie médicale',
    nameAr: 'الأشعة والتصوير الطبي',
    subtitle: 'Scanner, IRM, Échographie',
    subtitleAr: 'الرنين المغناطيسي والأشعة المقطعية والسونار',
    icon: 'perm_media',
    category: 'consultation',
    specialistCount: 24,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'scanner-irm', name: 'Scanner & IRM', nameAr: 'أشعة مقطعية ورنين مغناطيسي', doctorCount: 14 },
      { id: 'echographie-doppler', name: 'Échographie & Doppler', nameAr: 'الموجات فوق الصوتية والدوبلر', doctorCount: 10 }
    ]
  },
  {
    id: 'chirurgie-generale',
    name: 'Chirurgie générale & Digestive',
    nameAr: 'الجراحة العامة وجراحة البطن',
    subtitle: 'Interventions & Blocs opératoires',
    subtitleAr: 'العمليات الجراحية وجراحة الفتق والزائدة',
    icon: 'medical_services',
    category: 'chirurgie',
    specialistCount: 28,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'chirurgie-laparo', name: 'Chirurgie laparoscopique', nameAr: 'جراحة المناظير المتقدمة', doctorCount: 16 },
      { id: 'chirurgie-urgence', name: 'Chirurgie d\'urgence', nameAr: 'جراحة الحالات الحرجة', doctorCount: 12 }
    ]
  },
  {
    id: 'oncologie',
    name: 'Oncologie & Cancérologie',
    nameAr: 'علاج الأورام وأمراض السرطان',
    subtitle: 'Chimiothérapie & Dépistage',
    subtitleAr: 'العلاج الكيميائي والكشف المبكر',
    icon: 'healing',
    category: 'specialise',
    specialistCount: 11,
    availableDelay: 'Sous 48h',
    availableDelayAr: 'خلال ٤٨ ساعة',
    subspecialties: [
      { id: 'onco-medicale', name: 'Oncologie médicale', nameAr: 'طب الأورام السريري', doctorCount: 7 },
      { id: 'radiotherapie', name: 'Radiothérapie', nameAr: 'العلاج بالأشعة', doctorCount: 4 }
    ]
  },
  {
    id: 'rhumatologie',
    name: 'Rhumatologie',
    nameAr: 'أمراض المفاصل والروماتيزم',
    subtitle: 'Arthrite & Douleurs articulaires',
    subtitleAr: 'التهاب المفاصل وهشاشة العظام',
    icon: 'accessibility_new',
    category: 'consultation',
    specialistCount: 14,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'rhumato-generale', name: 'Rhumatologie générale', nameAr: 'علاج الروماتيزم والعمود الفقري', doctorCount: 14 }
    ]
  },
  {
    id: 'medecine-interne',
    name: 'Médecine interne',
    nameAr: 'الطب الباطني والأمراض المعقدة',
    subtitle: 'Diagnostics complexes & Multi-pathologies',
    subtitleAr: 'الفحوصات الشاملة والحالات المزمنة المتعددة',
    icon: 'biotech',
    category: 'consultation',
    specialistCount: 22,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'med-interne-clinique', name: 'Médecine interne générale', nameAr: 'طب باطني سريري', doctorCount: 22 }
    ]
  },
  {
    id: 'infectiologie',
    name: 'Infectiologie & Maladies tropicales',
    nameAr: 'الأمراض المعدية والمدارية',
    subtitle: 'Infections bactériennes & Virales',
    subtitleAr: 'الحميات والأمراض الفيروسية والطفيلية',
    icon: 'coronavirus',
    category: 'consultation',
    specialistCount: 13,
    availableDelay: 'Dispo 24h',
    availableDelayAr: 'متاح خلال ٢٤ ساعة',
    subspecialties: [
      { id: 'infections-tropicales', name: 'Maladies tropicales & Paludisme', nameAr: 'الملاريا والأمراض المدارية', doctorCount: 13 }
    ]
  },
  {
    id: 'anesthesie-reanimation',
    name: 'Anesthésie-réanimation',
    nameAr: 'التخدير والعناية المركزة',
    subtitle: 'Blocs opératoires & Soins critiques',
    subtitleAr: 'التخدير الجراحي والإنعاش الطبي',
    icon: 'airline_seat_flat',
    category: 'chirurgie',
    specialistCount: 19,
    availableDelay: 'Immédiat',
    availableDelayAr: 'فوري في المستشفيات',
    subspecialties: [
      { id: 'reanimation-soins-intensifs', name: 'Réanimation & Soins intensifs', nameAr: 'العناية المركزة', doctorCount: 19 }
    ]
  },
  {
    id: 'medecine-urgence',
    name: 'Médecine d\'urgence & SAMU 101',
    nameAr: 'طب الطوارئ والإسعاف الطبي',
    subtitle: 'Interventions 24/7 & Régulation SAMU',
    subtitleAr: 'طوارئ مستمرة ٢٤ ساعة وخط النجدة ١٠١',
    icon: 'emergency',
    category: 'consultation',
    urgent: true,
    specialistCount: 30,
    availableDelay: '24h/24',
    availableDelayAr: 'على مدار الساعة',
    subspecialties: [
      { id: 'regulation-samu', name: 'Régulation SAMU 101', nameAr: 'إسعاف ١٠١', doctorCount: 12 },
      { id: 'urgences-hospitalieres', name: 'Urgences hospitalières', nameAr: 'أقسام الطوارئ', doctorCount: 18 }
    ]
  }
];

export const ESTABLISHMENTS_DATA: Establishment[] = ALL_142_ESTABLISHMENTS;

export const PRACTITIONERS_DATA: Practitioner[] = ALL_PRACTITIONERS;

// Centralized metrics calculated directly from verified data sources
export const TOTAL_SPECIALTIES_COUNT = SPECIALTIES_DATA.length; // 25
export const TOTAL_ESTABLISHMENTS_COUNT = ESTABLISHMENTS_DATA.length; // 142
export const TOTAL_PRACTITIONERS_COUNT = PRACTITIONERS_DATA.length; // 142

// Empty patient profile for unauthenticated / clean state
export const EMPTY_PATIENT: PatientProfile = {
  id: '',
  firstName: '',
  lastName: '',
  birthDate: '',
  gender: 'male',
  phone: '',
  nni: '',
  city: 'Nouakchott',
  neighborhood: 'Tevragh Zeina',
  insuranceType: 'NONE',
};

// Test User A (Ahmed Ould Cheikh - CNAM)
export const TEST_USER_A: PatientProfile = {
  id: 'user-ahmed-01',
  firstName: 'Ahmed',
  lastName: 'Ould Cheikh',
  birthDate: '1989-06-15',
  gender: 'male',
  phone: '+222 45 11 22 33',
  nni: '2840192831',
  city: 'Nouakchott',
  neighborhood: 'Tevragh Zeina',
  insuranceType: 'CNAM',
  insuranceNumber: 'CNAM-712-401928-1',
};

// Test User B (Mariem Mint Bilal - CNASS)
export const TEST_USER_B: PatientProfile = {
  id: 'user-mariem-02',
  firstName: 'Mariem',
  lastName: 'Mint Bilal',
  birthDate: '1995-11-20',
  gender: 'female',
  phone: '+222 36 99 88 77',
  nni: '5920194821',
  city: 'Nouakchott',
  neighborhood: 'Ksar',
  insuranceType: 'CNASS',
  insuranceNumber: 'CNASS-902-184029-4',
};

export const TEST_APPOINTMENTS_A: Appointment[] = [
  {
    id: 'apt-a-01',
    referenceNumber: 'SCAN-RIM-10492',
    patientId: 'user-ahmed-01',
    patientName: 'Ahmed Ould Cheikh',
    patientPhone: '+222 45 11 22 33',
    patientNni: '2840••••31',
    practitionerId: 'dr-mohamed-ould-ahmed',
    practitionerName: 'Dr Mohamed Ould Ahmed',
    practitionerSpecialty: 'Orthodontie & Chirurgie dentaire',
    practitionerSpecialtyAr: 'تقويم وجراحة الأسنان',
    establishmentId: 'clinique-ibn-sina',
    establishmentName: 'Clinique Ibn Sina',
    establishmentAddress: 'Tevragh Zeina, Rue 42-015, Nouakchott',
    date: '2026-10-05',
    dateFormatted: 'Lun. 05 Octobre 2026',
    time: '15:30',
    fee: 1500,
    reason: 'Première consultation orthodontie',
    reasonAr: 'أول كشف تقويم أسنان',
    status: 'confirmed',
    insuranceType: 'CNAM',
    insuranceCoveragePercent: 80,
    cnamAmount: 1200,
    patientAmount: 300,
    qrCodeData: 'RIMEDIC://APT/SCAN-RIM-10492/user-ahmed-01',
    createdAt: '2026-09-27T10:00:00Z'
  },
  {
    id: 'apt-a-02',
    referenceNumber: 'SCAN-RIM-09821',
    patientId: 'user-ahmed-01',
    patientName: 'Ahmed Ould Cheikh',
    patientPhone: '+222 45 11 22 33',
    patientNni: '2840••••31',
    practitionerId: 'dr-kane',
    practitionerName: 'Dr Kane',
    practitionerSpecialty: 'Chirurgien-dentiste',
    practitionerSpecialtyAr: 'طبيب أسنان',
    establishmentId: 'cabinet-nejah-orthodontie',
    establishmentName: 'Cabinet Dentaire Dr Kane · Ksar',
    establishmentAddress: 'Avenue Gamal Abdel Nasser, Ksar',
    date: '2026-08-14',
    dateFormatted: '14 Août 2026',
    time: '10:00',
    fee: 1200,
    reason: 'Détartrage & Contrôle annuel',
    reasonAr: 'تنظيف أسنان وفحص سنوي',
    status: 'completed',
    insuranceType: 'CNAM',
    insuranceCoveragePercent: 80,
    cnamAmount: 960,
    patientAmount: 240,
    qrCodeData: 'RIMEDIC://APT/SCAN-RIM-09821/user-ahmed-01',
    createdAt: '2026-08-10T14:30:00Z'
  }
];

export const TEST_APPOINTMENTS_B: Appointment[] = [
  {
    id: 'apt-b-01',
    referenceNumber: 'SCAN-RIM-88301',
    patientId: 'user-mariem-02',
    patientName: 'Mariem Mint Bilal',
    patientPhone: '+222 36 99 88 77',
    patientNni: '5920••••21',
    practitionerId: 'dr-fatimetou-mint-salem',
    practitionerName: 'Centre Mère et Enfant (Sabah)',
    practitionerSpecialty: 'Service Pédiatrie · Nouakchott',
    practitionerSpecialtyAr: 'قسم الأطفال',
    establishmentId: 'hopital-sabah',
    establishmentName: 'Centre Hospitalier Mère et Enfant',
    establishmentAddress: 'Tevragh Zeina, Nouakchott',
    date: '2026-10-12',
    dateFormatted: 'Lun. 12 Octobre 2026',
    time: '11:15',
    fee: 1000,
    reason: 'Consultation pédiatrique de contrôle',
    reasonAr: 'كشف أطفال دوري',
    status: 'confirmed',
    insuranceType: 'CNASS',
    insuranceCoveragePercent: 90,
    cnamAmount: 900,
    patientAmount: 100,
    qrCodeData: 'RIMEDIC://APT/SCAN-RIM-88301/user-mariem-02',
    createdAt: '2026-09-28T09:00:00Z'
  }
];

// Initial empty patient for clean multi-user dynamic authentication
export const INITIAL_PATIENT: PatientProfile = EMPTY_PATIENT;
export const INITIAL_APPOINTMENTS: Appointment[] = [];

export const DEFAULT_PRACTITIONER_SCHEDULE: PractitionerScheduleDay[] = [
  {
    dayOfWeek: 1, // Lundi
    dayName: 'Lundi',
    dayNameAr: 'الإثنين',
    active: true,
    morningStart: '08:30',
    morningEnd: '13:00',
    hasLunchBreak: true,
    lunchStart: '13:00',
    lunchEnd: '15:00',
    afternoonStart: '15:00',
    afternoonEnd: '18:30',
  },
  {
    dayOfWeek: 2, // Mardi
    dayName: 'Mardi',
    dayNameAr: 'الثلاثاء',
    active: true,
    morningStart: '08:30',
    morningEnd: '13:00',
    hasLunchBreak: true,
    lunchStart: '13:00',
    lunchEnd: '15:00',
    afternoonStart: '15:00',
    afternoonEnd: '18:30',
  },
  {
    dayOfWeek: 3, // Mercredi
    dayName: 'Mercredi',
    dayNameAr: 'الأربعاء',
    active: true,
    morningStart: '08:30',
    morningEnd: '13:00',
    hasLunchBreak: true,
    lunchStart: '13:00',
    lunchEnd: '15:00',
    afternoonStart: '15:00',
    afternoonEnd: '18:30',
  },
  {
    dayOfWeek: 4, // Jeudi
    dayName: 'Jeudi',
    dayNameAr: 'الخميس',
    active: true,
    morningStart: '08:30',
    morningEnd: '13:00',
    hasLunchBreak: true,
    lunchStart: '13:00',
    lunchEnd: '15:00',
    afternoonStart: '15:00',
    afternoonEnd: '18:30',
  },
  {
    dayOfWeek: 5, // Vendredi
    dayName: 'Vendredi',
    dayNameAr: 'الجمعة',
    active: true,
    morningStart: '08:30',
    morningEnd: '12:00',
    hasLunchBreak: true,
    lunchStart: '12:00',
    lunchEnd: '15:30',
    afternoonStart: '15:30',
    afternoonEnd: '18:00',
  },
  {
    dayOfWeek: 6, // Samedi
    dayName: 'Samedi',
    dayNameAr: 'السبت',
    active: true,
    morningStart: '09:00',
    morningEnd: '14:00',
    hasLunchBreak: false,
    lunchStart: '14:00',
    lunchEnd: '14:00',
    afternoonStart: '14:00',
    afternoonEnd: '14:00',
  },
  {
    dayOfWeek: 0, // Dimanche
    dayName: 'Dimanche',
    dayNameAr: 'الأحد',
    active: false,
    morningStart: '09:00',
    morningEnd: '13:00',
    hasLunchBreak: false,
    lunchStart: '13:00',
    lunchEnd: '15:00',
    afternoonStart: '15:00',
    afternoonEnd: '18:00',
  },
];

export const DEFAULT_PRACTITIONER_PROFILE: PractitionerProfileData = {
  id: 'dr-mohamed-ould-ahmed',
  firstName: 'Mohamed',
  lastName: 'Ould Ahmed',
  title: 'Dr Mohamed Ould Ahmed',
  titleAr: 'د. محمد ولد أحمد',
  phone: '+222 45 25 00 12',
  email: 'dr.mohamed@ibnsina.mr',
  specialtyId: 'odontologie',
  specialtyName: 'Odontologie & Orthodontie',
  specialtyNameAr: 'طب وجراحة وتقويم الأسنان',
  establishmentId: 'clinique-ibn-sina',
  establishmentName: 'Clinique Ibn Sina',
  establishmentNameAr: 'عيادة ابن سينا',
  city: 'Nouakchott',
  neighborhood: 'Tevragh Zeina',
  fee: 1500,
  cnamConventioned: true,
  cnassConventioned: true,
  orderNumber: 'ONMM-2018-0419',
  experienceYears: 12,
  bio: "Spécialiste chevronné en orthodontie pédiatrique et adulte à Nouakchott. Équipé des technologies d'imagerie 3D et d'aligneurs transparents au sein de la Clinique Ibn Sina.",
  bioAr: 'أخصائي متميز في تقويم الأسنان للأطفال والبالغين في نواكشوط. مجهز بأحدث تقنيات التصوير ثلاثي الأبعاد وتقويم الأسنان الشفاف داخل عيادة ابن سينا.',
  education: 'Diplômé de la Faculté de Médecine Dentaire • Spécialisation en Orthodontie & Orthopédie Dento-Faciale',
  educationAr: 'خريج كلية طب الأسنان • تخصص دقيق في تقويم وتجميل الأسنان والفكين',
  languages: ['Arabe (Hassaniya)', 'Français', 'Poular'],
  slotDurationMinutes: 30,
  autoAcceptAppointments: true,
  allowEmergencyWalkins: true,
  smsRemindersEnabled: true,
  teleconsultationEnabled: false,
  schedule: DEFAULT_PRACTITIONER_SCHEDULE,
};

export const INITIAL_PRACTITIONER_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-dr-01',
    referenceNumber: 'SCAN-RIM-89412',
    patientId: 'patient-fatimetou-01',
    patientName: 'Fatimetou Mint Mohamed',
    patientPhone: '+222 45 25 88 99',
    patientNni: '8941••••12',
    practitionerId: 'dr-mohamed-ould-ahmed',
    practitionerName: 'Dr Mohamed Ould Ahmed',
    practitionerSpecialty: 'Odontologie & Orthodontie',
    practitionerSpecialtyAr: 'طب وجراحة الأسنان',
    establishmentId: 'clinique-ibn-sina',
    establishmentName: 'Clinique Ibn Sina',
    establishmentAddress: 'Tevragh Zeina, Rue 42-015, Nouakchott',
    date: '2026-10-07',
    dateFormatted: 'Mer. 07 Octobre 2026',
    time: '09:00',
    fee: 1500,
    reason: 'Activation appareil multi-attache',
    reasonAr: 'تعديل وتقويم الأسنان',
    status: 'confirmed',
    insuranceType: 'CNAM',
    insuranceCoveragePercent: 80,
    cnamAmount: 1200,
    patientAmount: 300,
    qrCodeData: 'RIMEDIC://APT/SCAN-RIM-89412/dr-mohamed-ould-ahmed',
    createdAt: '2026-10-01T10:00:00Z'
  },
  {
    id: 'apt-dr-02',
    referenceNumber: 'SCAN-RIM-91823',
    patientId: 'patient-oumar-02',
    patientName: 'Oumar Ba',
    patientPhone: '+222 36 12 34 56',
    patientNni: '4410••••77',
    practitionerId: 'dr-mohamed-ould-ahmed',
    practitionerName: 'Dr Mohamed Ould Ahmed',
    practitionerSpecialty: 'Odontologie & Orthodontie',
    practitionerSpecialtyAr: 'طب وجراحة الأسنان',
    establishmentId: 'clinique-ibn-sina',
    establishmentName: 'Clinique Ibn Sina',
    establishmentAddress: 'Tevragh Zeina, Rue 42-015, Nouakchott',
    date: '2026-10-07',
    dateFormatted: 'Mer. 07 Octobre 2026',
    time: '10:00',
    fee: 1500,
    reason: 'Bilan orthodontique annuel',
    reasonAr: 'فحص تقويم الأسنان السنوي',
    status: 'confirmed',
    insuranceType: 'CNAM',
    insuranceCoveragePercent: 80,
    cnamAmount: 1200,
    patientAmount: 300,
    qrCodeData: 'RIMEDIC://APT/SCAN-RIM-91823/dr-mohamed-ould-ahmed',
    createdAt: '2026-10-02T11:00:00Z'
  },
  {
    id: 'apt-dr-03',
    referenceNumber: 'SCAN-RIM-77192',
    patientId: 'patient-ahmed-03',
    patientName: 'Ahmed Vall Ould Sidi',
    patientPhone: '+222 22 45 67 89',
    patientNni: '3901••••45',
    practitionerId: 'dr-mohamed-ould-ahmed',
    practitionerName: 'Dr Mohamed Ould Ahmed',
    practitionerSpecialty: 'Odontologie & Orthodontie',
    practitionerSpecialtyAr: 'طب وجراحة الأسنان',
    establishmentId: 'clinique-ibn-sina',
    establishmentName: 'Clinique Ibn Sina',
    establishmentAddress: 'Tevragh Zeina, Rue 42-015, Nouakchott',
    date: '2026-10-07',
    dateFormatted: 'Mer. 07 Octobre 2026',
    time: '15:30',
    fee: 1500,
    reason: 'Attache décollée (Urgence)',
    reasonAr: 'إصلاح طارئ لسلك التقويم',
    status: 'confirmed',
    insuranceType: 'CNASS',
    insuranceCoveragePercent: 90,
    cnamAmount: 1350,
    patientAmount: 150,
    qrCodeData: 'RIMEDIC://APT/SCAN-RIM-77192/dr-mohamed-ould-ahmed',
    createdAt: '2026-10-05T08:30:00Z'
  },
  {
    id: 'apt-dr-04',
    referenceNumber: 'SCAN-RIM-66401',
    patientId: 'patient-mariem-04',
    patientName: 'Mariem Mint Cheikh',
    patientPhone: '+222 46 78 90 12',
    patientNni: '1280••••88',
    practitionerId: 'dr-mohamed-ould-ahmed',
    practitionerName: 'Dr Mohamed Ould Ahmed',
    practitionerSpecialty: 'Odontologie & Orthodontie',
    practitionerSpecialtyAr: 'طب وجراحة الأسنان',
    establishmentId: 'clinique-ibn-sina',
    establishmentName: 'Clinique Ibn Sina',
    establishmentAddress: 'Tevragh Zeina, Rue 42-015, Nouakchott',
    date: '2026-10-08',
    dateFormatted: 'Jeu. 08 Octobre 2026',
    time: '11:00',
    fee: 1500,
    reason: 'Pose d\'arc supérieur et contrôle',
    reasonAr: 'تركيب وفحص تقويم علوي',
    status: 'pending',
    insuranceType: 'NONE',
    insuranceCoveragePercent: 0,
    cnamAmount: 0,
    patientAmount: 1500,
    qrCodeData: 'RIMEDIC://APT/SCAN-RIM-66401/dr-mohamed-ould-ahmed',
    createdAt: '2026-10-06T14:15:00Z'
  },
  {
    id: 'apt-dr-05',
    referenceNumber: 'SCAN-RIM-55210',
    patientId: 'patient-sidi-05',
    patientName: 'Sidi Mohamed Ould Cheikh',
    patientPhone: '+222 45 99 00 11',
    patientNni: '7721••••90',
    practitionerId: 'dr-mohamed-ould-ahmed',
    practitionerName: 'Dr Mohamed Ould Ahmed',
    practitionerSpecialty: 'Odontologie & Orthodontie',
    practitionerSpecialtyAr: 'طب وجراحة الأسنان',
    establishmentId: 'clinique-ibn-sina',
    establishmentName: 'Clinique Ibn Sina',
    establishmentAddress: 'Tevragh Zeina, Rue 42-015, Nouakchott',
    date: '2026-10-06',
    dateFormatted: 'Mar. 06 Octobre 2026',
    time: '16:00',
    fee: 1500,
    reason: 'Consultation de suivi semestriel',
    reasonAr: 'متابعة نصف سنوية',
    status: 'completed',
    insuranceType: 'CNAM',
    insuranceCoveragePercent: 80,
    cnamAmount: 1200,
    patientAmount: 300,
    qrCodeData: 'RIMEDIC://APT/SCAN-RIM-55210/dr-mohamed-ould-ahmed',
    createdAt: '2026-09-20T10:00:00Z'
  }
];

