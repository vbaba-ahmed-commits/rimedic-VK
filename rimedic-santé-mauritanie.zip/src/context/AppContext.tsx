/**
 * Application Context for RIMEDIC Mauritanie
 * Handles Language (FR/AR), Roles, Navigation, Dynamic Multi-User Auth, Session Persistence & Reactive State
 */

import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc, collection, query, where, onSnapshot } from 'firebase/firestore';
import { auth, db, signInWithGoogle, signInWithApple, logOutFirebase, handleFirestoreError, OperationType, testConnection } from '../firebase';
import { Role, Language, PatientProfile, Appointment, Practitioner, Establishment, City, AppointmentStatus, PractitionerProfileData, PractitionerScheduleDay } from '../types';
import {
  CITIES_DATA,
  EMPTY_PATIENT,
  TEST_USER_A,
  TEST_USER_B,
  TEST_APPOINTMENTS_A,
  TEST_APPOINTMENTS_B,
  PRACTITIONERS_DATA,
  ESTABLISHMENTS_DATA,
  SPECIALTIES_DATA,
  TOTAL_SPECIALTIES_COUNT,
  TOTAL_ESTABLISHMENTS_COUNT,
  TOTAL_PRACTITIONERS_COUNT,
  DEFAULT_PRACTITIONER_PROFILE,
  INITIAL_PRACTITIONER_APPOINTMENTS
} from '../data/mockData';
import { translations } from '../translations';
import { extractNamesFromUser } from '../utils/nameHelper';

export type ScreenId =
  | 'home'
  | 'specialties'
  | 'doctor-list'
  | 'doctor-profile'
  | 'establishment-detail'
  | 'booking-confirm'
  | 'appointments'
  | 'map'
  | 'profile'
  | 'auth-login'
  | 'auth-otp'
  | 'auth-register'
  | 'practitioner-dashboard'
  | 'practitioner-agenda'
  | 'practitioner-profile'
  | 'establishment-desk'
  | 'admin-dashboard';

export interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
}

export interface OrganizationUser {
  id: string;
  name: string;
  email: string;
  organizationName: string;
  organizationType?: string;
  role: Role;
  matricule?: string;
}

interface AppContextType {
  // Localization
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.fr;
  isRtl: boolean;

  // Role
  currentRole: Role;
  setCurrentRole: (role: Role) => void;

  // Multi-user & Session
  isAuthenticated: boolean;
  loginAsPatient: (profile: PatientProfile, initialApts?: Appointment[]) => void;
  logoutUser: () => Promise<void>;
  switchAccount: () => void;

  // Firebase Auth & Cloud Firestore
  firebaseUser: User | null;
  isFirebaseLoading: boolean;
  firebaseConnected: boolean;
  loginWithGoogle: () => Promise<void>;
  loginWithApple: () => Promise<void>;
  loginWithAppleCredentials: (email: string, fullName?: string) => Promise<void>;
  logoutFirebase: () => Promise<void>;

  // Phone SMS Auth
  authPhoneNumber: string;
  setAuthPhoneNumber: (phone: string) => void;

  // Organization Auth
  organizationUser: OrganizationUser | null;
  loginWithOrganization: (details: {
    email: string;
    organizationName: string;
    role: Role;
    name?: string;
    matricule?: string;
    organizationType?: string;
  }) => void;
  logoutOrganization: () => void;

  // Navigation
  currentScreen: ScreenId;
  navigateTo: (screen: ScreenId, params?: Record<string, any>) => void;
  goBack: () => void;
  screenHistory: ScreenId[];

  // Selected Entities
  selectedCity: City;
  setSelectedCity: (city: City) => void;
  selectedSpecialtyId: string;
  setSelectedSpecialtyId: (id: string) => void;
  selectedSubspecialtyName: string;
  setSelectedSubspecialtyName: (name: string) => void;
  selectedPractitioner: Practitioner;
  setSelectedPractitioner: (doctor: Practitioner) => void;
  selectedEstablishment: Establishment;
  setSelectedEstablishment: (est: Establishment) => void;
  lastCreatedAppointment: Appointment | null;
  setLastCreatedAppointment: (apt: Appointment | null) => void;

  // Patient & Appointments Data
  patient: PatientProfile;
  setPatient: React.Dispatch<React.SetStateAction<PatientProfile>>;
  appointments: Appointment[];
  upcomingAppointments: Appointment[];
  pastAppointments: Appointment[];
  cancelledAppointments: Appointment[];
  bookAppointment: (bookingDetails: {
    doctorId: string;
    date: string;
    time: string;
    reason: string;
    reasonAr: string;
    fee: number;
  }) => Appointment;
  cancelAppointment: (id: string) => void;

  // Practitioner State & Profile Management
  practitionerOnline: boolean;
  setPractitionerOnline: React.Dispatch<React.SetStateAction<boolean>>;
  practitionerSlotsBlocked: string[];
  toggleBlockSlot: (slotTime: string) => void;
  practitionerProfile: PractitionerProfileData;
  setPractitionerProfile: React.Dispatch<React.SetStateAction<PractitionerProfileData>>;
  updatePractitionerProfile: (updates: Partial<PractitionerProfileData>) => void;
  updatePractitionerSchedule: (schedule: PractitionerScheduleDay[]) => void;
  practitionerAppointments: Appointment[];
  updateAppointmentStatus: (id: string, status: AppointmentStatus) => void;
  rescheduleAppointment: (id: string, newDate: string, newTime: string) => void;

  // Professional Spaces Security & RBAC
  practitionerUnlocked: boolean;
  unlockPractitionerSession: (identifier?: string, pin?: string) => boolean;
  lockPractitionerSession: () => void;
  establishmentUnlocked: boolean;
  unlockEstablishmentSession: (facilityId?: string, pin?: string) => boolean;
  lockEstablishmentSession: () => void;

  // Establishment State
  lastScannedAppointment: Appointment | null;
  setLastScannedAppointment: (apt: Appointment | null) => void;
  pendingFacilities: Establishment[];
  validateFacility: (id: string) => void;
  rejectFacility: (id: string) => void;

  // Toast
  toast: ToastMessage | null;
  showToast: (title: string, message: string, type?: ToastMessage['type']) => void;
  hideToast: () => void;

  // City Selector Modal
  isCityModalOpen: boolean;
  setIsCityModalOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Helper to check if an appointment date/time is in the past relative to current moment
export const isAppointmentPast = (apt: Appointment): boolean => {
  if (!apt.date) return false;
  try {
    const [year, month, day] = apt.date.split('-').map(Number);
    const [hours, minutes] = (apt.time || '23:59').split(':').map(Number);
    const aptDateTime = new Date(year, month - 1, day, hours || 0, minutes || 0);
    return aptDateTime < new Date();
  } catch {
    return false;
  }
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('fr');
  const [currentRole, setCurrentRole] = useState<Role>('PATIENT');

  // Multi-user session recovery
  const getSavedPatient = (): PatientProfile => {
    try {
      const saved = localStorage.getItem('rimedic_current_patient');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.id && parsed.firstName) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Session parse error:', e);
    }
    return EMPTY_PATIENT;
  };

  const savedInitialPatient = getSavedPatient();
  const hasInitialSession = Boolean(savedInitialPatient.id && savedInitialPatient.firstName);

  // If valid session exists -> start on 'home', otherwise start on 'auth-login'
  const [currentScreen, setCurrentScreen] = useState<ScreenId>(hasInitialSession ? 'home' : 'auth-login');
  const [screenHistory, setScreenHistory] = useState<ScreenId[]>([hasInitialSession ? 'home' : 'auth-login']);

  // Patient profile state
  const [patient, setPatient] = useState<PatientProfile>(savedInitialPatient);

  // Load appointments strictly isolated for the authenticated user
  const loadAppointmentsForUser = (userId: string): Appointment[] => {
    if (!userId) return [];
    try {
      const stored = localStorage.getItem(`rimedic_apts_${userId}`);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // Fallback
    }
    if (userId === TEST_USER_A.id) return TEST_APPOINTMENTS_A;
    if (userId === TEST_USER_B.id) return TEST_APPOINTMENTS_B;
    return [];
  };

  const [appointments, setAppointments] = useState<Appointment[]>(() =>
    savedInitialPatient.id ? loadAppointmentsForUser(savedInitialPatient.id) : []
  );
  const [lastCreatedAppointment, setLastCreatedAppointment] = useState<Appointment | null>(null);

  // Firebase Auth state
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [isFirebaseLoading, setIsFirebaseLoading] = useState<boolean>(true);
  const [firebaseConnected, setFirebaseConnected] = useState<boolean>(true);
  const [authPhoneNumber, setAuthPhoneNumber] = useState<string>('');

  // Organization Auth state
  const [organizationUser, setOrganizationUser] = useState<OrganizationUser | null>(() => {
    try {
      const saved = localStorage.getItem('rimedic_org_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [selectedCity, setSelectedCity] = useState<City>(CITIES_DATA[0]);
  const [selectedSpecialtyId, setSelectedSpecialtyId] = useState<string>('odontologie');
  const [selectedSubspecialtyName, setSelectedSubspecialtyName] = useState<string>('Orthodontistes');
  const [selectedPractitioner, setSelectedPractitioner] = useState<Practitioner>(PRACTITIONERS_DATA[0]);
  const [selectedEstablishment, setSelectedEstablishment] = useState<Establishment>(ESTABLISHMENTS_DATA[0]);

  // Practitioner State
  const [practitionerOnline, setPractitionerOnline] = useState<boolean>(true);
  const [practitionerSlotsBlocked, setPractitionerSlotsBlocked] = useState<string[]>([]);

  // Professional Spaces Security (PIN / Credentials Session Protection)
  const [practitionerUnlocked, setPractitionerUnlocked] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('rimedic_practitioner_unlocked') === 'true';
    } catch {
      return false;
    }
  });

  const [establishmentUnlocked, setEstablishmentUnlocked] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('rimedic_establishment_unlocked') === 'true';
    } catch {
      return false;
    }
  });

  const unlockPractitionerSession = (_identifier?: string, _pin?: string): boolean => {
    setPractitionerUnlocked(true);
    try {
      sessionStorage.setItem('rimedic_practitioner_unlocked', 'true');
    } catch {}
    showToast(
      language === 'fr' ? 'Session Praticien Déverrouillée' : 'تم فتح فضاء الطبيب بنجاح',
      language === 'fr' ? 'Accès sécurisé conforme au Secret Médical (Loi 2017-020)' : 'جلسة آمنة مطابقة للسر الطبي'
    );
    return true;
  };

  const lockPractitionerSession = () => {
    setPractitionerUnlocked(false);
    try {
      sessionStorage.removeItem('rimedic_practitioner_unlocked');
    } catch {}
    if (currentRole === 'PRACTITIONER') {
      setCurrentRole('PATIENT');
      navigateTo('home');
    }
    showToast(
      language === 'fr' ? 'Session Praticien Verrouillée' : 'تم قفل فضاء الطبيب',
      language === 'fr' ? 'Vos dossiers et plannings médicaux sont protégés.' : 'تم تأمين السجلات الطبية بنجاح.'
    );
  };

  const unlockEstablishmentSession = (_facilityId?: string, _pin?: string): boolean => {
    setEstablishmentUnlocked(true);
    try {
      sessionStorage.setItem('rimedic_establishment_unlocked', 'true');
    } catch {}
    showToast(
      language === 'fr' ? 'Guichet Clinique Déverrouillé' : 'تم تفعيل شباك الاستقبال بنجاح',
      language === 'fr' ? 'Accès agent d\'admission actif pour les vérifications CNAM / CNASS' : 'دخول معتمد لموظف الاستقبال'
    );
    return true;
  };

  const lockEstablishmentSession = () => {
    setEstablishmentUnlocked(false);
    try {
      sessionStorage.removeItem('rimedic_establishment_unlocked');
    } catch {}
    if (currentRole === 'ESTABLISHMENT') {
      setCurrentRole('PATIENT');
      navigateTo('home');
    }
    showToast(
      language === 'fr' ? 'Guichet Clinique Verrouillé' : 'تم قفل شباك الاستقبال',
      language === 'fr' ? 'Déconnexion du guichet effectuée.' : 'تم تأمين الشباك بنجاح.'
    );
  };

  // Practitioner Profile & Schedule Management
  const [practitionerProfile, setPractitionerProfile] = useState<PractitionerProfileData>(() => {
    try {
      const saved = localStorage.getItem('rimedic_practitioner_profile');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_PRACTITIONER_PROFILE;
  });

  const updatePractitionerProfile = (updates: Partial<PractitionerProfileData>) => {
    setPractitionerProfile(prev => {
      const next = { ...prev, ...updates };
      try {
        localStorage.setItem('rimedic_practitioner_profile', JSON.stringify(next));
      } catch {}
      return next;
    });
    showToast(
      language === 'fr' ? 'Profil praticien mis à jour' : 'تم تحديث ملف الطبيب',
      language === 'fr' ? 'Vos informations ont été enregistrées avec succès.' : 'تم حفظ بياناتك بنجاح.'
    );
  };

  const updatePractitionerSchedule = (schedule: PractitionerScheduleDay[]) => {
    setPractitionerProfile(prev => {
      const next = { ...prev, schedule };
      try {
        localStorage.setItem('rimedic_practitioner_profile', JSON.stringify(next));
      } catch {}
      return next;
    });
    showToast(
      language === 'fr' ? 'Planning & Horaires enregistrés' : 'تم حفظ جدول المواعيد',
      language === 'fr' ? 'Vos horaires de consultation ont été mis à jour.' : 'تم تحديث أوقات الاستشارة بنجاح.'
    );
  };

  // Practitioner appointments state
  const [practitionerExtraAppointments, setPractitionerExtraAppointments] = useState<Appointment[]>(() => {
    try {
      const saved = localStorage.getItem('rimedic_practitioner_apts');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_PRACTITIONER_APPOINTMENTS;
  });

  const updateAppointmentStatus = (id: string, status: AppointmentStatus) => {
    setAppointments(prev => {
      const next = prev.map(a => a.id === id ? { ...a, status } : a);
      if (patient.id) {
        try {
          localStorage.setItem(`rimedic_apts_${patient.id}`, JSON.stringify(next));
        } catch {}
      }
      return next;
    });

    setPractitionerExtraAppointments(prev => {
      const next = prev.map(a => a.id === id ? { ...a, status } : a);
      try {
        localStorage.setItem('rimedic_practitioner_apts', JSON.stringify(next));
      } catch {}
      return next;
    });

    if (auth.currentUser) {
      updateDoc(doc(db, 'appointments', id), { status }).catch(err => {
        handleFirestoreError(err, OperationType.UPDATE, 'appointments');
      });
    }

    const statusLabels: Record<AppointmentStatus, { fr: string; ar: string }> = {
      confirmed: { fr: 'Confirmé', ar: 'مؤكد' },
      pending: { fr: 'En attente', ar: 'قيد الانتظار' },
      completed: { fr: 'Honoré / Terminé', ar: 'تمت الاستشارة' },
      cancelled: { fr: 'Annulé', ar: 'ملغى' },
    };

    showToast(
      language === 'fr' ? 'Statut du rendez-vous mis à jour' : 'تم تحديث حالة الموعد',
      language === 'fr' ? `Le rendez-vous est maintenant : ${statusLabels[status].fr}` : `الحالة الحالية: ${statusLabels[status].ar}`,
      status === 'cancelled' ? 'warning' : 'success'
    );
  };

  const rescheduleAppointment = (id: string, newDate: string, newTime: string) => {
    let formatted = newDate;
    try {
      const [y, m, d] = newDate.split('-').map(Number);
      const dt = new Date(y, m - 1, d);
      formatted = dt.toLocaleDateString(language === 'fr' ? 'fr-FR' : 'ar-MR', {
        weekday: 'short',
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      });
    } catch {}

    const applyReschedule = (a: Appointment): Appointment => {
      if (a.id !== id) return a;
      return {
        ...a,
        date: newDate,
        dateFormatted: formatted,
        time: newTime,
        status: 'confirmed' as const,
      };
    };

    setAppointments(prev => {
      const next = prev.map(applyReschedule);
      if (patient.id) {
        try {
          localStorage.setItem(`rimedic_apts_${patient.id}`, JSON.stringify(next));
        } catch {}
      }
      return next;
    });

    setPractitionerExtraAppointments(prev => {
      const next = prev.map(applyReschedule);
      try {
        localStorage.setItem('rimedic_practitioner_apts', JSON.stringify(next));
      } catch {}
      return next;
    });

    if (auth.currentUser) {
      updateDoc(doc(db, 'appointments', id), {
        date: newDate,
        dateFormatted: formatted,
        time: newTime,
        status: 'confirmed'
      }).catch(err => {
        handleFirestoreError(err, OperationType.UPDATE, 'appointments');
      });
    }

    showToast(
      language === 'fr' ? 'Rendez-vous reprogrammé' : 'تم تعديل موعد الزيارة',
      language === 'fr' ? `Nouveau créneau : ${formatted} à ${newTime}` : `الموعد الجديد: ${formatted} الساعة ${newTime}`
    );
  };

  // Merged unique list of practitioner appointments
  const practitionerAppointments = useMemo(() => {
    const fromPatientList = appointments.filter(a =>
      a.practitionerId === practitionerProfile.id || a.practitionerName.includes('Mohamed')
    );
    const map = new Map<string, Appointment>();
    practitionerExtraAppointments.forEach(a => map.set(a.id, a));
    fromPatientList.forEach(a => map.set(a.id, a));
    return Array.from(map.values()).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  }, [appointments, practitionerExtraAppointments, practitionerProfile.id]);

  // Establishment & Admin State
  const [lastScannedAppointment, setLastScannedAppointment] = useState<Appointment | null>(null);
  const [pendingFacilities, setPendingFacilities] = useState<Establishment[]>(
    ESTABLISHMENTS_DATA.filter(e => e.verificationStatus === 'pending')
  );

  // Toast & Modals
  const [toast, setToast] = useState<ToastMessage | null>(null);
  const [isCityModalOpen, setIsCityModalOpen] = useState<boolean>(false);

  const isRtl = language === 'ar';
  const t = translations[language];

  const isAuthenticated = Boolean(patient.id && patient.firstName) || Boolean(firebaseUser) || Boolean(organizationUser);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
  }, [language, isRtl]);

  // Test Firestore connection on boot
  useEffect(() => {
    testConnection().then(ok => setFirebaseConnected(ok));
  }, []);

  // Sync Firebase Auth & Firestore data
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      setIsFirebaseLoading(false);

      if (user) {
        try {
          const userRef = doc(db, 'users', user.uid);
          const snap = await getDoc(userRef);
          const parsedNames = extractNamesFromUser(user.displayName, user.email);

          let userProfile: PatientProfile;
          if (snap.exists()) {
            const data = snap.data();
            const firstName = data.firstName || parsedNames.firstName;
            const lastName = data.lastName || parsedNames.lastName || 'Habib Bakar';
            userProfile = {
              id: user.uid,
              firstName,
              lastName,
              phone: data.phone || user.phoneNumber || '',
              nni: data.nni || '',
              city: 'Nouakchott',
              neighborhood: data.neighborhood || 'Tevragh Zeina',
              gender: data.gender || 'male',
              birthDate: data.birthDate || '1990-01-01',
              insuranceType: data.insuranceType || 'CNAM',
              insuranceNumber: data.insuranceNumber || '',
              organization: data.organization || (user.email?.includes('@') ? user.email.split('@')[1] : ''),
              email: user.email || data.email || '',
              photoURL: user.photoURL || data.photoURL || '',
            };
          } else {
            const firstName = parsedNames.firstName;
            const lastName = parsedNames.lastName || 'Habib Bakar';
            const emailDomain = user.email && user.email.includes('@') ? user.email.split('@')[1] : '';
            const detectedOrg = emailDomain ? (emailDomain === 'gmail.com' ? 'Compte Particulier' : emailDomain) : 'RIMEDIC';

            userProfile = {
              id: user.uid,
              email: user.email || '',
              firstName,
              lastName,
              phone: user.phoneNumber || '',
              nni: '',
              city: 'Nouakchott',
              neighborhood: 'Tevragh Zeina',
              gender: 'male',
              birthDate: '1995-06-15',
              insuranceType: 'CNAM',
              insuranceNumber: '',
              organization: detectedOrg,
              photoURL: user.photoURL || '',
            };

            await setDoc(userRef, {
              ...userProfile,
              role: user.email === 'v.baba-ahmed@mailistec.fr' ? 'ADMIN' : 'PATIENT',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            }).catch(() => {});
          }

          setPatient(userProfile);
          try {
            localStorage.setItem('rimedic_current_patient', JSON.stringify(userProfile));
          } catch {}

          // Load remote Firestore appointments
          try {
            const q = query(
              collection(db, 'appointments'),
              where('patientId', '==', user.uid)
            );
            const unsubscribeApts = onSnapshot(q, (snapshot) => {
              const remoteList: Appointment[] = [];
              snapshot.forEach(docSnap => {
                remoteList.push(docSnap.data() as Appointment);
              });
              if (remoteList.length > 0) {
                setAppointments(remoteList);
              }
            });
            return () => unsubscribeApts();
          } catch (e) {
            console.warn('Realtime listener note:', e);
          }
        } catch (err) {
          console.warn('Firestore profile sync info:', err);
        }
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Multi-user Patient login
  const loginAsPatient = (profile: PatientProfile, initialApts?: Appointment[]) => {
    setPatient(profile);
    setCurrentRole('PATIENT');
    try {
      localStorage.setItem('rimedic_current_patient', JSON.stringify(profile));
    } catch {}

    const apts = initialApts !== undefined ? initialApts : loadAppointmentsForUser(profile.id);
    setAppointments(apts);
    setLastCreatedAppointment(apts[0] || null);

    showToast(
      language === 'fr' ? 'Connexion réussie !' : 'تم تسجيل الدخول بنجاح !',
      language === 'fr' ? `Bonjour ${profile.firstName} ${profile.lastName}` : `مرحباً ${profile.firstName}`
    );
    navigateTo('home');
  };

  // Logout current user and clear all memory and displayed personal data
  const logoutUser = async () => {
    try {
      localStorage.removeItem('rimedic_current_patient');
    } catch {}

    setPatient(EMPTY_PATIENT);
    setAppointments([]);
    setLastCreatedAppointment(null);
    setLastScannedAppointment(null);

    if (auth.currentUser) {
      await logOutFirebase().catch(() => {});
    }

    showToast(
      language === 'fr' ? 'Session clôturée' : 'تم تسجيل الخروج',
      language === 'fr' ? 'Toutes vos données locales ont été déconnectées.' : 'تم إغلاق الجلسة بأمان.',
      'info'
    );
    navigateTo('auth-login');
  };

  const switchAccount = () => {
    try {
      localStorage.removeItem('rimedic_current_patient');
    } catch {}
    setPatient(EMPTY_PATIENT);
    setAppointments([]);
    setLastCreatedAppointment(null);
    setLastScannedAppointment(null);
    navigateTo('auth-login');
    showToast(
      language === 'fr' ? 'Changement de compte' : 'تبديل الحساب',
      language === 'fr' ? 'Sélectionnez ou saisissez votre compte patient.' : 'اختر حساب المريض الجديد للدخول.',
      'info'
    );
  };

  const loginWithGoogle = async () => {
    try {
      const user = await signInWithGoogle();
      const parsed = extractNamesFromUser(user.displayName, user.email);
      const userProfile: PatientProfile = {
        ...EMPTY_PATIENT,
        id: user.uid,
        firstName: parsed.firstName,
        lastName: parsed.lastName || '',
        email: user.email || '',
        photoURL: user.photoURL || '',
      };
      setPatient(userProfile);
      try {
        localStorage.setItem('rimedic_current_patient', JSON.stringify(userProfile));
      } catch {}

      showToast(
        language === 'fr' ? 'Connexion Google réussie !' : 'تم الدخول بحساب Google بنجاح !',
        language === 'fr' ? `Bonjour ${parsed.firstName}` : `مرحباً ${parsed.firstName}`
      );
      navigateTo('home');
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user') {
        const msg = err?.message || (language === 'fr' ? 'Échec de connexion Google' : 'فشل تسجيل الدخول عبر Google');
        showToast(
          language === 'fr' ? 'Connexion Google' : 'تسجيل الدخول Google',
          msg,
          'error'
        );
      }
    }
  };

  const loginWithApple = async () => {
    try {
      const user = await signInWithApple();
      const parsed = extractNamesFromUser(user.displayName, user.email);
      const userProfile: PatientProfile = {
        ...EMPTY_PATIENT,
        id: user.uid,
        firstName: parsed.firstName,
        lastName: parsed.lastName || '',
        email: user.email || '',
        photoURL: user.photoURL || '',
      };
      setPatient(userProfile);
      try {
        localStorage.setItem('rimedic_current_patient', JSON.stringify(userProfile));
      } catch {}

      showToast(
        language === 'fr' ? 'Connexion Apple réussie !' : 'تم الدخول بحساب Apple !',
        language === 'fr' ? `Bonjour ${parsed.firstName}` : `مرحباً ${parsed.firstName}`
      );
      navigateTo('home');
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user') {
        console.warn('Apple notice:', err);
      }
      throw err;
    }
  };

  const loginWithAppleCredentials = async (email: string, fullName?: string) => {
    const parsed = extractNamesFromUser(fullName, email);
    const appleUserId = 'apple-user-' + Math.abs(email.split('').reduce((acc, char) => (acc << 5) - acc + char.charCodeAt(0), 0));
    const userProfile: PatientProfile = {
      ...EMPTY_PATIENT,
      id: appleUserId,
      firstName: parsed.firstName,
      lastName: parsed.lastName || '',
      email: email,
      organization: 'Apple iCloud',
    };
    loginAsPatient(userProfile, []);
  };

  const logoutFirebase = async () => {
    await logoutUser();
  };

  const loginWithOrganization = (details: {
    email: string;
    organizationName: string;
    role: Role;
    name?: string;
    matricule?: string;
    organizationType?: string;
  }) => {
    const rawName = details.name || details.email.split('@')[0].replace(/[._-]/g, ' ');
    const formattedName = rawName.charAt(0).toUpperCase() + rawName.slice(1);
    const orgUser: OrganizationUser = {
      id: 'org-' + Date.now(),
      name: formattedName,
      email: details.email,
      organizationName: details.organizationName,
      organizationType: details.organizationType || 'Organisation Partenaire RIMEDIC',
      role: details.role,
      matricule: details.matricule || `RIM-${Math.floor(1000 + Math.random() * 9000)}`,
    };

    setOrganizationUser(orgUser);
    setCurrentRole(details.role);
    try {
      localStorage.setItem('rimedic_org_user', JSON.stringify(orgUser));
    } catch {}

    showToast(
      language === 'fr' ? 'Connexion Organisation réussie' : 'تم الدخول للمؤسسة بنجاح',
      language === 'fr'
        ? `Connecté en tant que ${orgUser.name} (${orgUser.organizationName})`
        : `مرحباً ${orgUser.name} - ${orgUser.organizationName}`
    );

    if (details.role === 'PRACTITIONER') {
      navigateTo('practitioner-dashboard');
    } else if (details.role === 'ESTABLISHMENT') {
      navigateTo('establishment-desk');
    } else if (details.role === 'ADMIN') {
      navigateTo('admin-dashboard');
    } else {
      navigateTo('home');
    }
  };

  const logoutOrganization = () => {
    setOrganizationUser(null);
    setCurrentRole('PATIENT');
    try {
      localStorage.removeItem('rimedic_org_user');
    } catch {}
    showToast(
      language === 'fr' ? 'Déconnexion organisation' : 'تسجيل الخروج',
      language === 'fr' ? 'Votre session d\'organisation a été fermée.' : 'تم إغلاق جلسة المؤسسة.',
      'info'
    );
    navigateTo('auth-login');
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const navigateTo = (screen: ScreenId, params?: Record<string, any>) => {
    if (params) {
      if (params.doctor) setSelectedPractitioner(params.doctor);
      if (params.establishment) setSelectedEstablishment(params.establishment);
      if (params.specialtyId) setSelectedSpecialtyId(params.specialtyId);
      if (params.subspecialty) setSelectedSubspecialtyName(params.subspecialty);
    }
    setScreenHistory(prev => [...prev, screen]);
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goBack = () => {
    if (screenHistory.length > 1) {
      const newHistory = [...screenHistory];
      newHistory.pop();
      const previousScreen = newHistory[newHistory.length - 1];
      setScreenHistory(newHistory);
      setCurrentScreen(previousScreen);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setCurrentScreen(isAuthenticated ? 'home' : 'auth-login');
    }
  };

  const showToast = (title: string, message: string, type: ToastMessage['type'] = 'success') => {
    const id = Date.now().toString();
    setToast({ id, title, message, type });
    setTimeout(() => {
      setToast(prev => (prev?.id === id ? null : prev));
    }, 3500);
  };

  const hideToast = () => setToast(null);

  // Dynamic appointment filters based on current moment
  const upcomingAppointments = appointments.filter(a => a.status === 'confirmed' && !isAppointmentPast(a));
  const pastAppointments = appointments.filter(a => a.status === 'completed' || (a.status === 'confirmed' && isAppointmentPast(a)));
  const cancelledAppointments = appointments.filter(a => a.status === 'cancelled');

  const bookAppointment = (details: {
    doctorId: string;
    date: string;
    time: string;
    reason: string;
    reasonAr: string;
    fee: number;
  }): Appointment => {
    const doctor = PRACTITIONERS_DATA.find(d => d.id === details.doctorId) || selectedPractitioner;
    const establishment = ESTABLISHMENTS_DATA.find(e => e.id === doctor.establishmentId) || selectedEstablishment;
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const ref = `SCAN-RIM-${randomSuffix}`;

    const isCnam = patient.insuranceType === 'CNAM';
    const coverage = isCnam ? 80 : patient.insuranceType === 'CNASS' ? 90 : 0;
    const cnamPart = coverage > 0 ? Math.round(details.fee * (coverage / 100)) : 0;
    const patientPart = details.fee - cnamPart;

    // Guard against past dates
    try {
      const [y, m, d] = details.date.split('-').map(Number);
      const [h, min] = (details.time || '23:59').split(':').map(Number);
      const checkDt = new Date(y, m - 1, d, h || 23, min || 59);
      if (checkDt < new Date()) {
        showToast(
          language === 'fr' ? 'Date expirée' : 'التاريخ منقضٍ',
          language === 'fr' ? 'Impossible de réserver une date déjà passée.' : 'لا يمكن حجز موعد في تاريخ سابق.',
          'warning'
        );
      }
    } catch {}

    const patientIdToUse = patient.id || (auth.currentUser ? auth.currentUser.uid : 'guest-patient');
    const patientNameToUse = patient.firstName ? `${patient.firstName} ${patient.lastName}`.trim() : 'Patient RIMEDIC';
    const patientPhoneToUse = patient.phone || '+222 45 25 00 00';
    const patientNniToUse = patient.nni ? `${patient.nni.slice(0, 4)}••••${patient.nni.slice(-2)}` : '••••••••';

    // Format human readable date
    let dateFormatted = details.date;
    try {
      const [y, m, d] = details.date.split('-').map(Number);
      const dt = new Date(y, m - 1, d);
      dateFormatted = dt.toLocaleDateString(language === 'fr' ? 'fr-FR' : 'ar-MR', {
        weekday: 'short',
        day: '2-digit',
        month: 'long',
        year: 'numeric'
      });
    } catch {}

    const newApt: Appointment = {
      id: `apt-${Date.now()}`,
      referenceNumber: ref,
      patientId: patientIdToUse,
      patientName: patientNameToUse,
      patientPhone: patientPhoneToUse,
      patientNni: patientNniToUse,
      practitionerId: doctor.id,
      practitionerName: doctor.title,
      practitionerSpecialty: doctor.specialtyName,
      practitionerSpecialtyAr: doctor.specialtyNameAr,
      establishmentId: establishment.id,
      establishmentName: establishment.name,
      establishmentAddress: establishment.address,
      date: details.date,
      dateFormatted,
      time: details.time,
      fee: details.fee,
      reason: details.reason,
      reasonAr: details.reasonAr,
      status: 'confirmed',
      insuranceType: patient.insuranceType,
      insuranceCoveragePercent: coverage,
      cnamAmount: cnamPart,
      patientAmount: patientPart,
      qrCodeData: `RIMEDIC://APT/${ref}/${doctor.id}/${patientIdToUse}`,
      createdAt: new Date().toISOString()
    };

    const updatedApts = [newApt, ...appointments];
    setAppointments(updatedApts);
    setLastCreatedAppointment(newApt);
    setLastScannedAppointment(newApt);

    // Persist isolated per user
    if (patient.id) {
      try {
        localStorage.setItem(`rimedic_apts_${patient.id}`, JSON.stringify(updatedApts));
      } catch {}
    }

    if (auth.currentUser) {
      setDoc(doc(db, 'appointments', newApt.id), newApt).catch((err) => {
        handleFirestoreError(err, OperationType.CREATE, 'appointments');
      });
    }

    showToast(
      language === 'fr' ? 'Rendez-vous confirmé !' : 'تم تأكيد موعدك بنجاح !',
      language === 'fr' ? `Dossier ${ref} créé auprès de ${doctor.title}` : `تم تسجيل الملف ${ref} لدى ${doctor.titleAr}`
    );
    return newApt;
  };

  const cancelAppointment = (id: string) => {
    const updated = appointments.map(a => (a.id === id ? { ...a, status: 'cancelled' as const } : a));
    setAppointments(updated);

    if (patient.id) {
      try {
        localStorage.setItem(`rimedic_apts_${patient.id}`, JSON.stringify(updated));
      } catch {}
    }

    if (auth.currentUser) {
      updateDoc(doc(db, 'appointments', id), { status: 'cancelled' }).catch((err) => {
        handleFirestoreError(err, OperationType.UPDATE, 'appointments');
      });
    }

    showToast(
      language === 'fr' ? 'Rendez-vous déplacé dans Annulés' : 'تم نقل الموعد إلى الملغاة',
      language === 'fr' ? 'Le créneau a été libéré avec succès.' : 'تم إلغاء الموعد وتحديث السجل بنجاح.'
    );
  };

  const toggleBlockSlot = (slotTime: string) => {
    setPractitionerSlotsBlocked(prev =>
      prev.includes(slotTime) ? prev.filter(s => s !== slotTime) : [...prev, slotTime]
    );
  };

  const validateFacility = (id: string) => {
    setPendingFacilities(prev => prev.filter(f => f.id !== id));
    showToast(
      language === 'fr' ? 'Établissement validé !' : 'تم اعتماد المنشأة !',
      language === 'fr' ? 'L\'agrément a été mis à jour sur RIMEDIC' : 'تم تحديث الاعتماد في دليل ريميديك'
    );
  };

  const rejectFacility = (id: string) => {
    setPendingFacilities(prev => prev.filter(f => f.id !== id));
    showToast(
      language === 'fr' ? 'Dossier renvoyé' : 'تمت إعادة الملف',
      language === 'fr' ? 'Demande de pièces complémentaires transmise' : 'تم طلب استكمال الوثائق',
      'warning'
    );
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        t,
        isRtl,
        currentRole,
        setCurrentRole,
        isAuthenticated,
        loginAsPatient,
        logoutUser,
        switchAccount,
        firebaseUser,
        isFirebaseLoading,
        firebaseConnected,
        loginWithGoogle,
        loginWithApple,
        loginWithAppleCredentials,
        logoutFirebase,
        authPhoneNumber,
        setAuthPhoneNumber,
        organizationUser,
        loginWithOrganization,
        logoutOrganization,
        currentScreen,
        navigateTo,
        goBack,
        screenHistory,
        selectedCity,
        setSelectedCity,
        selectedSpecialtyId,
        setSelectedSpecialtyId,
        selectedSubspecialtyName,
        setSelectedSubspecialtyName,
        selectedPractitioner,
        setSelectedPractitioner,
        selectedEstablishment,
        setSelectedEstablishment,
        lastCreatedAppointment,
        setLastCreatedAppointment,
        patient,
        setPatient,
        appointments,
        upcomingAppointments,
        pastAppointments,
        cancelledAppointments,
        bookAppointment,
        cancelAppointment,
        practitionerOnline,
        setPractitionerOnline,
        practitionerSlotsBlocked,
        toggleBlockSlot,
        practitionerProfile,
        setPractitionerProfile,
        updatePractitionerProfile,
        updatePractitionerSchedule,
        practitionerAppointments,
        updateAppointmentStatus,
        rescheduleAppointment,
        practitionerUnlocked,
        unlockPractitionerSession,
        lockPractitionerSession,
        establishmentUnlocked,
        unlockEstablishmentSession,
        lockEstablishmentSession,
        lastScannedAppointment,
        setLastScannedAppointment,
        pendingFacilities,
        validateFacility,
        rejectFacility,
        toast,
        showToast,
        hideToast,
        isCityModalOpen,
        setIsCityModalOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
